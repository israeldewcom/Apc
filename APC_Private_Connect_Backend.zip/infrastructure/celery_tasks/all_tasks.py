"""
APC Private Connect - Celery Background Tasks
All async tasks: notifications, media processing, feed ranking, reminders, cleanup
"""

import logging
from datetime import timedelta
from celery import shared_task
from django.utils import timezone
from django.core.cache import cache

logger = logging.getLogger('apc.api')


# ═══════════════════════════════════════════════════════════════════════════════
# NOTIFICATION TASKS
# ═══════════════════════════════════════════════════════════════════════════════

@shared_task(queue='notifications', bind=True, max_retries=3)
def deliver_notification(self, notification_id: str):
    """Deliver a notification via all configured channels"""
    try:
        from apps.notifications.models import Notification
        notification = Notification.objects.get(id=notification_id)

        if 'push' in notification.channels and notification.recipient.fcm_token:
            from core.utils.all_utils import PushNotificationService
            PushNotificationService.send_to_user(
                str(notification.recipient.id),
                notification.title,
                notification.body,
                {'type': notification.notification_type, 'url': notification.action_url}
            )

        if 'email' in notification.channels:
            from core.utils.all_utils import EmailService
            EmailService._send(
                to=notification.recipient.email,
                subject=notification.title,
                html=f'<p>{notification.body}</p>'
            )

        notification.is_sent = True
        notification.sent_at = timezone.now()
        notification.save(update_fields=['is_sent', 'sent_at'])

    except Exception as exc:
        logger.error(f"Notification delivery failed {notification_id}: {exc}")
        raise self.retry(exc=exc, countdown=60)


@shared_task(queue='notifications')
def notify_followers_new_post(user_id: str, post_id: str):
    """Notify followers when user creates a post"""
    try:
        from apps.users.models import User, UserFollowing
        from apps.posts.models_and_views import Post
        from apps.notifications.models import Notification

        user = User.objects.get(id=user_id)
        post = Post.objects.get(id=post_id)

        followers = UserFollowing.objects.filter(
            following=user
        ).select_related('follower')[:500]  # Limit to 500 per task

        for follow in followers:
            follower = follow.follower
            prefs = follower.notification_preferences
            if not prefs.get('new_post', True):
                continue

            Notification.objects.create(
                recipient=follower,
                sender=user,
                notification_type='post_created',
                title=f'{user.get_full_name()} posted',
                body=post.content[:100],
                action_url=f'/posts/{post.id}',
                object_id=str(post.id),
                content_type='post',
                channels=['in_app', 'push'],
            )

        # If many followers, queue remaining
        if followers.count() == 500:
            notify_followers_new_post_batch.delay(user_id, post_id, offset=500)

    except Exception as e:
        logger.error(f"notify_followers_new_post error: {e}")


@shared_task(queue='notifications')
def notify_followers_new_post_batch(user_id: str, post_id: str, offset: int = 0):
    """Batch task for users with many followers"""
    from apps.users.models import UserFollowing
    from apps.posts.models_and_views import Post
    from apps.notifications.models import Notification
    from apps.users.models import User

    user = User.objects.get(id=user_id)
    post = Post.objects.get(id=post_id)
    followers = UserFollowing.objects.filter(following=user).select_related('follower')[offset:offset+500]

    for follow in followers:
        Notification.objects.create(
            recipient=follow.follower, sender=user,
            notification_type='post_created',
            title=f'{user.get_full_name()} posted',
            body=post.content[:100],
            action_url=f'/posts/{post.id}',
            channels=['in_app'],
        )

    if followers.count() == 500:
        notify_followers_new_post_batch.delay(user_id, post_id, offset=offset+500)


@shared_task(queue='notifications')
def send_reaction_notification(reactor_id: str, post_id: str, reaction_type: str):
    try:
        from apps.users.models import User
        from apps.posts.models_and_views import Post
        from apps.notifications.models import Notification

        reactor = User.objects.get(id=reactor_id)
        post = Post.objects.get(id=post_id)

        if str(post.author.id) == reactor_id:
            return

        emoji_map = {
            'like': '👍', 'love': '❤️', 'haha': '😄',
            'wow': '😮', 'sad': '😢', 'angry': '😠',
            'support': '🤝', 'celebrate': '🎉'
        }
        emoji = emoji_map.get(reaction_type, '👍')

        # Batch: don't notify for every single reaction
        batch_key = f'reaction_notif_{post_id}'
        batch_count = cache.get(batch_key, 0)

        if batch_count == 0:
            Notification.objects.create(
                recipient=post.author,
                sender=reactor,
                notification_type='post_like',
                title=f'{reactor.get_full_name()} reacted {emoji}',
                body=f'reacted to your post: "{post.content[:60]}"',
                action_url=f'/posts/{post_id}',
                channels=['in_app', 'push'],
            )
        cache.set(batch_key, batch_count + 1, timeout=300)

    except Exception as e:
        logger.error(f"send_reaction_notification error: {e}")


@shared_task(queue='notifications')
def send_comment_notification(commenter_id: str, post_id: str, comment_id: str):
    try:
        from apps.users.models import User
        from apps.posts.models_and_views import Post, Comment
        from apps.notifications.models import Notification

        commenter = User.objects.get(id=commenter_id)
        post = Post.objects.get(id=post_id)
        comment = Comment.objects.get(id=comment_id)

        if str(post.author.id) != commenter_id:
            Notification.objects.create(
                recipient=post.author,
                sender=commenter,
                notification_type='post_comment',
                title=f'{commenter.get_full_name()} commented',
                body=comment.content[:100],
                action_url=f'/posts/{post_id}#comment-{comment_id}',
                channels=['in_app', 'push'],
            )

    except Exception as e:
        logger.error(f"send_comment_notification error: {e}")


@shared_task(queue='notifications')
def send_message_push_notification(user_id: str, sender_name: str, preview: str, room_id: str):
    try:
        from apps.users.models import User
        from core.utils.all_utils import PushNotificationService

        user = User.objects.get(id=user_id)
        if user.fcm_token:
            PushNotificationService.send_to_user(
                user_id, sender_name, preview,
                {'type': 'new_message', 'room_id': room_id}
            )
    except Exception as e:
        logger.error(f"send_message_push error: {e}")


@shared_task(queue='notifications')
def notify_group_admins_join_request(group_id: str, user_id: str):
    try:
        from apps.groups.models_and_views import Group, GroupMember
        from apps.users.models import User
        from apps.notifications.models import Notification

        group = Group.objects.get(id=group_id)
        requester = User.objects.get(id=user_id)

        admins = GroupMember.objects.filter(
            group=group,
            role__in=['owner', 'admin', 'super_admin'],
            status='active'
        ).select_related('user')

        for admin_member in admins:
            Notification.objects.create(
                recipient=admin_member.user,
                sender=requester,
                notification_type='group_join_request',
                title=f'Join Request: {group.name}',
                body=f'{requester.get_full_name()} wants to join {group.name}',
                action_url=f'/groups/{group_id}/requests',
                channels=['in_app', 'push'],
            )
    except Exception as e:
        logger.error(f"notify_group_admins_join_request error: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# MEDIA PROCESSING TASKS
# ═══════════════════════════════════════════════════════════════════════════════

@shared_task(queue='media', bind=True, max_retries=2)
def process_post_media(self, post_id: str):
    """Process uploaded media: generate thumbnails, compress, extract metadata"""
    try:
        from apps.posts.models_and_views import PostMedia
        media_items = PostMedia.objects.filter(post_id=post_id, is_processed=False)

        for media in media_items:
            try:
                if media.media_type == 'image':
                    _process_image(media)
                elif media.media_type == 'video':
                    _process_video(media)
                elif media.media_type == 'document':
                    _process_document(media)

                media.is_processed = True
                media.processing_status = 'completed'
                media.save(update_fields=['is_processed', 'processing_status', 'cdn_url'])

            except Exception as e:
                logger.error(f"Media processing failed for {media.id}: {e}")
                media.processing_status = 'failed'
                media.save(update_fields=['processing_status'])

    except Exception as exc:
        raise self.retry(exc=exc, countdown=120)


def _process_image(media):
    """Compress image and generate thumbnail"""
    try:
        from PIL import Image
        import io
        from django.core.files.base import ContentFile

        img = Image.open(media.file)
        media.width, media.height = img.size

        # Generate thumbnail 200x200
        thumb = img.copy()
        thumb.thumbnail((200, 200), Image.LANCZOS)
        thumb_io = io.BytesIO()
        thumb.save(thumb_io, format='JPEG', quality=85)

        filename = f'thumb_{media.file_name}'
        media.thumbnail.save(filename, ContentFile(thumb_io.getvalue()), save=False)

        # Set CDN URL
        media.cdn_url = media.file.url

    except Exception as e:
        logger.warning(f"Image processing error: {e}")


def _process_video(media):
    """Extract video metadata and generate thumbnail"""
    try:
        # In production, use ffmpeg via subprocess
        # For now, just mark as processed
        media.cdn_url = media.file.url
    except Exception as e:
        logger.warning(f"Video processing error: {e}")


def _process_document(media):
    """Process document uploads"""
    media.cdn_url = media.file.url


@shared_task(queue='media')
def compress_profile_picture(user_id: str):
    """Compress user profile pictures"""
    try:
        from apps.users.models import UserProfile
        from PIL import Image
        import io
        from django.core.files.base import ContentFile

        profile = UserProfile.objects.get(user_id=user_id)
        if not profile.profile_picture:
            return

        img = Image.open(profile.profile_picture)
        img = img.convert('RGB')
        img.thumbnail((400, 400), Image.LANCZOS)

        output = io.BytesIO()
        img.save(output, format='JPEG', quality=90)

        filename = f'avatar_{user_id}.jpg'
        profile.profile_picture.save(filename, ContentFile(output.getvalue()), save=True)

    except Exception as e:
        logger.error(f"Profile picture compression failed: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# MEETING TASKS
# ═══════════════════════════════════════════════════════════════════════════════

@shared_task(queue='meetings')
def schedule_meeting_reminders(meeting_id: str):
    """Schedule reminder emails/notifications 24h and 15min before meeting"""
    from apps.meetings.models_and_views import Meeting, MeetingParticipant
    from celery import current_app

    try:
        meeting = Meeting.objects.get(id=meeting_id)
        if not meeting.scheduled_at:
            return

        # 24-hour reminder
        reminder_24h = meeting.scheduled_at - timedelta(hours=24)
        if reminder_24h > timezone.now():
            send_meeting_reminder_notification.apply_async(
                args=[meeting_id, '24h'],
                eta=reminder_24h
            )

        # 15-minute reminder
        reminder_15m = meeting.scheduled_at - timedelta(minutes=15)
        if reminder_15m > timezone.now():
            send_meeting_reminder_notification.apply_async(
                args=[meeting_id, '15m'],
                eta=reminder_15m
            )

    except Exception as e:
        logger.error(f"schedule_meeting_reminders error: {e}")


@shared_task(queue='meetings')
def send_meeting_reminder_notification(meeting_id: str, reminder_type: str):
    """Send meeting reminder to all registered participants"""
    from apps.meetings.models_and_views import Meeting, MeetingParticipant
    from apps.notifications.models import Notification
    from core.utils.all_utils import EmailService

    try:
        meeting = Meeting.objects.get(id=meeting_id)

        if meeting.status == 'cancelled':
            return

        participants = MeetingParticipant.objects.filter(
            meeting=meeting
        ).select_related('user')

        time_text = '24 hours' if reminder_type == '24h' else '15 minutes'

        for participant in participants:
            if not participant.user:
                continue

            Notification.objects.create(
                recipient=participant.user,
                notification_type='meeting_reminder',
                title=f'Meeting in {time_text}: {meeting.title}',
                body=f'Your meeting starts {time_text}. Join: {meeting.join_url}',
                action_url=meeting.join_url,
                channels=['in_app', 'push', 'email'],
            )

            # Also send email for 24h reminder
            if reminder_type == '24h':
                EmailService.send_meeting_reminder(
                    participant.user.email,
                    participant.user.first_name,
                    meeting.title,
                    meeting.scheduled_at.strftime('%Y-%m-%d %H:%M UTC'),
                    meeting.join_url
                )

    except Exception as e:
        logger.error(f"send_meeting_reminder_notification error: {e}")


@shared_task(queue='meetings')
def end_expired_meetings():
    """Auto-end meetings that have exceeded their duration"""
    from apps.meetings.models_and_views import Meeting

    expired = Meeting.objects.filter(
        status='active',
        started_at__lte=timezone.now() - timedelta(hours=12)
    )

    for meeting in expired:
        meeting.status = Meeting.Status.ENDED
        meeting.ended_at = timezone.now()
        if meeting.started_at:
            duration = (meeting.ended_at - meeting.started_at).total_seconds() / 60
            meeting.actual_duration_minutes = int(duration)
        meeting.save()
        logger.info(f"Auto-ended expired meeting: {meeting.meeting_id}")


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYTICS TASKS
# ═══════════════════════════════════════════════════════════════════════════════

@shared_task(queue='analytics')
def calculate_daily_stats():
    """Calculate and store daily platform statistics - runs at midnight"""
    from apps.security.models_and_views import DailyStats, UserActivity
    from apps.users.models import User
    from apps.posts.models_and_views import Post, Reaction, Comment
    from apps.messaging.models_and_views import Message
    from apps.meetings.models_and_views import Meeting

    today = timezone.now().date()
    yesterday = today - timedelta(days=1)

    stats, _ = DailyStats.objects.get_or_create(date=yesterday)

    stats.new_registrations = User.objects.filter(date_joined__date=yesterday).count()
    stats.active_users = User.objects.filter(last_seen__date=yesterday).count()
    stats.total_logins = UserActivity.objects.filter(
        activity_type='login', timestamp__date=yesterday
    ).count()
    stats.verified_users_total = User.objects.filter(is_verified=True).count()
    stats.posts_created = Post.objects.filter(created_at__date=yesterday).count()
    stats.comments_created = Comment.objects.filter(created_at__date=yesterday).count()
    stats.reactions_given = Reaction.objects.filter(created_at__date=yesterday).count()
    stats.messages_sent = Message.objects.filter(created_at__date=yesterday).count()
    stats.meetings_held = Meeting.objects.filter(
        started_at__date=yesterday, status='ended'
    ).count()
    stats.nin_verifications = UserActivity.objects.filter(
        activity_type='nin_verified', timestamp__date=yesterday
    ).count()
    stats.save()

    logger.info(f"Daily stats calculated for {yesterday}")


@shared_task(queue='analytics')
def update_feed_cache(user_id: str):
    """Invalidate and pre-warm feed cache after user posts"""
    cache_patterns = [
        f'feed_{user_id}_home_1',
        f'feed_{user_id}_following_1',
    ]
    for key in cache_patterns:
        cache.delete(key)


@shared_task(queue='analytics')
def recalculate_trending_posts():
    """Recalculate trending score for all recent posts"""
    from apps.posts.models_and_views import Post
    from django.db.models import F

    recent_posts = Post.objects.filter(
        created_at__gte=timezone.now() - timedelta(hours=48),
        post_status='published'
    )

    for post in recent_posts:
        post.calculate_engagement_score()

    logger.info(f"Recalculated trending for {recent_posts.count()} posts")


@shared_task(queue='analytics')
def calculate_state_engagement():
    """Calculate per-state engagement scores"""
    from apps.security.models_and_views import StateEngagementStats
    from apps.users.models import User
    from apps.posts.models_and_views import Post
    from apps.meetings.models_and_views import Meeting
    from apps.messaging.models_and_views import Message

    today = timezone.now().date()
    yesterday = today - timedelta(days=1)

    NIGERIAN_STATES = [
        'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa',
        'Benue', 'Borno', 'Cross River', 'Delta', 'Ebonyi', 'Edo',
        'Ekiti', 'Enugu', 'FCT', 'Gombe', 'Imo', 'Jigawa',
        'Kaduna', 'Kano', 'Katsina', 'Kebbi', 'Kogi', 'Kwara',
        'Lagos', 'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun',
        'Oyo', 'Plateau', 'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara',
    ]

    for state in NIGERIAN_STATES:
        active = User.objects.filter(state=state, last_seen__date=yesterday).count()
        posts = Post.objects.filter(author__state=state, created_at__date=yesterday).count()
        meetings = Meeting.objects.filter(host__state=state, created_at__date=yesterday).count()
        new_regs = User.objects.filter(state=state, date_joined__date=yesterday).count()

        score = (active * 1.0 + posts * 2.0 + meetings * 5.0 + new_regs * 3.0)

        StateEngagementStats.objects.update_or_create(
            date=yesterday, state=state,
            defaults={
                'active_members': active,
                'posts_count': posts,
                'meetings_count': meetings,
                'new_registrations': new_regs,
                'engagement_score': score,
            }
        )


# ═══════════════════════════════════════════════════════════════════════════════
# SECURITY TASKS
# ═══════════════════════════════════════════════════════════════════════════════

@shared_task(queue='security')
def detect_spam_activity():
    """Detect and flag potential spam accounts"""
    from apps.users.models import User
    from apps.security.models_and_views import SecurityAlert
    from apps.posts.models_and_views import Post

    lookback = timezone.now() - timedelta(hours=1)

    # Find users who posted more than 20 times in last hour
    from django.db.models import Count
    spammers = Post.objects.filter(
        created_at__gte=lookback
    ).values('author').annotate(
        count=Count('id')
    ).filter(count__gte=20)

    for item in spammers:
        user = User.objects.get(id=item['author'])
        SecurityAlert.objects.get_or_create(
            user=user,
            alert_type='spam_activity',
            status='open',
            defaults={
                'severity': 'medium',
                'description': f'User posted {item["count"]} times in 1 hour',
                'metadata': {'post_count': item['count'], 'period': '1h'},
                'auto_action_taken': 'flagged_for_review',
            }
        )


@shared_task(queue='security')
def cleanup_expired_sessions():
    """Clean up expired JWT tokens and device sessions"""
    from apps.users.models import UserDevice
    cutoff = timezone.now() - timedelta(days=30)
    deleted, _ = UserDevice.objects.filter(
        is_current=False, last_active__lt=cutoff
    ).delete()
    logger.info(f"Cleaned up {deleted} expired device sessions")


@shared_task(queue='security')
def cleanup_expired_otp_records():
    """Clean expired OTP cache keys (Redis auto-expires, this is DB cleanup)"""
    # Redis TTL handles OTP expiry automatically
    # This task handles any DB-side cleanup
    pass


# ═══════════════════════════════════════════════════════════════════════════════
# AUDIT TASKS
# ═══════════════════════════════════════════════════════════════════════════════

@shared_task(queue='security')
def create_audit_log(log_data: dict):
    """Async audit log creation"""
    try:
        from apps.security.models_and_views import AuditLog
        from apps.users.models import User

        user = None
        if log_data.get('user_id'):
            user = User.objects.filter(id=log_data['user_id']).first()

        AuditLog.objects.create(
            user=user,
            action=log_data.get('action', ''),
            severity=log_data.get('severity', 'low'),
            ip_address=log_data.get('ip'),
            metadata=log_data.get('details', {}),
            target_type=log_data.get('target_type', ''),
            target_id=log_data.get('target_id', ''),
        )
    except Exception as e:
        logger.error(f"create_audit_log failed: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# CELERY BEAT SCHEDULE (runs in settings or celery.py)
# ═══════════════════════════════════════════════════════════════════════════════

CELERY_BEAT_SCHEDULE = {
    # Daily at midnight
    'daily-stats': {
        'task': 'infrastructure.celery_tasks.calculate_daily_stats',
        'schedule': 86400,
    },
    # Every 15 minutes
    'recalculate-trending': {
        'task': 'infrastructure.celery_tasks.recalculate_trending_posts',
        'schedule': 900,
    },
    # Every hour
    'state-engagement': {
        'task': 'infrastructure.celery_tasks.calculate_state_engagement',
        'schedule': 3600,
    },
    # Every 30 minutes
    'end-expired-meetings': {
        'task': 'infrastructure.celery_tasks.end_expired_meetings',
        'schedule': 1800,
    },
    # Every 2 hours
    'detect-spam': {
        'task': 'infrastructure.celery_tasks.detect_spam_activity',
        'schedule': 7200,
    },
    # Daily
    'cleanup-sessions': {
        'task': 'infrastructure.celery_tasks.cleanup_expired_sessions',
        'schedule': 86400,
    },
}
