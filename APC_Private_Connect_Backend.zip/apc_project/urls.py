"""
APC Private Connect - Master URL Configuration
All API endpoints + WebSocket routing
"""

from django.contrib import admin
from django.urls import path, include
from django.http import JsonResponse
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerUIView, SpectacularRedocView


def health_check(request):
    from django.db import connection
    from django.core.cache import cache
    try:
        connection.ensure_connection()
        db_ok = True
    except Exception:
        db_ok = False

    try:
        cache.set('health', 'ok', timeout=10)
        redis_ok = cache.get('health') == 'ok'
    except Exception:
        redis_ok = False

    status_code = 200 if (db_ok and redis_ok) else 503
    return JsonResponse({
        'status': 'healthy' if status_code == 200 else 'degraded',
        'database': 'ok' if db_ok else 'error',
        'cache': 'ok' if redis_ok else 'error',
        'version': '1.0.0',
        'platform': 'APC Private Connect',
    }, status=status_code)


# ─── Authentication ───────────────────────────────────────────────────────────
auth_patterns = [
    path('register', include('apps.authentication.urls.register')),
    path('login', include('apps.authentication.urls.login')),
    path('logout', include('apps.authentication.urls.logout')),
    path('2fa/', include('apps.authentication.urls.twofa')),
    path('password/', include('apps.authentication.urls.password')),
    path('verify/', include('apps.authentication.urls.verify')),
    path('sessions', include('apps.authentication.urls.sessions')),
    path('otp/resend', include('apps.authentication.urls.otp')),
    path('token/refresh', include('apps.authentication.urls.token')),
]

# ─── Users ────────────────────────────────────────────────────────────────────
user_patterns = [
    path('profile', include('apps.users.urls.profile')),
    path('profile/update', include('apps.users.urls.update')),
    path('<uuid:user_id>', include('apps.users.urls.detail')),
    path('<uuid:user_id>/follow', include('apps.users.urls.follow')),
    path('<uuid:user_id>/block', include('apps.users.urls.block')),
    path('<uuid:user_id>/report', include('apps.users.urls.report')),
    path('search', include('apps.users.urls.search')),
    path('followers', include('apps.users.urls.followers')),
    path('following', include('apps.users.urls.following')),
    path('settings', include('apps.users.urls.settings')),
    path('devices', include('apps.users.urls.devices')),
    path('notifications/preferences', include('apps.users.urls.notif_prefs')),
]

# ─── NIN Verification ─────────────────────────────────────────────────────────
verification_patterns = [
    path('nin/submit', include('apps.nin_verification.urls.nin')),
    path('nin/status', include('apps.nin_verification.urls.nin_status')),
    path('fingerprint/enroll', include('apps.nin_verification.urls.fingerprint_enroll')),
    path('fingerprint/verify', include('apps.nin_verification.urls.fingerprint_verify')),
    path('status', include('apps.nin_verification.urls.status')),
]

# ─── Posts & Feed ─────────────────────────────────────────────────────────────
post_patterns = [
    path('feed', include('apps.posts.urls.feed')),
    path('create', include('apps.posts.urls.create')),
    path('<uuid:post_id>', include('apps.posts.urls.detail')),
    path('<uuid:post_id>/react', include('apps.posts.urls.react')),
    path('<uuid:post_id>/comments', include('apps.posts.urls.comments')),
    path('<uuid:post_id>/share', include('apps.posts.urls.share')),
    path('<uuid:post_id>/save', include('apps.posts.urls.save')),
    path('<uuid:post_id>/report', include('apps.posts.urls.report')),
    path('<uuid:post_id>/poll/vote', include('apps.posts.urls.poll')),
    path('saved', include('apps.posts.urls.saved')),
    path('trending', include('apps.posts.urls.trending')),
]

# ─── Messaging ────────────────────────────────────────────────────────────────
message_patterns = [
    path('conversations', include('apps.messaging.urls.conversations')),
    path('direct', include('apps.messaging.urls.direct')),
    path('<uuid:room_id>/history', include('apps.messaging.urls.history')),
    path('<uuid:room_id>/media', include('apps.messaging.urls.media')),
    path('<uuid:room_id>/members', include('apps.messaging.urls.members')),
    path('<uuid:room_id>/settings', include('apps.messaging.urls.settings')),
    path('groups/create', include('apps.messaging.urls.group_create')),
    path('search', include('apps.messaging.urls.search')),
    path('upload', include('apps.messaging.urls.upload')),
]

# ─── Groups ───────────────────────────────────────────────────────────────────
group_patterns = [
    path('', include('apps.groups.urls.list')),
    path('create', include('apps.groups.urls.create')),
    path('<uuid:group_id>', include('apps.groups.urls.detail')),
    path('<uuid:group_id>/join', include('apps.groups.urls.join')),
    path('<uuid:group_id>/leave', include('apps.groups.urls.leave')),
    path('<uuid:group_id>/members', include('apps.groups.urls.members')),
    path('<uuid:group_id>/members/manage', include('apps.groups.urls.manage')),
    path('<uuid:group_id>/posts', include('apps.groups.urls.posts')),
    path('<uuid:group_id>/announcements', include('apps.groups.urls.announcements')),
    path('<uuid:group_id>/documents', include('apps.groups.urls.documents')),
    path('<uuid:group_id>/polls', include('apps.groups.urls.polls')),
    path('<uuid:group_id>/settings', include('apps.groups.urls.settings')),
    path('<uuid:group_id>/invitations', include('apps.groups.urls.invitations')),
    path('<uuid:group_id>/analytics', include('apps.groups.urls.analytics')),
]

# ─── Meetings ─────────────────────────────────────────────────────────────────
meeting_patterns = [
    path('', include('apps.meetings.urls.list')),
    path('create', include('apps.meetings.urls.create')),
    path('<str:meeting_id>/join', include('apps.meetings.urls.join')),
    path('<str:meeting_id>/leave', include('apps.meetings.urls.leave')),
    path('<str:meeting_id>/end', include('apps.meetings.urls.end')),
    path('<str:meeting_id>/details', include('apps.meetings.urls.details')),
    path('<str:meeting_id>/participants', include('apps.meetings.urls.participants')),
    path('<str:meeting_id>/chat', include('apps.meetings.urls.chat')),
    path('<str:meeting_id>/recording', include('apps.meetings.urls.recording')),
    path('<str:meeting_id>/stats', include('apps.meetings.urls.stats')),
    path('<str:meeting_id>/cancel', include('apps.meetings.urls.cancel')),
    path('upcoming', include('apps.meetings.urls.upcoming')),
]

# ─── Notifications ────────────────────────────────────────────────────────────
notification_patterns = [
    path('', include('apps.notifications.urls.list')),
    path('unread-count', include('apps.notifications.urls.count')),
    path('mark-read', include('apps.notifications.urls.mark_read')),
    path('settings', include('apps.notifications.urls.settings')),
]

# ─── Media ────────────────────────────────────────────────────────────────────
media_patterns = [
    path('upload', include('apps.media.urls.upload')),
    path('<uuid:media_id>', include('apps.media.urls.detail')),
    path('<uuid:media_id>/download', include('apps.media.urls.download')),
]

# ─── Analytics ────────────────────────────────────────────────────────────────
analytics_patterns = [
    path('dashboard', include('apps.analytics.urls.dashboard')),
    path('users', include('apps.analytics.urls.users')),
    path('engagement', include('apps.analytics.urls.engagement')),
    path('meetings', include('apps.analytics.urls.meetings')),
    path('states', include('apps.analytics.urls.states')),
    path('me', include('apps.analytics.urls.personal')),
]

# ─── Security (Admin) ─────────────────────────────────────────────────────────
security_patterns = [
    path('dashboard', include('apps.security.urls.dashboard')),
    path('alerts', include('apps.security.urls.alerts')),
    path('alerts/<uuid:alert_id>', include('apps.security.urls.alert_detail')),
    path('audit-logs', include('apps.security.urls.audit')),
    path('ip-blacklist', include('apps.security.urls.blacklist')),
    path('spam-reports', include('apps.security.urls.spam')),
    path('user/<uuid:user_id>/suspend', include('apps.security.urls.suspend')),
    path('user/<uuid:user_id>/ban', include('apps.security.urls.ban')),
]

# ─── Search ───────────────────────────────────────────────────────────────────
search_patterns = [
    path('', include('apps.search.urls.global_search')),
    path('users', include('apps.search.urls.users')),
    path('posts', include('apps.search.urls.posts')),
    path('groups', include('apps.search.urls.groups')),
    path('messages', include('apps.search.urls.messages')),
]

# ─── Master URL Patterns ──────────────────────────────────────────────────────
urlpatterns = [
    path('admin/', admin.site.urls),
    path('health/', health_check),

    # API v1
    path('api/v1/auth/', include((auth_patterns, 'auth'))),
    path('api/v1/users/', include((user_patterns, 'users'))),
    path('api/v1/verification/', include((verification_patterns, 'verification'))),
    path('api/v1/posts/', include((post_patterns, 'posts'))),
    path('api/v1/messages/', include((message_patterns, 'messages'))),
    path('api/v1/groups/', include((group_patterns, 'groups'))),
    path('api/v1/meetings/', include((meeting_patterns, 'meetings'))),
    path('api/v1/notifications/', include((notification_patterns, 'notifications'))),
    path('api/v1/media/', include((media_patterns, 'media'))),
    path('api/v1/analytics/', include((analytics_patterns, 'analytics'))),
    path('api/v1/security/', include((security_patterns, 'security'))),
    path('api/v1/search/', include((search_patterns, 'search'))),

    # API Documentation
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/', SpectacularSwaggerUIView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
]


# ─── ASGI + WebSocket Routing ─────────────────────────────────────────────────
"""
ASGI configuration - apc_project/asgi.py
"""
ASGI_CONFIG = '''
import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from channels.security.websocket import AllowedHostsOriginValidator
from django.urls import re_path

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "apc_project.settings")

from apps.messaging.models_and_views import ChatConsumer
from apps.meetings.models_and_views import MeetingSignalingConsumer
from infrastructure.websockets.notification_consumer import NotificationConsumer
from infrastructure.websockets.presence_consumer import PresenceConsumer

websocket_urlpatterns = [
    re_path(r"ws/chat/(?P<room_id>[0-9a-f-]+)/$", ChatConsumer.as_asgi()),
    re_path(r"ws/meeting/(?P<meeting_id>[0-9-]+)/$", MeetingSignalingConsumer.as_asgi()),
    re_path(r"ws/notifications/$", NotificationConsumer.as_asgi()),
    re_path(r"ws/presence/$", PresenceConsumer.as_asgi()),
]

application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": AllowedHostsOriginValidator(
        AuthMiddlewareStack(
            URLRouter(websocket_urlpatterns)
        )
    ),
})
'''
