# APC Private Connect — Backend System
### Enterprise-Grade Private Social Platform Backend

> **Built for Production** · Python/Django · PostgreSQL · Redis · WebRTC · WebSockets · Celery · Docker · Kubernetes

---

## 🏗️ Architecture Overview

```
Internet
    │
    ▼
[CloudFlare CDN / DDoS Protection]
    │
    ▼
[Nginx Reverse Proxy + SSL Termination]
    │         │
    ▼         ▼
[API Server]  [WebSocket Server]
(Gunicorn +  (ASGI + Channels)
 Uvicorn)         │
    │             │
    ▼             ▼
[Django REST Framework + JWT Auth]
    │
    ├──► [PostgreSQL Primary DB]   ─── 70+ tables
    ├──► [PostgreSQL Analytics DB] ─── Stats tables
    ├──► [Redis]                   ─── Cache + Sessions + Pub/Sub
    ├──► [Celery Workers]          ─── Background tasks
    │        ├── notifications queue (x8 workers)
    │        ├── media queue (x2 workers)
    │        ├── analytics queue (x2 workers)
    │        └── security queue (x2 workers)
    ├──► [AWS S3]                  ─── Media storage + CDN
    ├──► [Firebase FCM]            ─── Push notifications
    ├──► [NIMC API]                ─── NIN verification
    └──► [Termii SMS]              ─── SMS OTP
```

---

## 📁 Project Structure

```
apc_backend/
├── apc_project/
│   ├── settings.py          # Production settings
│   ├── urls.py              # Master URL router (70+ endpoints)
│   └── asgi.py              # ASGI + WebSocket config
├── apps/
│   ├── authentication/      # JWT, OTP, 2FA, device verification
│   ├── users/               # User model, profiles, following, blocking
│   ├── nin_verification/    # NIMC API, fingerprint enrollment
│   ├── posts/               # Feed, posts, reactions, comments, polls
│   ├── messaging/           # E2E encrypted chat, WebSocket consumer
│   ├── groups/              # Group management, roles, fingerprint admin
│   ├── meetings/            # WebRTC video conferencing, signaling
│   ├── notifications/       # Multi-channel notification system
│   ├── media/               # File upload, compression, CDN
│   ├── analytics/           # Dashboard, user stats, engagement
│   └── security/            # Audit logs, alerts, IP blacklist
├── core/
│   ├── middleware/          # Security headers, audit, rate limit
│   ├── permissions/         # Custom DRF permission classes
│   └── utils/               # Encryption, OTP, Email, SMS, Pagination
├── infrastructure/
│   ├── celery_tasks/        # All async background tasks
│   └── websockets/          # Notification + presence consumers
├── config/
│   ├── docker/              # docker-compose.yml
│   ├── nginx/               # nginx.conf
│   ├── kubernetes/          # k8s deployment manifests
│   └── prometheus/          # metrics config
├── scripts/
│   ├── deployment/          # deploy.sh
│   ├── automation/          # create_superadmin.py
│   └── monitoring/          # health_check.py
├── tests/                   # Unit + integration + e2e tests
├── docs/                    # API docs, schema reference
├── Dockerfile
├── requirements.txt
└── .env.example
```

---

## 🔌 Complete API Endpoints (70+ routes)

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/register` | Register new member |
| POST | `/api/v1/auth/login` | Login with brute force protection |
| POST | `/api/v1/auth/logout` | Logout + token blacklist |
| POST | `/api/v1/auth/2fa/setup` | Setup TOTP 2FA |
| POST | `/api/v1/auth/2fa/verify` | Verify 2FA code |
| POST | `/api/v1/auth/password/reset/request` | Request password reset OTP |
| POST | `/api/v1/auth/password/reset/confirm` | Confirm password reset |
| POST | `/api/v1/auth/password/change` | Change password |
| POST | `/api/v1/auth/verify/email` | Verify email with OTP |
| POST | `/api/v1/auth/otp/resend` | Resend OTP |
| GET  | `/api/v1/auth/sessions` | List active sessions |
| DELETE | `/api/v1/auth/sessions` | Revoke all sessions |
| POST | `/api/v1/auth/token/refresh` | Refresh JWT token |

### Identity Verification
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/verification/nin/submit` | Submit NIN to NIMC |
| GET  | `/api/v1/verification/nin/status` | NIN verification status |
| POST | `/api/v1/verification/fingerprint/enroll` | Enroll fingerprint |
| POST | `/api/v1/verification/fingerprint/verify` | Verify fingerprint |
| GET  | `/api/v1/verification/status` | Full verification status |

### Posts & Feed
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/v1/posts/feed` | Personalized feed (home/trending/following) |
| POST | `/api/v1/posts/create` | Create post (text/image/video/doc/poll) |
| GET  | `/api/v1/posts/<id>` | Get post detail |
| PUT  | `/api/v1/posts/<id>` | Edit post |
| DELETE | `/api/v1/posts/<id>` | Delete post |
| POST | `/api/v1/posts/<id>/react` | React to post |
| GET/POST | `/api/v1/posts/<id>/comments` | List/add comments |
| POST | `/api/v1/posts/<id>/save` | Save/unsave post |
| POST | `/api/v1/posts/<id>/share` | Share post |
| POST | `/api/v1/posts/<id>/poll/vote` | Vote on poll |
| GET  | `/api/v1/posts/trending` | Trending posts |
| GET  | `/api/v1/posts/saved` | Saved posts |

### Messaging
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/v1/messages/conversations` | List all conversations |
| POST | `/api/v1/messages/direct` | Start/get DM with user |
| GET  | `/api/v1/messages/<room_id>/history` | Message history (paginated) |
| POST | `/api/v1/messages/groups/create` | Create group chat |
| GET  | `/api/v1/messages/search` | Search messages |
| POST | `/api/v1/messages/upload` | Upload media for chat |
| **WS** | `ws://api/ws/chat/<room_id>/` | Real-time chat WebSocket |

### Groups
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/v1/groups` | List/discover groups |
| POST | `/api/v1/groups/create` | Create group |
| GET  | `/api/v1/groups/<id>` | Group detail |
| POST | `/api/v1/groups/<id>/join` | Join group |
| GET  | `/api/v1/groups/<id>/members` | Member list |
| POST | `/api/v1/groups/<id>/members/manage` | Approve/remove/ban members |
| GET/POST | `/api/v1/groups/<id>/announcements` | Group announcements |
| GET/POST | `/api/v1/groups/<id>/documents` | Group documents |

### Meetings (Zoom-level)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/v1/meetings` | List meetings |
| POST | `/api/v1/meetings/create` | Create meeting |
| POST | `/api/v1/meetings/<id>/join` | Join meeting (get WebRTC config) |
| POST | `/api/v1/meetings/<id>/end` | End meeting |
| GET  | `/api/v1/meetings/<id>/stats` | Meeting statistics |
| GET  | `/api/v1/meetings/<id>/recording` | Access recording |
| GET  | `/api/v1/meetings/upcoming` | Upcoming meetings |
| **WS** | `ws://api/ws/meeting/<meeting_id>/` | WebRTC signaling WebSocket |

### Analytics
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/analytics/dashboard` | Admin analytics dashboard |
| GET | `/api/v1/analytics/users` | User registration analytics |
| GET | `/api/v1/analytics/engagement` | Content engagement stats |
| GET | `/api/v1/analytics/meetings` | Meeting analytics |
| GET | `/api/v1/analytics/states` | State engagement rankings |
| GET | `/api/v1/analytics/me` | Personal analytics |

### Security (Admin)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/v1/security/dashboard` | Security overview |
| GET  | `/api/v1/security/alerts` | Security alerts list |
| PATCH | `/api/v1/security/alerts/<id>` | Resolve alert |
| GET  | `/api/v1/security/audit-logs` | Full audit trail |
| POST/DELETE | `/api/v1/security/ip-blacklist` | IP blocking |

---

## 🔒 Security Features

| Feature | Implementation |
|---------|---------------|
| Authentication | JWT + Refresh tokens + Token blacklist |
| 2FA | TOTP (Google Authenticator compatible) |
| Identity Verification | NIMC API + Fingerprint biometrics |
| Message Encryption | AES-256 (Fernet) at rest |
| Password Policy | 10 chars + uppercase + number + special char |
| Brute Force Protection | 5 attempts → 30min lockout per IP+email |
| Device Verification | New device OTP via email |
| Rate Limiting | Per-endpoint limits via DRF + Nginx |
| IP Blacklisting | Automatic + manual with Redis cache |
| Audit Logging | Every sensitive action logged to DB + file |
| Security Alerts | Auto-detected: brute force, duplicate NIN, spam |
| Fingerprint for Admin | Group admin actions require biometric confirmation |
| HTTPS Only | SSL/TLS 1.2/1.3, HSTS preload |
| Security Headers | CSP, XSS, Frame-Options, HSTS |

---

## ⚡ WebSocket Events

### Chat WebSocket (`ws/chat/<room_id>/`)
| Direction | Event | Payload |
|-----------|-------|---------|
| Client→Server | `message` | `{type, content, message_type, reply_to, media_url}` |
| Client→Server | `typing` | `{type}` |
| Client→Server | `read` | `{type, message_id}` |
| Client→Server | `reaction` | `{type, message_id, emoji}` |
| Client→Server | `edit` | `{type, message_id, content}` |
| Client→Server | `delete` | `{type, message_id, delete_for_everyone}` |
| Server→Client | `message` | Full message object |
| Server→Client | `typing` | `{user_id, username, is_typing}` |
| Server→Client | `read_receipt` | `{message_id, user_id, read_at}` |
| Server→Client | `reaction` | `{message_id, user_id, emoji}` |
| Server→Client | `presence` | `{user_id, online/offline, last_seen}` |

### Meeting WebSocket (`ws/meeting/<meeting_id>/`)
| Direction | Event | Payload |
|-----------|-------|---------|
| Client→Server | `offer` | `{to_user, sdp}` WebRTC offer |
| Client→Server | `answer` | `{to_user, sdp}` WebRTC answer |
| Client→Server | `ice_candidate` | `{to_user, candidate}` |
| Client→Server | `mute` | `{muted: bool}` |
| Client→Server | `video` | `{enabled: bool}` |
| Client→Server | `screen_share` | `{sharing: bool}` |
| Client→Server | `raise_hand` | `{raised: bool}` |
| Client→Server | `chat` | `{content}` |
| Client→Server | `end_meeting` | `{}` (host only) |
| Client→Server | `start_recording` | `{}` (host only) |

---

## 🚀 Quick Start (Development)

```bash
# 1. Clone and setup
git clone https://github.com/apc-connect/backend.git
cd apc_backend

# 2. Create virtual environment
python -m venv venv && source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env with your settings

# 5. Start services
docker-compose -f config/docker/docker-compose.dev.yml up -d postgres redis

# 6. Run migrations
python manage.py migrate

# 7. Create super admin
python scripts/automation/create_superadmin.py

# 8. Start development server
python manage.py runserver

# 9. Start Celery worker
celery -A apc_project worker --loglevel=info

# 10. API Documentation
# Open: http://localhost:8000/api/docs/
```

## 🐳 Production Deployment

```bash
# Deploy with Docker Compose
docker-compose -f config/docker/docker-compose.yml up -d

# Or use deployment script
bash scripts/deployment/deploy.sh

# Check health
python scripts/monitoring/health_check.py
```

---

## 📊 Performance Targets

| Metric | Target |
|--------|--------|
| API Response Time (p95) | < 200ms |
| WebSocket Message Latency | < 50ms |
| Feed Generation | < 500ms |
| Notification Delivery | < 2 seconds |
| Concurrent WebSocket Connections | 100,000+ |
| Daily Active Users | 1,000,000+ |
| Messages per Second | 10,000+ |

---

*APC Private Connect Backend v1.0.0 — Built for Scale*
