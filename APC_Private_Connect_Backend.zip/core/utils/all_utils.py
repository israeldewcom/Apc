"""
APC Private Connect - Core Utilities & Middleware
Encryption, OTP, Email, SMS, Audit Logger, Rate Limiter, Security Middleware
"""

import os
import hmac
import json
import random
import string
import hashlib
import logging
import secrets
from datetime import datetime, timedelta

from django.conf import settings
from django.core.cache import cache
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils import timezone

from rest_framework.permissions import BasePermission
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination
from rest_framework.exceptions import Throttled
from rest_framework.views import exception_handler

from cryptography.fernet import Fernet

logger = logging.getLogger('apc.api')
security_logger = logging.getLogger('apc.security')
audit_log = logging.getLogger('apc.audit')


# ═══════════════════════════════════════════════════════════════════════════════
# ENCRYPTION SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

class EncryptionService:
    """
    AES-256 encryption for sensitive data at rest (messages, biometric templates)
    """

    _key = None

    @classmethod
    def _get_key(cls):
        if not cls._key:
            raw_key = settings.SECRET_KEY[:32].encode().ljust(32, b'0')
            import base64
            cls._key = base64.urlsafe_b64encode(raw_key)
        return cls._key

    @classmethod
    def encrypt(cls, data: str) -> bytes:
        f = Fernet(cls._get_key())
        return f.encrypt(data.encode('utf-8'))

    @classmethod
    def decrypt(cls, token: bytes) -> str:
        f = Fernet(cls._get_key())
        return f.decrypt(token).decode('utf-8')

    @classmethod
    def hash_sensitive(cls, data: str) -> str:
        """One-way hash for sensitive lookups (NIN, fingerprint dedup)"""
        return hmac.new(
            settings.SECRET_KEY.encode(),
            data.encode(),
            hashlib.sha256
        ).hexdigest()


# ═══════════════════════════════════════════════════════════════════════════════
# OTP SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

class OTPService:
    """One-Time Password generation and verification via Redis"""

    def generate_and_store(self, key: str, length: int = 6, expiry_minutes: int = 10) -> str:
        otp = ''.join(random.choices(string.digits, k=length))
        hashed = hashlib.sha256(otp.encode()).hexdigest()
        cache.set(f'otp_{key}', hashed, timeout=expiry_minutes * 60)
        # Track attempt count
        cache.set(f'otp_attempts_{key}', 0, timeout=expiry_minutes * 60)
        return otp

    def verify(self, key: str, otp: str) -> bool:
        stored_hash = cache.get(f'otp_{key}')
        if not stored_hash:
            return False

        attempts = cache.get(f'otp_attempts_{key}', 0)
        if attempts >= 5:
            cache.delete(f'otp_{key}')
            return False

        cache.incr(f'otp_attempts_{key}')
        submitted_hash = hashlib.sha256(otp.encode()).hexdigest()

        if hmac.compare_digest(stored_hash, submitted_hash):
            cache.delete(f'otp_{key}')
            cache.delete(f'otp_attempts_{key}')
            return True
        return False


# ═══════════════════════════════════════════════════════════════════════════════
# EMAIL SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

class EmailService:
    """Transactional email service"""

    FROM_EMAIL = settings.DEFAULT_FROM_EMAIL
    PLATFORM_NAME = 'APC Private Connect'

    @classmethod
    def send_email_verification(cls, email: str, name: str, otp: str):
        subject = f'Verify your {cls.PLATFORM_NAME} email'
        html = f"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;background:#f9f9f9">
          <div style="background:#006400;padding:20px;text-align:center;border-radius:8px 8px 0 0">
            <h1 style="color:white;margin:0">APC Private Connect</h1>
          </div>
          <div style="background:white;padding:30px;border-radius:0 0 8px 8px">
            <h2>Hello {name},</h2>
            <p>Your email verification code is:</p>
            <div style="background:#f0f4f8;padding:20px;text-align:center;border-radius:8px;margin:20px 0">
              <span style="font-size:36px;font-weight:bold;letter-spacing:8px;color:#006400">{otp}</span>
            </div>
            <p>This code expires in <strong>10 minutes</strong>.</p>
            <p>If you did not request this, please ignore this email.</p>
          </div>
        </div>
        """
        cls._send(to=email, subject=subject, html=html)

    @classmethod
    def send_password_reset(cls, email: str, name: str, otp: str):
        subject = f'{cls.PLATFORM_NAME} - Password Reset Code'
        html = f"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px">
          <h2>Password Reset Request</h2>
          <p>Dear {name}, your password reset code is:</p>
          <div style="background:#fee;padding:20px;text-align:center;border-radius:8px;margin:20px 0;border:2px solid #c00">
            <span style="font-size:36px;font-weight:bold;letter-spacing:8px;color:#c00">{otp}</span>
          </div>
          <p>Expires in <strong>15 minutes</strong>. If you did not request this, secure your account immediately.</p>
        </div>
        """
        cls._send(to=email, subject=subject, html=html)

    @classmethod
    def send_new_device_alert(cls, email: str, name: str, device, otp: str):
        subject = f'[SECURITY] New device login - {cls.PLATFORM_NAME}'
        html = f"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px">
          <h2 style="color:#c00">⚠️ New Device Login Detected</h2>
          <p>Dear {name},</p>
          <p>A login was attempted from a new device:</p>
          <ul>
            <li><strong>Device:</strong> {device.device_name or 'Unknown'}</li>
            <li><strong>Type:</strong> {device.device_type}</li>
            <li><strong>IP:</strong> {device.ip_address}</li>
            <li><strong>Time:</strong> {timezone.now().strftime('%Y-%m-%d %H:%M UTC')}</li>
          </ul>
          <p>Verification code: <strong style="font-size:24px;color:#006400">{otp}</strong></p>
          <p>If this wasn't you, change your password immediately.</p>
        </div>
        """
        cls._send(to=email, subject=subject, html=html)

    @classmethod
    def send_meeting_reminder(cls, email: str, name: str, meeting_title: str,
                              meeting_time: str, join_url: str):
        subject = f'Meeting Reminder: {meeting_title}'
        html = f"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px">
          <h2>📅 Meeting Reminder</h2>
          <p>Dear {name},</p>
          <p>Your meeting <strong>{meeting_title}</strong> starts at <strong>{meeting_time}</strong>.</p>
          <a href="{join_url}" style="display:inline-block;background:#006400;color:white;padding:12px 24px;
             text-decoration:none;border-radius:6px;margin:16px 0;font-weight:bold">Join Meeting</a>
          <p style="color:#666;font-size:12px">APC Private Connect Platform</p>
        </div>
        """
        cls._send(to=email, subject=subject, html=html)

    @classmethod
    def send_nin_verification_result(cls, email: str, name: str, success: bool, message: str):
        status_text = 'Verified ✅' if success else 'Failed ❌'
        color = '#006400' if success else '#c00'
        subject = f'NIN Verification {status_text}'
        html = f"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px">
          <h2 style="color:{color}">NIN Verification {status_text}</h2>
          <p>Dear {name},</p>
          <p>{message}</p>
        </div>
        """
        cls._send(to=email, subject=subject, html=html)

    @classmethod
    def _send(cls, to: str, subject: str, html: str):
        try:
            from django.core.mail import EmailMultiAlternatives
            msg = EmailMultiAlternatives(subject, html, cls.FROM_EMAIL, [to])
            msg.attach_alternative(html, 'text/html')
            msg.send(fail_silently=False)
        except Exception as e:
            logger.error(f"Email send failed to {to}: {str(e)}")


# ═══════════════════════════════════════════════════════════════════════════════
# SMS SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

class SMSService:
    """SMS service via Termii or Twilio"""

    @classmethod
    def send_verification(cls, phone: str, otp: str):
        message = f'Your APC Connect verification code is: {otp}. Valid for 10 minutes. Do not share.'
        cls._send(phone, message)

    @classmethod
    def send_security_alert(cls, phone: str, alert: str):
        cls._send(phone, f'APC Connect Security Alert: {alert}')

    @classmethod
    def _send(cls, phone: str, message: str):
        try:
            # Termii API (popular Nigeria SMS provider)
            import requests as req
            api_key = settings.APC_SETTINGS.get('TERMII_API_KEY', '')
            if not api_key:
                logger.warning(f"SMS not configured. Would send to {phone}: {message}")
                return

            payload = {
                'to': phone, 'from': 'APC_Connect',
                'sms': message, 'type': 'plain',
                'channel': 'dnd', 'api_key': api_key,
            }
            req.post('https://api.ng.termii.com/api/sms/send', json=payload, timeout=10)
        except Exception as e:
            logger.error(f"SMS send failed to {phone}: {str(e)}")


# ═══════════════════════════════════════════════════════════════════════════════
# PUSH NOTIFICATION SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

class PushNotificationService:
    """Firebase Cloud Messaging push notifications"""

    @classmethod
    def send_to_user(cls, user_id: str, title: str, body: str, data: dict = None):
        from apps.users.models import User, UserDevice
        try:
            devices = UserDevice.objects.filter(
                user_id=user_id, is_current=True
            ).exclude(fcm_token='')
            for device in devices:
                cls._send_fcm(device.fcm_token, title, body, data or {})
        except Exception as e:
            logger.error(f"Push notification failed for user {user_id}: {str(e)}")

    @classmethod
    def send_to_topic(cls, topic: str, title: str, body: str, data: dict = None):
        """Send to all subscribers of a topic (e.g., state groups)"""
        import requests as req
        try:
            headers = {
                'Authorization': f'key={settings.FCM_SERVER_KEY}',
                'Content-Type': 'application/json',
            }
            payload = {
                'to': f'/topics/{topic}',
                'notification': {'title': title, 'body': body},
                'data': data or {},
            }
            req.post('https://fcm.googleapis.com/fcm/send',
                    json=payload, headers=headers, timeout=10)
        except Exception as e:
            logger.error(f"Push to topic {topic} failed: {str(e)}")

    @classmethod
    def _send_fcm(cls, token: str, title: str, body: str, data: dict):
        import requests as req
        headers = {
            'Authorization': f'key={settings.FCM_SERVER_KEY}',
            'Content-Type': 'application/json',
        }
        payload = {
            'to': token,
            'notification': {
                'title': title, 'body': body,
                'icon': 'apc_icon', 'sound': 'default',
            },
            'data': data,
            'priority': 'high',
        }
        try:
            req.post('https://fcm.googleapis.com/fcm/send',
                    json=payload, headers=headers, timeout=10)
        except Exception as e:
            logger.error(f"FCM send failed: {str(e)}")


# ═══════════════════════════════════════════════════════════════════════════════
# AUDIT LOGGER
# ═══════════════════════════════════════════════════════════════════════════════

class AuditLogger:
    """Structured audit logging to both DB and log files"""

    # High severity actions
    HIGH_SEVERITY_ACTIONS = {
        'ACCOUNT_LOCKED', 'ACCOUNT_SUSPENDED', 'ACCOUNT_BANNED',
        'ADMIN_ACTION', 'ROLE_CHANGED', 'NIN_VERIFIED', 'FINGERPRINT_ENROLLED',
        'DUPLICATE_NIN_DETECTED', 'IP_BLACKLISTED', 'PASSWORD_RESET_COMPLETED',
        'ALL_SESSIONS_REVOKED', '2FA_ENABLED', '2FA_DISABLED',
        'GROUP_MEMBER_BAN', 'USER_REPORTED',
    }

    CRITICAL_ACTIONS = {
        'SUPER_ADMIN_ACTION', 'DATA_EXPORT', 'BULK_USER_ACTION',
        'PLATFORM_SETTINGS_CHANGED', 'SECURITY_POLICY_CHANGED',
    }

    def log(self, action: str, user=None, ip: str = None,
            details: dict = None, target_type: str = '', target_id: str = ''):
        severity = 'low'
        if action in self.HIGH_SEVERITY_ACTIONS:
            severity = 'high'
        elif action in self.CRITICAL_ACTIONS:
            severity = 'critical'

        log_data = {
            'action': action,
            'user_id': str(user.id) if user else None,
            'username': user.username if user else None,
            'ip': ip,
            'severity': severity,
            'details': details or {},
            'timestamp': timezone.now().isoformat(),
            'target_type': target_type,
            'target_id': target_id,
        }

        # Write to log file
        audit_log.info(json.dumps(log_data))

        # Write to DB asynchronously
        try:
            from infrastructure.celery_tasks.audit import create_audit_log
            create_audit_log.delay(log_data)
        except Exception:
            # Fallback: write synchronously
            from apps.security.models_and_views import AuditLog
            AuditLog.objects.create(
                user=user,
                action=action,
                severity=severity,
                ip_address=ip,
                metadata=details or {},
                target_type=target_type,
                target_id=target_id,
            )


# ═══════════════════════════════════════════════════════════════════════════════
# MIDDLEWARE
# ═══════════════════════════════════════════════════════════════════════════════

class SecurityHeadersMiddleware:
    """Add security headers to all responses"""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response['X-Content-Type-Options'] = 'nosniff'
        response['X-Frame-Options'] = 'DENY'
        response['X-XSS-Protection'] = '1; mode=block'
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
        response['Content-Security-Policy'] = (
            "default-src 'self'; "
            "img-src 'self' data: https:; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline';"
        )
        return response


class AuditLogMiddleware:
    """Log all API requests for audit trail"""

    EXEMPT_PATHS = ['/health/', '/metrics/', '/static/', '/favicon.ico']
    LOG_METHODS = ['POST', 'PUT', 'PATCH', 'DELETE']

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        if (request.method in self.LOG_METHODS and
                not any(request.path.startswith(p) for p in self.EXEMPT_PATHS) and
                hasattr(request, 'user') and request.user.is_authenticated):

            try:
                audit_log.info(json.dumps({
                    'user_id': str(request.user.id),
                    'method': request.method,
                    'path': request.path,
                    'status_code': response.status_code,
                    'ip': self._get_ip(request),
                    'timestamp': timezone.now().isoformat(),
                }))
            except Exception:
                pass

        return response

    def _get_ip(self, request):
        x_fwd = request.META.get('HTTP_X_FORWARDED_FOR', '')
        return x_fwd.split(',')[0].strip() if x_fwd else request.META.get('REMOTE_ADDR', '')


class RateLimitMiddleware:
    """Global rate limiting and IP blacklist enforcement"""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        ip = self._get_ip(request)

        # Check IP blacklist
        if cache.get(f'ip_blocked_{ip}'):
            from django.http import JsonResponse
            security_logger.warning(f"Blocked request from blacklisted IP: {ip}")
            return JsonResponse({'error': 'Access denied.', 'code': 'IP_BLOCKED'}, status=403)

        return self.get_response(request)

    def _get_ip(self, request):
        x_fwd = request.META.get('HTTP_X_FORWARDED_FOR', '')
        return x_fwd.split(',')[0].strip() if x_fwd else request.META.get('REMOTE_ADDR', '')


class DeviceTrackingMiddleware:
    """Track device ID from headers"""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        device_id = request.META.get('HTTP_X_DEVICE_ID', '')
        if device_id and hasattr(request, 'user') and request.user.is_authenticated:
            request.device_id = device_id
        return self.get_response(request)


# ═══════════════════════════════════════════════════════════════════════════════
# PERMISSIONS
# ═══════════════════════════════════════════════════════════════════════════════

class IsVerifiedMember(BasePermission):
    """Require NIN-verified account for sensitive actions"""
    message = 'Account verification required. Please complete NIN and fingerprint verification.'

    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
        return request.user.is_verified or request.user.nin_verified


class IsOwnerOrModerator(BasePermission):
    """Allow owner of object or platform moderator"""
    def has_object_permission(self, request, view, obj):
        if request.user.has_role_permission('moderate_content'):
            return True
        if hasattr(obj, 'author'):
            return obj.author == request.user
        if hasattr(obj, 'user'):
            return obj.user == request.user
        return False


class IsGroupAdmin(BasePermission):
    """Check if user is admin of the group in context"""
    message = 'Group admin permission required.'

    def has_permission(self, request, view):
        group_id = view.kwargs.get('group_id') or request.data.get('group_id')
        if not group_id:
            return False
        from apps.groups.models_and_views import GroupMember
        return GroupMember.objects.filter(
            group_id=group_id,
            user=request.user,
            role__in=['owner', 'super_admin', 'admin'],
            status='active'
        ).exists()


class IsPlatformAdmin(BasePermission):
    message = 'Platform administrator access required.'

    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.is_admin


class IsSuperAdmin(BasePermission):
    message = 'Super administrator access required.'

    def has_permission(self, request, view):
        return (request.user.is_authenticated and
                request.user.role == 'super_admin')


# ═══════════════════════════════════════════════════════════════════════════════
# PAGINATION
# ═══════════════════════════════════════════════════════════════════════════════

class StandardResultsSetPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100

    def get_paginated_response(self, data):
        return Response({
            'success': True,
            'count': self.page.paginator.count,
            'total_pages': self.page.paginator.num_pages,
            'next': self.get_next_link(),
            'previous': self.get_previous_link(),
            'results': data,
        })


# ═══════════════════════════════════════════════════════════════════════════════
# EXCEPTION HANDLER
# ═══════════════════════════════════════════════════════════════════════════════

def custom_exception_handler(exc, context):
    response = exception_handler(exc, context)

    if response is not None:
        error_data = {
            'success': False,
            'status_code': response.status_code,
        }

        if isinstance(response.data, dict):
            error_data['message'] = response.data.get('detail', 'An error occurred.')
            error_data['errors'] = {k: v for k, v in response.data.items() if k != 'detail'}
        else:
            error_data['message'] = str(response.data)

        if isinstance(exc, Throttled):
            error_data['message'] = f'Request limit exceeded. Retry after {exc.wait} seconds.'
            error_data['retry_after'] = exc.wait

        response.data = error_data

    return response


# ═══════════════════════════════════════════════════════════════════════════════
# PASSWORD VALIDATOR
# ═══════════════════════════════════════════════════════════════════════════════

class ApcPasswordValidator:
    """Custom password validator - requires uppercase, lowercase, number, special char"""

    def validate(self, password, user=None):
        from django.core.exceptions import ValidationError
        errors = []
        if not any(c.isupper() for c in password):
            errors.append('Password must contain at least one uppercase letter.')
        if not any(c.islower() for c in password):
            errors.append('Password must contain at least one lowercase letter.')
        if not any(c.isdigit() for c in password):
            errors.append('Password must contain at least one number.')
        if not any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?' for c in password):
            errors.append('Password must contain at least one special character.')
        if errors:
            raise ValidationError(errors)

    def get_help_text(self):
        return 'Must contain uppercase, lowercase, number, and special character.'


# ═══════════════════════════════════════════════════════════════════════════════
# DATABASE ROUTER
# ═══════════════════════════════════════════════════════════════════════════════

class AnalyticsRouter:
    """Route analytics models to separate database"""

    ANALYTICS_APPS = ['analytics']

    def db_for_read(self, model, **hints):
        if model._meta.app_label in self.ANALYTICS_APPS:
            return 'analytics'
        return 'default'

    def db_for_write(self, model, **hints):
        if model._meta.app_label in self.ANALYTICS_APPS:
            return 'analytics'
        return 'default'

    def allow_relation(self, obj1, obj2, **hints):
        return True

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        if app_label in self.ANALYTICS_APPS:
            return db == 'analytics'
        return db == 'default'
