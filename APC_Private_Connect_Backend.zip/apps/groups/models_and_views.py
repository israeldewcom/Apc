"""
APC Private Connect - Groups Service
Group creation, management, roles, permissions, admin fingerprint verification
"""

import uuid
import logging
from django.db import models
from django.utils import timezone
from django.core.cache import cache
from django.db.models import F

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, JSONParser

from apps.users.models import User
from core.utils.audit import AuditLogger
from core.permissions import IsVerifiedMember, IsGroupAdmin

logger = logging.getLogger('apc.api')
audit_logger = AuditLogger()


# ═══════════════════════════════════════════════════════════════════════════════
# MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class Group(models.Model):
    """APC Platform Groups - equivalent to Facebook Groups"""

    class GroupType(models.TextChoices):
        NATIONAL = 'national', 'National Group'
        STATE = 'state', 'State Group'
        LGA = 'lga', 'LGA Group'
        WARD = 'ward', 'Ward Group'
        CAMPAIGN = 'campaign', 'Campaign Group'
        COMMITTEE = 'committee', 'Committee'
        CAUCUS = 'caucus', 'Caucus'
        TASK_FORCE = 'task_force', 'Task Force'
        INTEREST = 'interest', 'Interest Group'
        YOUTH = 'youth', 'Youth Wing'
        WOMEN = 'women', "Women's Wing"
        MEDIA = 'media', 'Media Team'

    class Privacy(models.TextChoices):
        PUBLIC = 'public', 'Public - Anyone can see and join'
        PRIVATE = 'private', 'Private - Invite only'
        SECRET = 'secret', 'Secret - Hidden from search'

    class JoinApproval(models.TextChoices):
        AUTO = 'auto', 'Auto Approve'
        ADMIN_APPROVAL = 'admin_approval', 'Admin Approval Required'
        INVITE_ONLY = 'invite_only', 'Invite Only'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255, db_index=True)
    slug = models.SlugField(max_length=255, unique=True)
    description = models.TextField(max_length=2000, blank=True)
    rules = models.TextField(blank=True)

    group_type = models.CharField(max_length=30, choices=GroupType.choices, default=GroupType.INTEREST)
    privacy = models.CharField(max_length=20, choices=Privacy.choices, default=Privacy.PRIVATE)
    join_approval = models.CharField(
        max_length=20, choices=JoinApproval.choices, default=JoinApproval.ADMIN_APPROVAL
    )

    # Media
    cover_image = models.ImageField(upload_to='groups/covers/', null=True, blank=True)
    avatar = models.ImageField(upload_to='groups/avatars/', null=True, blank=True)

    # Leadership
    creator = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_groups')

    # Location context
    state = models.CharField(max_length=100, blank=True)
    lga = models.CharField(max_length=100, blank=True)
    ward = models.CharField(max_length=100, blank=True)

    # Settings
    is_active = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    require_fingerprint_for_admin = models.BooleanField(default=True)
    allow_member_posts = models.BooleanField(default=True)
    allow_member_invites = models.BooleanField(default=False)
    allow_media = models.BooleanField(default=True)
    post_approval_required = models.BooleanField(default=False)

    # Stats (denormalized)
    members_count = models.PositiveIntegerField(default=0)
    posts_count = models.PositiveIntegerField(default=0)
    active_members_count = models.PositiveIntegerField(default=0)

    # Associated chat room
    chat_room = models.OneToOneField(
        'messaging.ChatRoom', null=True, blank=True, on_delete=models.SET_NULL,
        related_name='group'
    )

    tags = models.JSONField(default=list, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-members_count', '-created_at']
        indexes = [
            models.Index(fields=['privacy', 'is_active']),
            models.Index(fields=['group_type']),
            models.Index(fields=['state', 'lga']),
            models.Index(fields=['-members_count']),
        ]

    def __str__(self):
        return f"{self.name} ({self.group_type})"


class GroupMember(models.Model):
    """Group membership with full role and permission system"""

    class Role(models.TextChoices):
        OWNER = 'owner', 'Owner'
        SUPER_ADMIN = 'super_admin', 'Super Admin'
        ADMIN = 'admin', 'Admin'
        MODERATOR = 'moderator', 'Moderator'
        SPEAKER = 'speaker', 'Speaker'
        MEMBER = 'member', 'Member'
        OBSERVER = 'observer', 'Observer (Read Only)'

    class Status(models.TextChoices):
        ACTIVE = 'active', 'Active'
        PENDING = 'pending', 'Pending Approval'
        SUSPENDED = 'suspended', 'Suspended'
        BANNED = 'banned', 'Banned'
        LEFT = 'left', 'Left Group'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name='members')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='group_memberships')
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.MEMBER)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.ACTIVE)

    # Invitation tracking
    invited_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name='group_invites'
    )
    invite_message = models.TextField(blank=True)
    join_request_message = models.TextField(blank=True)

    # Activity
    last_activity = models.DateTimeField(null=True, blank=True)
    posts_count = models.PositiveIntegerField(default=0)
    comments_count = models.PositiveIntegerField(default=0)

    # Moderation
    suspension_reason = models.TextField(blank=True)
    suspended_until = models.DateTimeField(null=True, blank=True)
    suspended_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name='group_suspensions'
    )

    # Custom permissions
    custom_permissions = models.JSONField(default=dict, blank=True)

    joined_at = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    left_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = ['group', 'user']
        indexes = [
            models.Index(fields=['group', 'role', 'status']),
            models.Index(fields=['user', 'status']),
            models.Index(fields=['group', 'status']),
        ]

    def __str__(self):
        return f"{self.user.username} in {self.group.name} ({self.role})"

    def has_permission(self, permission):
        role_permissions = {
            'owner': ['*'],
            'super_admin': ['manage_members', 'edit_group', 'delete_posts', 'pin_posts',
                           'manage_admins', 'view_analytics'],
            'admin': ['manage_members', 'edit_group', 'delete_posts', 'pin_posts', 'approve_posts'],
            'moderator': ['delete_posts', 'approve_posts', 'suspend_member'],
            'speaker': ['post', 'comment', 'upload_media'],
            'member': ['post', 'comment'],
            'observer': ['view'],
        }
        perms = role_permissions.get(self.role, [])
        if '*' in perms:
            return True
        if permission in perms:
            return True
        return self.custom_permissions.get(permission, False)


class GroupInvitation(models.Model):
    """Group invitation management"""

    class Status(models.TextChoices):
        PENDING = 'pending', 'Pending'
        ACCEPTED = 'accepted', 'Accepted'
        DECLINED = 'declined', 'Declined'
        EXPIRED = 'expired', 'Expired'
        REVOKED = 'revoked', 'Revoked'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name='invitations')
    inviter = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_invitations')
    invitee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_invitations')
    role = models.CharField(max_length=20, choices=GroupMember.Role.choices, default=GroupMember.Role.MEMBER)
    message = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    expires_at = models.DateTimeField()
    responded_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['group', 'invitee']
        ordering = ['-created_at']


class GroupAnnouncement(models.Model):
    """Pinned announcements from group admins"""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name='announcements')
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=300)
    content = models.TextField()
    is_pinned = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-is_pinned', '-created_at']


class GroupDocument(models.Model):
    """Shared documents within a group"""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name='documents')
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='groups/documents/')
    file_name = models.CharField(max_length=255)
    file_size = models.PositiveBigIntegerField()
    mime_type = models.CharField(max_length=100)
    download_count = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']


class GroupPoll(models.Model):
    """Polls specific to groups"""
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name='polls')
    creator = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    question = models.CharField(max_length=500)
    options = models.JSONField(default=list)
    allow_multiple = models.BooleanField(default=False)
    closes_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


# ═══════════════════════════════════════════════════════════════════════════════
# API VIEWS
# ═══════════════════════════════════════════════════════════════════════════════

class GroupCreateView(APIView):
    """POST /groups/create"""
    permission_classes = [IsAuthenticated, IsVerifiedMember]
    parser_classes = [MultiPartParser, JSONParser]

    def post(self, request):
        name = request.data.get('name', '').strip()
        if not name:
            return Response({'success': False, 'message': 'Group name is required.'}, status=400)

        from django.utils.text import slugify
        slug = slugify(name)
        if Group.objects.filter(slug=slug).exists():
            slug = f"{slug}-{uuid.uuid4().hex[:6]}"

        group = Group.objects.create(
            name=name,
            slug=slug,
            description=request.data.get('description', ''),
            group_type=request.data.get('group_type', Group.GroupType.INTEREST),
            privacy=request.data.get('privacy', Group.Privacy.PRIVATE),
            join_approval=request.data.get('join_approval', Group.JoinApproval.ADMIN_APPROVAL),
            creator=request.user,
            state=request.data.get('state', ''),
            lga=request.data.get('lga', ''),
            ward=request.data.get('ward', ''),
            rules=request.data.get('rules', ''),
            require_fingerprint_for_admin=request.data.get('require_fingerprint', True),
        )

        # Handle avatar/cover
        if 'avatar' in request.FILES:
            group.avatar = request.FILES['avatar']
        if 'cover_image' in request.FILES:
            group.cover_image = request.FILES['cover_image']
        group.save()

        # Add creator as owner
        GroupMember.objects.create(
            group=group,
            user=request.user,
            role=GroupMember.Role.OWNER,
            status=GroupMember.Status.ACTIVE,
            approved_at=timezone.now()
        )
        Group.objects.filter(id=group.id).update(members_count=1)

        # Create associated chat room
        from apps.messaging.models_and_views import ChatRoom, RoomParticipant
        chat_room = ChatRoom.objects.create(
            room_type=ChatRoom.RoomType.GROUP,
            name=f"{name} Chat",
            creator=request.user,
        )
        RoomParticipant.objects.create(room=chat_room, user=request.user, role='owner')
        group.chat_room = chat_room
        group.save(update_fields=['chat_room'])

        audit_logger.log(action='GROUP_CREATED', user=request.user, details={'group_id': str(group.id)})

        return Response({
            'success': True,
            'group': {
                'id': str(group.id),
                'name': group.name,
                'slug': group.slug,
                'type': group.group_type,
                'chat_room_id': str(chat_room.id),
            }
        }, status=201)


class GroupDetailView(APIView):
    """GET /groups/<group_id> - Get group details"""
    permission_classes = [IsAuthenticated]

    def get(self, request, group_id):
        try:
            group = Group.objects.get(id=group_id, is_active=True)
        except Group.DoesNotExist:
            return Response({'success': False, 'message': 'Group not found.'}, status=404)

        # Check access for private/secret groups
        is_member = GroupMember.objects.filter(
            group=group, user=request.user, status='active'
        ).exists()

        if group.privacy == Group.Privacy.SECRET and not is_member:
            return Response({'success': False, 'message': 'Group not found.'}, status=404)

        my_membership = None
        if is_member:
            my_membership = GroupMember.objects.get(group=group, user=request.user, status='active')

        data = {
            'id': str(group.id),
            'name': group.name,
            'slug': group.slug,
            'description': group.description,
            'rules': group.rules,
            'type': group.group_type,
            'privacy': group.privacy,
            'members_count': group.members_count,
            'posts_count': group.posts_count,
            'is_featured': group.is_featured,
            'is_verified': group.is_verified,
            'state': group.state,
            'lga': group.lga,
            'created_at': group.created_at.isoformat(),
            'is_member': is_member,
            'my_role': my_membership.role if my_membership else None,
            'chat_room_id': str(group.chat_room.id) if group.chat_room else None,
        }

        return Response({'success': True, 'group': data})


class GroupJoinView(APIView):
    """POST /groups/<group_id>/join"""
    permission_classes = [IsAuthenticated, IsVerifiedMember]

    def post(self, request, group_id):
        try:
            group = Group.objects.get(id=group_id, is_active=True)
        except Group.DoesNotExist:
            return Response({'success': False, 'message': 'Group not found.'}, status=404)

        if group.privacy == Group.Privacy.SECRET:
            return Response({'success': False, 'message': 'This is an invite-only group.'}, status=403)

        existing = GroupMember.objects.filter(group=group, user=request.user).first()
        if existing:
            if existing.status == 'active':
                return Response({'success': False, 'message': 'Already a member.'})
            elif existing.status == 'banned':
                return Response({'success': False, 'message': 'You are banned from this group.'}, status=403)
            elif existing.status == 'pending':
                return Response({'success': True, 'message': 'Join request already pending.'})

        if group.join_approval == Group.JoinApproval.AUTO:
            member = GroupMember.objects.create(
                group=group, user=request.user,
                role=GroupMember.Role.MEMBER,
                status=GroupMember.Status.ACTIVE,
                join_request_message=request.data.get('message', ''),
                approved_at=timezone.now()
            )
            Group.objects.filter(id=group_id).update(members_count=F('members_count') + 1)

            # Add to group chat
            if group.chat_room:
                from apps.messaging.models_and_views import RoomParticipant
                RoomParticipant.objects.get_or_create(
                    room=group.chat_room, user=request.user,
                    defaults={'role': 'member'}
                )

            audit_logger.log(action='GROUP_JOINED', user=request.user, details={'group_id': group_id})
            return Response({'success': True, 'status': 'joined', 'message': 'Joined group successfully.'})

        else:
            GroupMember.objects.create(
                group=group, user=request.user,
                role=GroupMember.Role.MEMBER,
                status=GroupMember.Status.PENDING,
                join_request_message=request.data.get('message', ''),
            )
            # Notify group admins
            from infrastructure.celery_tasks.notifications import notify_group_admins_join_request
            notify_group_admins_join_request.delay(str(group_id), str(request.user.id))

            return Response({'success': True, 'status': 'pending', 'message': 'Join request submitted.'})


class GroupMemberManageView(APIView):
    """POST /groups/<group_id>/members/manage - Admin actions on members"""
    permission_classes = [IsAuthenticated]

    def post(self, request, group_id):
        action = request.data.get('action')
        target_user_id = request.data.get('user_id')

        try:
            group = Group.objects.get(id=group_id)
            admin_membership = GroupMember.objects.get(group=group, user=request.user, status='active')
        except (Group.DoesNotExist, GroupMember.DoesNotExist):
            return Response({'success': False, 'message': 'Access denied.'}, status=403)

        # Check fingerprint for admin actions
        if group.require_fingerprint_for_admin and admin_membership.role in ['owner', 'admin', 'super_admin']:
            fingerprint_token = request.headers.get('X-Fingerprint-Token')
            if not fingerprint_token or not self._verify_fingerprint_token(fingerprint_token, request.user):
                return Response({
                    'success': False,
                    'message': 'Fingerprint verification required for admin actions.',
                    'requires_fingerprint': True
                }, status=403)

        try:
            target_user = User.objects.get(id=target_user_id)
            target_membership = GroupMember.objects.get(group=group, user=target_user)
        except (User.DoesNotExist, GroupMember.DoesNotExist):
            return Response({'success': False, 'message': 'Member not found.'}, status=404)

        if action == 'approve':
            if not admin_membership.has_permission('manage_members'):
                return Response({'success': False, 'message': 'Insufficient permissions.'}, status=403)
            target_membership.status = GroupMember.Status.ACTIVE
            target_membership.approved_at = timezone.now()
            target_membership.save()
            Group.objects.filter(id=group_id).update(members_count=F('members_count') + 1)

        elif action == 'remove':
            if not admin_membership.has_permission('manage_members'):
                return Response({'success': False, 'message': 'Insufficient permissions.'}, status=403)
            target_membership.status = GroupMember.Status.LEFT
            target_membership.left_at = timezone.now()
            target_membership.save()
            Group.objects.filter(id=group_id).update(members_count=F('members_count') - 1)

        elif action == 'suspend':
            target_membership.status = GroupMember.Status.SUSPENDED
            target_membership.suspension_reason = request.data.get('reason', '')
            target_membership.suspended_until = request.data.get('until')
            target_membership.suspended_by = request.user
            target_membership.save()

        elif action == 'ban':
            target_membership.status = GroupMember.Status.BANNED
            target_membership.suspension_reason = request.data.get('reason', '')
            target_membership.suspended_by = request.user
            target_membership.save()
            Group.objects.filter(id=group_id).update(members_count=F('members_count') - 1)

        elif action == 'promote':
            new_role = request.data.get('role', GroupMember.Role.MODERATOR)
            if admin_membership.role not in ['owner', 'super_admin']:
                return Response({'success': False, 'message': 'Only owners can promote admins.'}, status=403)
            target_membership.role = new_role
            target_membership.save()

        else:
            return Response({'success': False, 'message': f'Unknown action: {action}'}, status=400)

        audit_logger.log(
            action=f'GROUP_MEMBER_{action.upper()}',
            user=request.user,
            details={'group_id': group_id, 'target_user': target_user_id, 'action': action}
        )

        return Response({'success': True, 'message': f'Action {action} completed.'})

    def _verify_fingerprint_token(self, token, user):
        """Verify a short-lived fingerprint token from cache"""
        cached_user_id = cache.get(f'fp_token_{token}')
        return cached_user_id == str(user.id)


class GroupMemberListView(APIView):
    """GET /groups/<group_id>/members"""
    permission_classes = [IsAuthenticated]

    def get(self, request, group_id):
        try:
            group = Group.objects.get(id=group_id)
        except Group.DoesNotExist:
            return Response({'success': False, 'message': 'Group not found.'}, status=404)

        role = request.query_params.get('role')
        search = request.query_params.get('search')
        page = int(request.query_params.get('page', 1))
        size = min(int(request.query_params.get('size', 20)), 100)

        qs = GroupMember.objects.filter(
            group=group, status='active'
        ).select_related('user', 'user__profile').order_by('role', '-joined_at')

        if role:
            qs = qs.filter(role=role)
        if search:
            qs = qs.filter(
                models.Q(user__first_name__icontains=search) |
                models.Q(user__last_name__icontains=search) |
                models.Q(user__username__icontains=search)
            )

        total = qs.count()
        members = qs[(page-1)*size:page*size]

        return Response({
            'success': True,
            'total': total,
            'page': page,
            'members': [{
                'id': str(m.id),
                'user_id': str(m.user.id),
                'username': m.user.username,
                'full_name': m.user.get_full_name(),
                'role': m.role,
                'is_verified': m.user.is_verified,
                'state': m.user.state,
                'lga': m.user.lga,
                'joined_at': m.joined_at.isoformat(),
                'last_activity': m.last_activity.isoformat() if m.last_activity else None,
            } for m in members]
        })


class GroupListView(APIView):
    """GET /groups - List/discover groups"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        group_type = request.query_params.get('type')
        state = request.query_params.get('state')
        search = request.query_params.get('search')
        my_groups = request.query_params.get('my_groups', 'false').lower() == 'true'
        page = int(request.query_params.get('page', 1))
        size = min(int(request.query_params.get('size', 20)), 50)

        if my_groups:
            qs = Group.objects.filter(
                members__user=request.user,
                members__status='active',
                is_active=True
            )
        else:
            qs = Group.objects.filter(
                is_active=True,
                privacy__in=[Group.Privacy.PUBLIC, Group.Privacy.PRIVATE]
            )

        if group_type:
            qs = qs.filter(group_type=group_type)
        if state:
            qs = qs.filter(state=state)
        if search:
            qs = qs.filter(
                models.Q(name__icontains=search) |
                models.Q(description__icontains=search)
            )

        qs = qs.order_by('-is_featured', '-members_count').distinct()
        total = qs.count()
        groups = qs[(page-1)*size:page*size]

        return Response({
            'success': True,
            'total': total,
            'page': page,
            'groups': [{
                'id': str(g.id),
                'name': g.name,
                'slug': g.slug,
                'description': g.description[:200],
                'type': g.group_type,
                'privacy': g.privacy,
                'members_count': g.members_count,
                'is_verified': g.is_verified,
                'is_featured': g.is_featured,
                'state': g.state,
                'is_member': GroupMember.objects.filter(
                    group=g, user=request.user, status='active'
                ).exists(),
            } for g in groups]
        })
