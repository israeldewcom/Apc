"""
APC Private Connect - Meetings Service
Video conferencing like Zoom: scheduling, WebRTC, recording, participants
"""

import uuid
import secrets
import logging
from datetime import timedelta

from django.db import models
from django.utils import timezone
from django.core.cache import cache
from django.db.models import F

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async

from apps.users.models import User
from core.utils.audit import AuditLogger
from core.permissions import IsVerifiedMember

logger = logging.getLogger('apc.api')
audit_logger = AuditLogger()


# ═══════════════════════════════════════════════════════════════════════════════
# MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class Meeting(models.Model):
    """Meeting model - supports instant and scheduled meetings"""

    class MeetingType(models.TextChoices):
        INSTANT = 'instant', 'Instant Meeting'
        SCHEDULED = 'scheduled', 'Scheduled Meeting'
        RECURRING = 'recurring', 'Recurring Meeting'
        WEBINAR = 'webinar', 'Webinar'
        TOWN_HALL = 'town_hall', 'Town Hall'
        CAMPAIGN_RALLY = 'campaign_rally', 'Campaign Rally'
        COMMITTEE = 'committee', 'Committee Meeting'

    class Status(models.TextChoices):
        SCHEDULED = 'scheduled', 'Scheduled'
        WAITING = 'waiting', 'Waiting (Not Started)'
        ACTIVE = 'active', 'Active (In Progress)'
        ENDED = 'ended', 'Ended'
        CANCELLED = 'cancelled', 'Cancelled'

    class RecordingStatus(models.TextChoices):
        NOT_RECORDING = 'not_recording', 'Not Recording'
        RECORDING = 'recording', 'Recording'
        PROCESSING = 'processing', 'Processing Recording'
        READY = 'ready', 'Recording Ready'
        FAILED = 'failed', 'Recording Failed'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    meeting_id = models.CharField(max_length=20, unique=True, db_index=True)
    passcode = models.CharField(max_length=20, blank=True)
    title = models.CharField(max_length=300)
    description = models.TextField(blank=True)
    agenda = models.TextField(blank=True)

    meeting_type = models.CharField(max_length=20, choices=MeetingType.choices, default=MeetingType.INSTANT)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.WAITING)
    recording_status = models.CharField(
        max_length=20, choices=RecordingStatus.choices, default=RecordingStatus.NOT_RECORDING
    )

    # Host
    host = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='hosted_meetings')
    co_hosts = models.ManyToManyField(User, related_name='co_hosted_meetings', blank=True)
    group = models.ForeignKey(
        'groups.Group', null=True, blank=True, on_delete=models.SET_NULL, related_name='meetings'
    )

    # Timing
    scheduled_at = models.DateTimeField(null=True, blank=True)
    duration_minutes = models.PositiveIntegerField(default=60)
    started_at = models.DateTimeField(null=True, blank=True)
    ended_at = models.DateTimeField(null=True, blank=True)
    actual_duration_minutes = models.PositiveIntegerField(null=True, blank=True)

    # Settings
    max_participants = models.PositiveIntegerField(default=500)
    waiting_room_enabled = models.BooleanField(default=True)
    require_registration = models.BooleanField(default=False)
    allow_join_before_host = models.BooleanField(default=False)
    mute_on_entry = models.BooleanField(default=True)
    disable_video_on_entry = models.BooleanField(default=False)
    screen_sharing_enabled = models.BooleanField(default=True)
    chat_enabled = models.BooleanField(default=True)
    recording_enabled = models.BooleanField(default=True)
    auto_recording = models.BooleanField(default=False)
    require_password = models.BooleanField(default=True)
    raise_hand_enabled = models.BooleanField(default=True)
    only_host_can_share = models.BooleanField(default=False)

    # Stats
    participant_count = models.PositiveIntegerField(default=0)
    peak_participants = models.PositiveIntegerField(default=0)
    total_attendees = models.PositiveIntegerField(default=0)

    # Recording
    recording_url = models.URLField(blank=True)
    recording_size_mb = models.FloatField(null=True, blank=True)

    # Join links
    join_url = models.URLField(blank=True)
    host_url = models.URLField(blank=True)

    # Recurrence
    recurrence_rule = models.JSONField(null=True, blank=True)
    parent_meeting = models.ForeignKey(
        'self', null=True, blank=True, on_delete=models.SET_NULL, related_name='recurring_instances'
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-scheduled_at', '-created_at']
        indexes = [
            models.Index(fields=['meeting_id']),
            models.Index(fields=['status']),
            models.Index(fields=['host', '-created_at']),
            models.Index(fields=['scheduled_at']),
        ]

    def __str__(self):
        return f"{self.title} ({self.meeting_id})"

    def generate_meeting_id(self):
        return f"{secrets.randbelow(9000) + 1000}-{secrets.randbelow(9000) + 1000}-{secrets.randbelow(9000) + 1000}"

    def generate_join_url(self):
        return f"https://meet.apcconnect.ng/j/{self.meeting_id}"

    def generate_host_url(self):
        return f"https://meet.apcconnect.ng/s/{self.meeting_id}?tk={secrets.token_urlsafe(16)}"

    @property
    def is_active(self):
        return self.status == self.Status.ACTIVE

    @property
    def duration_actual(self):
        if self.started_at and self.ended_at:
            return int((self.ended_at - self.started_at).total_seconds() / 60)
        return None


class MeetingParticipant(models.Model):
    """Track all meeting participants"""

    class Role(models.TextChoices):
        HOST = 'host', 'Host'
        CO_HOST = 'co_host', 'Co-Host'
        PANELIST = 'panelist', 'Panelist'
        ATTENDEE = 'attendee', 'Attendee'
        OBSERVER = 'observer', 'Observer'

    class Status(models.TextChoices):
        IN_MEETING = 'in_meeting', 'In Meeting'
        WAITING = 'waiting', 'In Waiting Room'
        LEFT = 'left', 'Left Meeting'
        REMOVED = 'removed', 'Removed by Host'
        ADMITTED = 'admitted', 'Admitted'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE, related_name='participants')
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='meeting_participations')
    display_name = models.CharField(max_length=200)
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.ATTENDEE)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.WAITING)

    # Connection details
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    device_type = models.CharField(max_length=50, blank=True)
    connection_quality = models.CharField(max_length=20, blank=True)

    # A/V status
    is_muted = models.BooleanField(default=True)
    video_enabled = models.BooleanField(default=False)
    screen_sharing = models.BooleanField(default=False)
    hand_raised = models.BooleanField(default=False)

    # Stats
    join_time = models.DateTimeField(null=True, blank=True)
    leave_time = models.DateTimeField(null=True, blank=True)
    duration_seconds = models.PositiveIntegerField(default=0)
    reconnect_count = models.PositiveSmallIntegerField(default=0)

    # Attendance confirmation
    attendance_confirmed = models.BooleanField(default=False)
    attention_score = models.FloatField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['join_time']
        indexes = [
            models.Index(fields=['meeting', 'status']),
            models.Index(fields=['user', 'meeting']),
        ]


class MeetingRegistration(models.Model):
    """Pre-registration for scheduled meetings"""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE, related_name='registrations')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True)
    questions_answered = models.JSONField(default=dict)
    is_approved = models.BooleanField(default=True)
    join_token = models.CharField(max_length=64, unique=True)
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['meeting', 'user']


class MeetingRecording(models.Model):
    """Meeting recording management"""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE, related_name='recordings')
    file_url = models.URLField()
    file_size_mb = models.FloatField()
    duration_seconds = models.PositiveIntegerField()
    format = models.CharField(max_length=20, default='mp4')
    started_at = models.DateTimeField()
    ended_at = models.DateTimeField()
    is_public = models.BooleanField(default=False)
    access_token = models.CharField(max_length=64, blank=True)
    download_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)


class MeetingChat(models.Model):
    """In-meeting chat messages"""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE, related_name='chat_messages')
    sender = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    content = models.TextField()
    is_to_everyone = models.BooleanField(default=True)
    recipient = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='+')
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['timestamp']


# ═══════════════════════════════════════════════════════════════════════════════
# WEBRTC SIGNALING CONSUMER
# ═══════════════════════════════════════════════════════════════════════════════

class MeetingSignalingConsumer(AsyncWebsocketConsumer):
    """
    WebRTC signaling server for meeting video calls
    Handles: SDP offer/answer, ICE candidates, participant control
    """

    async def connect(self):
        self.meeting_id = self.scope['url_route']['kwargs']['meeting_id']
        self.room_group = f'meeting_{self.meeting_id}'
        self.user = self.scope['user']

        if not self.user.is_authenticated:
            await self.close()
            return

        is_participant = await self._check_participant()
        if not is_participant:
            await self.close()
            return

        await self.channel_layer.group_add(self.room_group, self.channel_name)
        await self.accept()

        # Join meeting
        await self._join_meeting()

        # Notify others of new participant
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'participant_joined',
                'user_id': str(self.user.id),
                'display_name': self.user.get_full_name(),
                'role': await self._get_user_role(),
            }
        )

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.room_group, self.channel_name)
        await self._leave_meeting()

        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'participant_left',
                'user_id': str(self.user.id),
                'display_name': self.user.get_full_name(),
            }
        )

    async def receive(self, text_data):
        import json
        data = json.loads(text_data)
        event_type = data.get('type')

        handlers = {
            'offer': self._handle_webrtc_offer,
            'answer': self._handle_webrtc_answer,
            'ice_candidate': self._handle_ice_candidate,
            'mute': self._handle_mute_toggle,
            'video': self._handle_video_toggle,
            'screen_share': self._handle_screen_share,
            'raise_hand': self._handle_raise_hand,
            'chat': self._handle_chat_message,
            'remove_participant': self._handle_remove_participant,
            'mute_all': self._handle_mute_all,
            'end_meeting': self._handle_end_meeting,
            'start_recording': self._handle_start_recording,
            'stop_recording': self._handle_stop_recording,
        }

        handler = handlers.get(event_type)
        if handler:
            await handler(data)

    async def _handle_webrtc_offer(self, data):
        """Forward WebRTC offer to target peer"""
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'webrtc_signal',
                'signal_type': 'offer',
                'from_user': str(self.user.id),
                'to_user': data.get('to_user'),
                'sdp': data.get('sdp'),
            }
        )

    async def _handle_webrtc_answer(self, data):
        """Forward WebRTC answer to target peer"""
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'webrtc_signal',
                'signal_type': 'answer',
                'from_user': str(self.user.id),
                'to_user': data.get('to_user'),
                'sdp': data.get('sdp'),
            }
        )

    async def _handle_ice_candidate(self, data):
        """Forward ICE candidate to target peer"""
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'webrtc_signal',
                'signal_type': 'ice_candidate',
                'from_user': str(self.user.id),
                'to_user': data.get('to_user'),
                'candidate': data.get('candidate'),
            }
        )

    async def _handle_mute_toggle(self, data):
        is_muted = data.get('muted', True)
        await self._update_participant_status(muted=is_muted)
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'participant_status_update',
                'user_id': str(self.user.id),
                'muted': is_muted,
            }
        )

    async def _handle_video_toggle(self, data):
        video_enabled = data.get('enabled', False)
        await self._update_participant_status(video_enabled=video_enabled)
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'participant_status_update',
                'user_id': str(self.user.id),
                'video_enabled': video_enabled,
            }
        )

    async def _handle_screen_share(self, data):
        sharing = data.get('sharing', False)
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'screen_share_status',
                'user_id': str(self.user.id),
                'sharing': sharing,
            }
        )

    async def _handle_raise_hand(self, data):
        raised = data.get('raised', True)
        await self._update_participant_status(hand_raised=raised)
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'hand_raise',
                'user_id': str(self.user.id),
                'raised': raised,
            }
        )

    async def _handle_chat_message(self, data):
        content = data.get('content', '').strip()
        if not content:
            return
        await self._save_chat_message(content)
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'meeting_chat',
                'user_id': str(self.user.id),
                'display_name': self.user.get_full_name(),
                'content': content,
                'timestamp': timezone.now().isoformat(),
            }
        )

    async def _handle_remove_participant(self, data):
        if not await self._is_host_or_cohost():
            return
        target_id = data.get('user_id')
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'participant_removed',
                'user_id': target_id,
                'removed_by': str(self.user.id),
            }
        )

    async def _handle_mute_all(self, data):
        if not await self._is_host_or_cohost():
            return
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'mute_all',
                'by_host': str(self.user.id),
            }
        )

    async def _handle_end_meeting(self, data):
        if not await self._is_host():
            return
        await self._end_meeting()
        await self.channel_layer.group_send(
            self.room_group,
            {
                'type': 'meeting_ended',
                'ended_by': str(self.user.id),
                'timestamp': timezone.now().isoformat(),
            }
        )

    async def _handle_start_recording(self, data):
        if not await self._is_host_or_cohost():
            return
        await self._update_recording_status('recording')
        await self.channel_layer.group_send(
            self.room_group,
            {'type': 'recording_started', 'by': str(self.user.id)}
        )

    async def _handle_stop_recording(self, data):
        if not await self._is_host_or_cohost():
            return
        await self._update_recording_status('processing')
        await self.channel_layer.group_send(
            self.room_group,
            {'type': 'recording_stopped', 'by': str(self.user.id)}
        )

    # ─── Channel layer message handlers ─────────────────────────────────────
    async def webrtc_signal(self, event):
        import json
        to_user = event.get('to_user')
        if not to_user or to_user == str(self.user.id):
            await self.send(text_data=json.dumps({'type': 'webrtc_signal', **event}))

    async def participant_joined(self, event):
        import json
        await self.send(text_data=json.dumps({'type': 'participant_joined', **event}))

    async def participant_left(self, event):
        import json
        await self.send(text_data=json.dumps({'type': 'participant_left', **event}))

    async def participant_status_update(self, event):
        import json
        await self.send(text_data=json.dumps({'type': 'status_update', **event}))

    async def meeting_chat(self, event):
        import json
        await self.send(text_data=json.dumps({'type': 'chat', **event}))

    async def meeting_ended(self, event):
        import json
        await self.send(text_data=json.dumps({'type': 'meeting_ended', **event}))

    async def participant_removed(self, event):
        import json
        if event.get('user_id') == str(self.user.id):
            await self.send(text_data=json.dumps({'type': 'removed_from_meeting'}))
            await self.close()

    async def mute_all(self, event):
        import json
        await self.send(text_data=json.dumps({'type': 'mute_all'}))

    async def screen_share_status(self, event):
        import json
        await self.send(text_data=json.dumps({'type': 'screen_share', **event}))

    async def hand_raise(self, event):
        import json
        await self.send(text_data=json.dumps({'type': 'hand_raise', **event}))

    # ─── DB helpers ──────────────────────────────────────────────────────────
    @database_sync_to_async
    def _check_participant(self):
        return Meeting.objects.filter(meeting_id=self.meeting_id).exists()

    @database_sync_to_async
    def _get_user_role(self):
        try:
            mtg = Meeting.objects.get(meeting_id=self.meeting_id)
            if mtg.host == self.user:
                return 'host'
            if mtg.co_hosts.filter(id=self.user.id).exists():
                return 'co_host'
            return 'attendee'
        except Meeting.DoesNotExist:
            return 'attendee'

    @database_sync_to_async
    def _join_meeting(self):
        try:
            meeting = Meeting.objects.get(meeting_id=self.meeting_id)
            participant, created = MeetingParticipant.objects.update_or_create(
                meeting=meeting, user=self.user,
                defaults={
                    'display_name': self.user.get_full_name(),
                    'status': MeetingParticipant.Status.IN_MEETING,
                    'join_time': timezone.now(),
                }
            )
            Meeting.objects.filter(id=meeting.id).update(participant_count=F('participant_count') + 1)
        except Meeting.DoesNotExist:
            pass

    @database_sync_to_async
    def _leave_meeting(self):
        try:
            meeting = Meeting.objects.get(meeting_id=self.meeting_id)
            MeetingParticipant.objects.filter(
                meeting=meeting, user=self.user
            ).update(
                status=MeetingParticipant.Status.LEFT,
                leave_time=timezone.now()
            )
            Meeting.objects.filter(id=meeting.id).update(
                participant_count=F('participant_count') - 1
            )
        except Meeting.DoesNotExist:
            pass

    @database_sync_to_async
    def _update_participant_status(self, **kwargs):
        try:
            meeting = Meeting.objects.get(meeting_id=self.meeting_id)
            MeetingParticipant.objects.filter(meeting=meeting, user=self.user).update(**kwargs)
        except Meeting.DoesNotExist:
            pass

    @database_sync_to_async
    def _is_host(self):
        try:
            mtg = Meeting.objects.get(meeting_id=self.meeting_id)
            return mtg.host == self.user
        except:
            return False

    @database_sync_to_async
    def _is_host_or_cohost(self):
        try:
            mtg = Meeting.objects.get(meeting_id=self.meeting_id)
            return mtg.host == self.user or mtg.co_hosts.filter(id=self.user.id).exists()
        except:
            return False

    @database_sync_to_async
    def _end_meeting(self):
        Meeting.objects.filter(meeting_id=self.meeting_id).update(
            status=Meeting.Status.ENDED, ended_at=timezone.now()
        )

    @database_sync_to_async
    def _update_recording_status(self, status):
        Meeting.objects.filter(meeting_id=self.meeting_id).update(recording_status=status)

    @database_sync_to_async
    def _save_chat_message(self, content):
        try:
            meeting = Meeting.objects.get(meeting_id=self.meeting_id)
            MeetingChat.objects.create(meeting=meeting, sender=self.user, content=content)
        except Meeting.DoesNotExist:
            pass


# ═══════════════════════════════════════════════════════════════════════════════
# API VIEWS
# ═══════════════════════════════════════════════════════════════════════════════

class CreateMeetingView(APIView):
    """POST /meetings/create"""
    permission_classes = [IsAuthenticated, IsVerifiedMember]

    def post(self, request):
        title = request.data.get('title', '').strip()
        if not title:
            return Response({'success': False, 'message': 'Meeting title required.'}, status=400)

        meeting = Meeting(
            title=title,
            description=request.data.get('description', ''),
            agenda=request.data.get('agenda', ''),
            meeting_type=request.data.get('meeting_type', Meeting.MeetingType.INSTANT),
            host=request.user,
            duration_minutes=request.data.get('duration', 60),
            max_participants=min(int(request.data.get('max_participants', 100)), 500),
            waiting_room_enabled=request.data.get('waiting_room', True),
            mute_on_entry=request.data.get('mute_on_entry', True),
            recording_enabled=request.data.get('recording', True),
            chat_enabled=request.data.get('chat', True),
            screen_sharing_enabled=request.data.get('screen_sharing', True),
            require_password=request.data.get('require_password', True),
        )
        meeting.meeting_id = meeting.generate_meeting_id()
        meeting.passcode = secrets.randbelow(900000) + 100000 if meeting.require_password else ''
        meeting.join_url = meeting.generate_join_url()
        meeting.host_url = meeting.generate_host_url()

        # Scheduled meeting
        scheduled_at = request.data.get('scheduled_at')
        if scheduled_at:
            meeting.meeting_type = Meeting.MeetingType.SCHEDULED
            meeting.scheduled_at = scheduled_at
            meeting.status = Meeting.Status.SCHEDULED
        else:
            meeting.status = Meeting.Status.WAITING
            meeting.started_at = timezone.now()

        meeting.save()

        # Add host as participant
        MeetingParticipant.objects.create(
            meeting=meeting,
            user=request.user,
            display_name=request.user.get_full_name(),
            role=MeetingParticipant.Role.HOST,
            status=MeetingParticipant.Status.IN_MEETING if not scheduled_at else MeetingParticipant.Status.WAITING,
            join_time=timezone.now() if not scheduled_at else None,
        )

        # Link to group if specified
        group_id = request.data.get('group_id')
        if group_id:
            from apps.groups.models_and_views import Group
            try:
                meeting.group = Group.objects.get(id=group_id)
                meeting.save(update_fields=['group'])
            except Group.DoesNotExist:
                pass

        # Schedule reminder notifications
        if scheduled_at:
            from infrastructure.celery_tasks.meetings import schedule_meeting_reminders
            schedule_meeting_reminders.delay(str(meeting.id))

        audit_logger.log(action='MEETING_CREATED', user=request.user, details={'meeting_id': meeting.meeting_id})

        return Response({
            'success': True,
            'meeting': {
                'id': str(meeting.id),
                'meeting_id': meeting.meeting_id,
                'title': meeting.title,
                'status': meeting.status,
                'join_url': meeting.join_url,
                'host_url': meeting.host_url,
                'passcode': meeting.passcode,
                'scheduled_at': meeting.scheduled_at.isoformat() if meeting.scheduled_at else None,
                'ws_url': f'wss://api.apcconnect.ng/ws/meeting/{meeting.meeting_id}/',
                'stun_servers': [
                    'stun:stun.l.google.com:19302',
                    'stun:stun1.l.google.com:19302',
                ],
                'turn_servers': [{
                    'urls': 'turn:turn.apcconnect.ng:3478',
                    'username': request.user.email,
                    'credential': secrets.token_urlsafe(16),
                }],
            }
        }, status=201)


class JoinMeetingView(APIView):
    """POST /meetings/<meeting_id>/join"""
    permission_classes = [IsAuthenticated]

    def post(self, request, meeting_id):
        try:
            meeting = Meeting.objects.get(meeting_id=meeting_id)
        except Meeting.DoesNotExist:
            return Response({'success': False, 'message': 'Meeting not found.'}, status=404)

        if meeting.status == Meeting.Status.ENDED:
            return Response({'success': False, 'message': 'This meeting has ended.'}, status=400)
        if meeting.status == Meeting.Status.CANCELLED:
            return Response({'success': False, 'message': 'This meeting was cancelled.'}, status=400)

        # Check passcode
        if meeting.require_password:
            passcode = request.data.get('passcode', '')
            if str(passcode) != str(meeting.passcode):
                return Response({'success': False, 'message': 'Incorrect meeting passcode.'}, status=403)

        # Check capacity
        if meeting.participant_count >= meeting.max_participants:
            return Response({'success': False, 'message': 'Meeting is full.'}, status=400)

        # Check allow_join_before_host
        if meeting.status == Meeting.Status.WAITING and not meeting.allow_join_before_host and meeting.host != request.user:
            return Response({
                'success': True,
                'waiting_room': True,
                'message': 'Waiting for host to start the meeting.'
            })

        participant_status = (
            MeetingParticipant.Status.WAITING if meeting.waiting_room_enabled and meeting.host != request.user
            else MeetingParticipant.Status.IN_MEETING
        )

        participant, _ = MeetingParticipant.objects.update_or_create(
            meeting=meeting,
            user=request.user,
            defaults={
                'display_name': request.user.get_full_name(),
                'role': MeetingParticipant.Role.ATTENDEE,
                'status': participant_status,
                'join_time': timezone.now(),
                'is_muted': meeting.mute_on_entry,
                'video_enabled': not meeting.disable_video_on_entry,
                'ip_address': request.META.get('REMOTE_ADDR'),
            }
        )

        Meeting.objects.filter(id=meeting.id).update(
            participant_count=F('participant_count') + 1,
            total_attendees=F('total_attendees') + 1
        )

        audit_logger.log(action='MEETING_JOINED', user=request.user, details={'meeting_id': meeting_id})

        return Response({
            'success': True,
            'meeting': {
                'id': str(meeting.id),
                'meeting_id': meeting.meeting_id,
                'title': meeting.title,
                'host': meeting.host.get_full_name() if meeting.host else '',
                'status': meeting.status,
                'participant_count': meeting.participant_count,
                'waiting_room': participant_status == MeetingParticipant.Status.WAITING,
                'settings': {
                    'muted': meeting.mute_on_entry,
                    'video_on': not meeting.disable_video_on_entry,
                    'chat_enabled': meeting.chat_enabled,
                    'screen_sharing': meeting.screen_sharing_enabled,
                    'recording_active': meeting.recording_status == 'recording',
                    'raise_hand': meeting.raise_hand_enabled,
                },
            },
            'ws_url': f'wss://api.apcconnect.ng/ws/meeting/{meeting_id}/',
            'stun_servers': ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'],
        })


class MeetingListView(APIView):
    """GET /meetings"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        meeting_type = request.query_params.get('type', 'upcoming')
        page = int(request.query_params.get('page', 1))
        size = min(int(request.query_params.get('size', 20)), 50)

        if meeting_type == 'upcoming':
            qs = Meeting.objects.filter(
                models.Q(host=request.user) | models.Q(participants__user=request.user),
                status__in=['scheduled', 'waiting'],
                scheduled_at__gte=timezone.now(),
            )
        elif meeting_type == 'past':
            qs = Meeting.objects.filter(
                models.Q(host=request.user) | models.Q(participants__user=request.user),
                status='ended',
            )
        elif meeting_type == 'active':
            qs = Meeting.objects.filter(status='active')
        else:
            qs = Meeting.objects.filter(host=request.user)

        qs = qs.distinct().order_by('-scheduled_at', '-created_at')
        total = qs.count()
        meetings = qs[(page-1)*size:page*size]

        return Response({
            'success': True,
            'total': total,
            'meetings': [{
                'id': str(m.id),
                'meeting_id': m.meeting_id,
                'title': m.title,
                'type': m.meeting_type,
                'status': m.status,
                'host': m.host.get_full_name() if m.host else '',
                'participant_count': m.participant_count,
                'scheduled_at': m.scheduled_at.isoformat() if m.scheduled_at else None,
                'join_url': m.join_url,
                'duration': m.duration_minutes,
                'has_recording': bool(m.recording_url),
            } for m in meetings]
        })


class MeetingStatsView(APIView):
    """GET /meetings/<meeting_id>/stats"""
    permission_classes = [IsAuthenticated]

    def get(self, request, meeting_id):
        try:
            meeting = Meeting.objects.get(meeting_id=meeting_id, host=request.user)
        except Meeting.DoesNotExist:
            return Response({'success': False, 'message': 'Meeting not found.'}, status=404)

        participants = MeetingParticipant.objects.filter(meeting=meeting)

        return Response({
            'success': True,
            'stats': {
                'total_attendees': meeting.total_attendees,
                'peak_participants': meeting.peak_participants,
                'current_participants': meeting.participant_count,
                'duration_minutes': meeting.duration_actual,
                'recording_available': bool(meeting.recording_url),
                'attendee_list': [{
                    'name': p.display_name,
                    'join_time': p.join_time.isoformat() if p.join_time else None,
                    'leave_time': p.leave_time.isoformat() if p.leave_time else None,
                    'duration': p.duration_seconds // 60,
                    'role': p.role,
                } for p in participants.order_by('join_time')]
            }
        })
