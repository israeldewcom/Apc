"""
APC Private Connect - User Models
Complete user model with all profile, role, and verification fields
"""

import uuid
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.db import models
from django.utils import timezone
from django.core.validators import RegexValidator
from django.utils.translation import gettext_lazy as _


class UserManager(BaseUserManager):
    """Custom user manager for APC platform"""

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('Email address is required')
        email = self.normalize_email(email)
        extra_fields.setdefault('is_active', True)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('role', User.Role.SUPER_ADMIN)
        extra_fields.setdefault('is_verified', True)
        return self.create_user(email, password, **extra_fields)

    def get_verified_members(self):
        return self.filter(is_verified=True, is_active=True)

    def get_by_nin(self, nin_number):
        return self.filter(nin_number=nin_number).first()


class User(AbstractBaseUser, PermissionsMixin):
    """
    Main User model for APC Private Connect Platform.
    Extends Django's AbstractBaseUser for full customization.
    """

    class Role(models.TextChoices):
        SUPER_ADMIN = 'super_admin', _('Super Administrator')
        NATIONAL_ADMIN = 'national_admin', _('National Administrator')
        STATE_ADMIN = 'state_admin', _('State Administrator')
        LGA_ADMIN = 'lga_admin', _('LGA Administrator')
        WARD_ADMIN = 'ward_admin', _('Ward Administrator')
        MODERATOR = 'moderator', _('Moderator')
        VERIFIED_MEMBER = 'verified_member', _('Verified Member')
        DELEGATE = 'delegate', _('Delegate')
        CANDIDATE = 'candidate', _('Candidate')
        OBSERVER = 'observer', _('Observer')
        MEDIA_OFFICER = 'media_officer', _('Media Officer')
        FINANCIAL_OFFICER = 'financial_officer', _('Financial Officer')

    class VerificationStatus(models.TextChoices):
        UNVERIFIED = 'unverified', _('Unverified')
        PENDING = 'pending', _('Pending Verification')
        NIN_VERIFIED = 'nin_verified', _('NIN Verified')
        FINGERPRINT_VERIFIED = 'fingerprint_verified', _('Fingerprint Verified')
        FULLY_VERIFIED = 'fully_verified', _('Fully Verified')
        REJECTED = 'rejected', _('Rejected')
        SUSPENDED = 'suspended', _('Suspended')

    class AccountStatus(models.TextChoices):
        ACTIVE = 'active', _('Active')
        INACTIVE = 'inactive', _('Inactive')
        SUSPENDED = 'suspended', _('Suspended')
        BANNED = 'banned', _('Banned')
        PENDING_REVIEW = 'pending_review', _('Pending Review')

    # ─── Primary Fields ────────────────────────────────────────────────────
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(_('Email Address'), unique=True, db_index=True)
    username = models.CharField(
        _('Username'), max_length=50, unique=True, db_index=True,
        validators=[RegexValidator(r'^[a-zA-Z0-9_]+$', 'Only letters, numbers, underscores')]
    )
    phone_number = models.CharField(
        max_length=15, unique=True, db_index=True, null=True, blank=True,
        validators=[RegexValidator(r'^\+?1?\d{9,15}$', 'Invalid phone number')]
    )

    # ─── Personal Information ──────────────────────────────────────────────
    first_name = models.CharField(_('First Name'), max_length=100)
    last_name = models.CharField(_('Last Name'), max_length=100)
    middle_name = models.CharField(max_length=100, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(
        max_length=20,
        choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other')],
        blank=True
    )
    nationality = models.CharField(max_length=100, default='Nigerian')

    # ─── NIN / Identity ────────────────────────────────────────────────────
    nin_number = models.CharField(
        max_length=11, unique=True, null=True, blank=True, db_index=True,
        validators=[RegexValidator(r'^\d{11}$', 'NIN must be 11 digits')]
    )
    voter_id = models.CharField(max_length=50, null=True, blank=True)
    party_membership_id = models.CharField(max_length=50, null=True, blank=True, unique=True)

    # ─── Location ──────────────────────────────────────────────────────────
    state = models.CharField(max_length=100, blank=True)
    lga = models.CharField(max_length=100, blank=True)
    ward = models.CharField(max_length=100, blank=True)
    polling_unit = models.CharField(max_length=200, blank=True)
    address = models.TextField(blank=True)

    # ─── Role & Permissions ────────────────────────────────────────────────
    role = models.CharField(max_length=30, choices=Role.choices, default=Role.OBSERVER)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)

    # ─── Verification ──────────────────────────────────────────────────────
    is_verified = models.BooleanField(default=False, db_index=True)
    verification_status = models.CharField(
        max_length=30,
        choices=VerificationStatus.choices,
        default=VerificationStatus.UNVERIFIED
    )
    email_verified = models.BooleanField(default=False)
    phone_verified = models.BooleanField(default=False)
    nin_verified = models.BooleanField(default=False)
    fingerprint_enrolled = models.BooleanField(default=False)

    # ─── Account Status ────────────────────────────────────────────────────
    account_status = models.CharField(
        max_length=20, choices=AccountStatus.choices, default=AccountStatus.ACTIVE
    )
    suspension_reason = models.TextField(blank=True)
    suspended_by = models.ForeignKey(
        'self', null=True, blank=True, on_delete=models.SET_NULL,
        related_name='suspended_users'
    )
    suspended_until = models.DateTimeField(null=True, blank=True)

    # ─── 2FA / Security ────────────────────────────────────────────────────
    two_factor_enabled = models.BooleanField(default=False)
    two_factor_secret = models.CharField(max_length=32, blank=True)
    backup_codes = models.JSONField(default=list, blank=True)

    # ─── Timestamps ────────────────────────────────────────────────────────
    date_joined = models.DateTimeField(default=timezone.now)
    last_login = models.DateTimeField(null=True, blank=True)
    last_seen = models.DateTimeField(null=True, blank=True)
    last_active = models.DateTimeField(null=True, blank=True)
    password_changed_at = models.DateTimeField(null=True, blank=True)

    # ─── Privacy Settings ──────────────────────────────────────────────────
    privacy_settings = models.JSONField(default=dict, blank=True)

    # ─── Push Notifications ────────────────────────────────────────────────
    fcm_token = models.TextField(blank=True)
    notification_preferences = models.JSONField(default=dict, blank=True)

    # ─── Profile Stats (denormalized for performance) ─────────────────────
    followers_count = models.PositiveIntegerField(default=0)
    following_count = models.PositiveIntegerField(default=0)
    posts_count = models.PositiveIntegerField(default=0)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name']

    objects = UserManager()

    class Meta:
        verbose_name = _('User')
        verbose_name_plural = _('Users')
        ordering = ['-date_joined']
        indexes = [
            models.Index(fields=['email']),
            models.Index(fields=['username']),
            models.Index(fields=['nin_number']),
            models.Index(fields=['role', 'is_verified']),
            models.Index(fields=['state', 'lga']),
            models.Index(fields=['account_status', 'is_active']),
        ]

    def __str__(self):
        return f"{self.get_full_name()} ({self.email})"

    def get_full_name(self):
        return f"{self.first_name} {self.middle_name} {self.last_name}".strip()

    def get_short_name(self):
        return self.first_name

    @property
    def is_admin(self):
        return self.role in [
            self.Role.SUPER_ADMIN, self.Role.NATIONAL_ADMIN,
            self.Role.STATE_ADMIN, self.Role.LGA_ADMIN, self.Role.WARD_ADMIN
        ]

    @property
    def is_fully_verified(self):
        return self.verification_status == self.VerificationStatus.FULLY_VERIFIED

    @property
    def is_online(self):
        if not self.last_seen:
            return False
        return (timezone.now() - self.last_seen).seconds < 300  # 5 min

    def update_last_seen(self):
        self.last_seen = timezone.now()
        self.save(update_fields=['last_seen'])

    def get_privacy_setting(self, key, default='friends'):
        return self.privacy_settings.get(key, default)

    def has_role_permission(self, permission):
        role_permissions = {
            'super_admin': ['*'],
            'national_admin': ['manage_all', 'view_analytics', 'manage_users', 'manage_groups'],
            'state_admin': ['manage_state', 'view_state_analytics', 'manage_state_users'],
            'lga_admin': ['manage_lga', 'view_lga_analytics'],
            'ward_admin': ['manage_ward'],
            'moderator': ['moderate_content', 'manage_reports'],
            'verified_member': ['post', 'message', 'join_groups', 'join_meetings'],
            'observer': ['view_public'],
        }
        perms = role_permissions.get(self.role, [])
        return '*' in perms or permission in perms


class UserProfile(models.Model):
    """Extended profile information for users"""

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    bio = models.TextField(max_length=500, blank=True)
    profile_picture = models.ImageField(upload_to='profiles/avatars/', null=True, blank=True)
    cover_photo = models.ImageField(upload_to='profiles/covers/', null=True, blank=True)
    designation = models.CharField(max_length=200, blank=True)
    department = models.CharField(max_length=200, blank=True)
    website = models.URLField(blank=True)
    linkedin = models.URLField(blank=True)
    twitter = models.URLField(blank=True)
    facebook = models.URLField(blank=True)

    # Political info
    political_position = models.CharField(max_length=200, blank=True)
    years_in_party = models.PositiveIntegerField(null=True, blank=True)
    constituency = models.CharField(max_length=200, blank=True)
    senatorial_zone = models.CharField(max_length=200, blank=True)

    # Skills and interests
    skills = models.JSONField(default=list, blank=True)
    interests = models.JSONField(default=list, blank=True)

    # Profile completion
    profile_completion = models.PositiveSmallIntegerField(default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Profile: {self.user.get_full_name()}"

    def calculate_completion(self):
        fields = ['bio', 'profile_picture', 'designation', 'phone_number']
        completed = sum(1 for f in fields if getattr(self, f, None))
        user_fields = ['date_of_birth', 'state', 'lga', 'nin_number']
        completed += sum(1 for f in user_fields if getattr(self.user, f, None))
        self.profile_completion = int((completed / (len(fields) + len(user_fields))) * 100)
        self.save(update_fields=['profile_completion'])


class UserDevice(models.Model):
    """Track user devices for security"""

    class DeviceType(models.TextChoices):
        MOBILE = 'mobile', _('Mobile')
        TABLET = 'tablet', _('Tablet')
        DESKTOP = 'desktop', _('Desktop')
        UNKNOWN = 'unknown', _('Unknown')

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='devices')
    device_id = models.CharField(max_length=255, db_index=True)
    device_name = models.CharField(max_length=255, blank=True)
    device_type = models.CharField(max_length=20, choices=DeviceType.choices, default=DeviceType.UNKNOWN)
    os = models.CharField(max_length=100, blank=True)
    os_version = models.CharField(max_length=50, blank=True)
    app_version = models.CharField(max_length=20, blank=True)
    browser = models.CharField(max_length=100, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    location = models.CharField(max_length=200, blank=True)
    is_trusted = models.BooleanField(default=False)
    is_current = models.BooleanField(default=True)
    fcm_token = models.TextField(blank=True)
    last_active = models.DateTimeField(auto_now=True)
    first_seen = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'device_id']
        ordering = ['-last_active']
        indexes = [
            models.Index(fields=['user', 'device_id']),
            models.Index(fields=['user', 'is_current']),
        ]

    def __str__(self):
        return f"{self.user.username} - {self.device_name or self.device_id[:12]}"


class UserFollowing(models.Model):
    """Follow/Follower relationship"""

    follower = models.ForeignKey(User, on_delete=models.CASCADE, related_name='following')
    following = models.ForeignKey(User, on_delete=models.CASCADE, related_name='followers')
    created_at = models.DateTimeField(auto_now_add=True)
    is_close_friend = models.BooleanField(default=False)

    class Meta:
        unique_together = ['follower', 'following']
        indexes = [
            models.Index(fields=['follower']),
            models.Index(fields=['following']),
        ]

    def __str__(self):
        return f"{self.follower.username} follows {self.following.username}"


class UserBlock(models.Model):
    """User blocking system"""

    blocker = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blocking')
    blocked = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blocked_by')
    reason = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['blocker', 'blocked']


class UserReport(models.Model):
    """User reporting system"""

    class ReportReason(models.TextChoices):
        SPAM = 'spam', _('Spam')
        HARASSMENT = 'harassment', _('Harassment')
        FAKE_ACCOUNT = 'fake_account', _('Fake Account')
        INAPPROPRIATE = 'inappropriate', _('Inappropriate Content')
        IMPERSONATION = 'impersonation', _('Impersonation')
        OTHER = 'other', _('Other')

    class Status(models.TextChoices):
        PENDING = 'pending', _('Pending Review')
        REVIEWING = 'reviewing', _('Under Review')
        RESOLVED = 'resolved', _('Resolved')
        DISMISSED = 'dismissed', _('Dismissed')

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reporter = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reports_made')
    reported_user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reports_received')
    reason = models.CharField(max_length=30, choices=ReportReason.choices)
    description = models.TextField()
    evidence_urls = models.JSONField(default=list)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    reviewed_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name='reports_reviewed'
    )
    review_notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
