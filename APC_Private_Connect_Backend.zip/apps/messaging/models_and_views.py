"""
APC Private Connect - Messaging Service
End-to-end encrypted messaging, group chats, media sharing, WebSocket real-time
"""

import uuid
import json
import logging
from datetime import datetime

from django.db import models
from django.utils import timezone
from django.core.cache import cache

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async

from apps.users.models import User
from core.utils.encryption import EncryptionService
from core.utils.audit import AuditLogger

logger = logging.getLogger('apc.api')
audit_logger = AuditLogger()


# ═══════════════════════════════════════════════════════════════════════════════
# MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class ChatRoom(models.Model):
    """Chat room - handles both DMs and group chats"""

    class RoomType(models.TextChoices):
        DIRECT = 'direct', 'Direct Message'
        GROUP = 'group', 'Group Chat'
        CHANNEL = 'channel', 'Channel'
        SUPPORT = 'support', 'Support'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    room_type = models.CharField(max_length=20, choices=RoomType.choices)
    name = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)
    avatar = models.ImageField(upload_to='chats/avatars/', null=True, blank=True)
    creator = models.ForeignKey(
        User, null=True, on_delete=models.SET_NULL, related_name='created_rooms'
    )
    participants = models.ManyToManyField(User, through='RoomParticipant', related_name='chat_rooms')

    # Settings
    is_encrypted = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    max_participants = models.PositiveIntegerField(default=500)
    allow_media = models.BooleanField(default=True)
    allow_links = models.BooleanField(default=True)
    only_admins_can_send = models.BooleanField(default=False)

    # Stats (denormalized)
    message_count = models.PositiveIntegerField(default=0)
    last_message_at = models.DateTimeField(null=True, blank=True)
    last_message_preview = models.CharField(max_length=200, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-last_message_at']
        indexes = [
            models.Index(fields=['room_type']),
            models.Index(fields=['-last_message_at']),
        ]

    def __str__(self):
        return f"{self.room_type}: {self.name or str(self.id)[:8]}"

    @classmethod
    def get_or_create_direct(cls, user1, user2):
        """Get or create a direct message room between two users"""
        rooms = cls.objects.filter(
            room_type=cls.RoomType.DIRECT,
            participants=user1
        ).filter(participants=user2)

        if rooms.exists():
            return rooms.first(), False

        room = cls.objects.create(room_type=cls.RoomType.DIRECT)
        RoomParticipant.objects.create(room=room, user=user1, role='member')
        RoomParticipant.objects.create(room=room, user=user2, role='member')
        return room, True


class RoomParticipant(models.Model):
    """Room membership with role management"""

    class Role(models.TextChoices):
        OWNER = 'owner', 'Owner'
        ADMIN = 'admin', 'Admin'
        MODERATOR = 'moderator', 'Moderator'
        MEMBER = 'member', 'Member'

    room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='memberships')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='room_memberships')
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.MEMBER)

    # Messaging state
    is_muted = models.BooleanField(default=False)
    muted_until = models.DateTimeField(null=True, blank=True)
    is_banned = models.BooleanField(default=False)
    last_read_at = models.DateTimeField(null=True, blank=True)
    unread_count = models.PositiveIntegerField(default=0)

    joined_at = models.DateTimeField(auto_now_add=True)
    left_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = ['room', 'user']
        indexes = [
            models.Index(fields=['room', 'user']),
            models.Index(fields=['user', 'is_active']),
        ]


class Message(models.Model):
    """Individual chat message"""

    class MessageType(models.TextChoices):
        TEXT = 'text', 'Text'
        IMAGE = 'image', 'Image'
        VIDEO = 'video', 'Video'
        AUDIO = 'audio', 'Audio'
        VOICE_NOTE = 'voice_note', 'Voice Note'
        DOCUMENT = 'document', 'Document'
        LOCATION = 'location', 'Location'
        CONTACT = 'contact', 'Contact'
        STICKER = 'sticker', 'Sticker'
        SYSTEM = 'system', 'System Message'
        MEETING_INVITE = 'meeting_invite', 'Meeting Invite'
        POLL = 'poll', 'Poll'

    class DeliveryStatus(models.TextChoices):
        SENT = 'sent', 'Sent'
        DELIVERED = 'delivered', 'Delivered'
        READ = 'read', 'Read'
        FAILED = 'failed', 'Failed'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='sent_messages')

    message_type = models.CharField(max_length=20, choices=MessageType.choices, default=MessageType.TEXT)

    # Content (encrypted at rest)
    content = models.TextField(blank=True)
    content_encrypted = models.BinaryField(null=True, blank=True)
    is_encrypted = models.BooleanField(default=True)

    # Media
    media_url = models.URLField(blank=True)
    media_type = models.CharField(max_length=100, blank=True)
    media_size = models.PositiveBigIntegerField(null=True, blank=True)
    media_name = models.CharField(max_length=255, blank=True)
    media_duration = models.FloatField(null=True, blank=True)
    thumbnail_url = models.URLField(blank=True)

    # Threading
    reply_to = models.ForeignKey(
        'self', null=True, blank=True, on_delete=models.SET_NULL,
        related_name='replies'
    )
    forwarded_from = models.ForeignKey(
        'self', null=True, blank=True, on_delete=models.SET_NULL,
        related_name='forwards'
    )
    is_forwarded = models.BooleanField(default=False)

    # Status
    delivery_status = models.CharField(
        max_length=20, choices=DeliveryStatus.choices, default=DeliveryStatus.SENT
    )
    is_edited = models.BooleanField(default=False)
    edit_history = models.JSONField(default=list, blank=True)
    is_deleted = models.BooleanField(default=False)
    deleted_for_everyone = models.BooleanField(default=False)

    # Reactions
    reactions = models.JSONField(default=dict, blank=True)  # {'👍': ['user_id1', 'user_id2']}

    # Metadata
    location_data = models.JSONField(null=True, blank=True)
    contact_data = models.JSONField(null=True, blank=True)
    meeting_data = models.JSONField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['room', '-created_at']),
            models.Index(fields=['sender', '-created_at']),
        ]

    def __str__(self):
        return f"Message from {self.sender} in {self.room} at {self.created_at}"

    def get_content(self):
        """Decrypt and return message content"""
        if self.is_encrypted and self.content_encrypted:
            return EncryptionService.decrypt(bytes(self.content_encrypted))
        return self.content

    def set_content(self, text):
        """Encrypt and store message content"""
        self.content = text[:50] + '...' if len(text) > 50 else text  # Preview
        if self.is_encrypted:
            self.content_encrypted = EncryptionService.encrypt(text)
        else:
            self.content = text


class MessageRead(models.Model):
    """Track read receipts per user"""
    message = models.ForeignKey(Message, on_delete=models.CASCADE, related_name='read_by')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    read_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['message', 'user']


class MessageDelivery(models.Model):
    """Track delivery status per user"""
    message = models.ForeignKey(Message, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    delivered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['message', 'user']


# ═══════════════════════════════════════════════════════════════════════════════
# WEBSOCKET CONSUMER
# ═══════════════════════════════════════════════════════════════════════════════

class ChatConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for real-time messaging
    Handles: messages, typing indicators, read receipts, online status
    """

    async def connect(self):
        self.room_id = self.scope['url_route']['kwargs']['room_id']
        self.room_group_name = f'chat_{self.room_id}'
        self.user = self.scope['user']

        if not self.user.is_authenticated:
            await self.close()
            return

        # Check if user is participant
        is_member = await self._check_membership()
        if not is_member:
            await self.close()
            return

        # Join room group
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)

        # Join user's personal channel for direct notifications
        await self.channel_layer.group_add(f'user_{self.user.id}', self.channel_name)

        await self.accept()

        # Mark user online
        await self._set_user_online(True)

        # Send pending messages
        await self._send_pending_messages()

        # Broadcast presence
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'user_online',
                'user_id': str(self.user.id),
                'username': self.user.username,
                'timestamp': timezone.now().isoformat(),
            }
        )

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)
        await self._set_user_online(False)

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'user_offline',
                'user_id': str(self.user.id),
                'last_seen': timezone.now().isoformat(),
            }
        )

    async def receive(self, text_data):
        """Handle incoming WebSocket messages"""
        try:
            data = json.loads(text_data)
            event_type = data.get('type')

            handlers = {
                'message': self._handle_send_message,
                'typing': self._handle_typing,
                'stop_typing': self._handle_stop_typing,
                'read': self._handle_read_receipt,
                'reaction': self._handle_reaction,
                'delete': self._handle_delete_message,
                'edit': self._handle_edit_message,
            }

            handler = handlers.get(event_type)
            if handler:
                await handler(data)
            else:
                await self.send(text_data=json.dumps({'error': f'Unknown event type: {event_type}'}))

        except json.JSONDecodeError:
            await self.send(text_data=json.dumps({'error': 'Invalid JSON'}))
        except Exception as e:
            logger.error(f"WebSocket error: {str(e)}")
            await self.send(text_data=json.dumps({'error': 'Internal error'}))

    async def _handle_send_message(self, data):
        """Process and broadcast a new message"""
        content = data.get('content', '').strip()
        message_type = data.get('message_type', 'text')
        reply_to_id = data.get('reply_to')

        if not content and message_type == 'text':
            return

        # Save message to DB
        message = await self._save_message(
            content=content,
            message_type=message_type,
            reply_to_id=reply_to_id,
            media_url=data.get('media_url', ''),
            media_type=data.get('media_type', ''),
            media_name=data.get('media_name', ''),
        )

        # Broadcast to room
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'id': str(message.id),
                'content': content,
                'message_type': message_type,
                'sender_id': str(self.user.id),
                'sender_username': self.user.username,
                'sender_name': self.user.get_full_name(),
                'sender_avatar': None,
                'reply_to': reply_to_id,
                'media_url': data.get('media_url'),
                'timestamp': message.created_at.isoformat(),
                'delivery_status': 'sent',
            }
        )

        # Send push to offline users
        await self._send_push_to_offline_participants(content)

    async def _handle_typing(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'typing_indicator',
                'user_id': str(self.user.id),
                'username': self.user.username,
                'is_typing': True,
            }
        )

    async def _handle_stop_typing(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'typing_indicator',
                'user_id': str(self.user.id),
                'username': self.user.username,
                'is_typing': False,
            }
        )

    async def _handle_read_receipt(self, data):
        message_id = data.get('message_id')
        if message_id:
            await self._mark_message_read(message_id)
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'read_receipt',
                    'message_id': message_id,
                    'user_id': str(self.user.id),
                    'read_at': timezone.now().isoformat(),
                }
            )

    async def _handle_reaction(self, data):
        message_id = data.get('message_id')
        emoji = data.get('emoji', '👍')
        await self._add_reaction(message_id, emoji)
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'message_reaction',
                'message_id': message_id,
                'user_id': str(self.user.id),
                'emoji': emoji,
            }
        )

    async def _handle_edit_message(self, data):
        message_id = data.get('message_id')
        new_content = data.get('content', '').strip()
        if message_id and new_content:
            success = await self._edit_message(message_id, new_content)
            if success:
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'message_edited',
                        'message_id': message_id,
                        'content': new_content,
                        'edited_at': timezone.now().isoformat(),
                    }
                )

    async def _handle_delete_message(self, data):
        message_id = data.get('message_id')
        delete_for_everyone = data.get('delete_for_everyone', False)
        if message_id:
            await self._delete_message(message_id, delete_for_everyone)
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'message_deleted',
                    'message_id': message_id,
                    'deleted_for_everyone': delete_for_everyone,
                }
            )

    # ─── Channel layer message handlers ─────────────────────────────────────
    async def chat_message(self, event):
        await self.send(text_data=json.dumps({'type': 'message', **event}))

    async def typing_indicator(self, event):
        if event['user_id'] != str(self.user.id):
            await self.send(text_data=json.dumps({'type': 'typing', **event}))

    async def read_receipt(self, event):
        await self.send(text_data=json.dumps({'type': 'read_receipt', **event}))

    async def message_reaction(self, event):
        await self.send(text_data=json.dumps({'type': 'reaction', **event}))

    async def message_edited(self, event):
        await self.send(text_data=json.dumps({'type': 'message_edited', **event}))

    async def message_deleted(self, event):
        await self.send(text_data=json.dumps({'type': 'message_deleted', **event}))

    async def user_online(self, event):
        await self.send(text_data=json.dumps({'type': 'presence', **event}))

    async def user_offline(self, event):
        await self.send(text_data=json.dumps({'type': 'presence', **event}))

    # ─── Database helpers ─────────────────────────────────────────────────────
    @database_sync_to_async
    def _save_message(self, content, message_type, reply_to_id, **kwargs):
        msg = Message(
            room_id=self.room_id,
            sender=self.user,
            message_type=message_type,
        )
        msg.set_content(content)
        msg.media_url = kwargs.get('media_url', '')
        msg.media_type = kwargs.get('media_type', '')
        msg.media_name = kwargs.get('media_name', '')

        if reply_to_id:
            try:
                msg.reply_to = Message.objects.get(id=reply_to_id)
            except Message.DoesNotExist:
                pass

        msg.save()

        # Update room last message
        ChatRoom.objects.filter(id=self.room_id).update(
            last_message_at=timezone.now(),
            last_message_preview=content[:100],
            message_count=models.F('message_count') + 1
        )

        # Update unread counts for other participants
        RoomParticipant.objects.filter(
            room_id=self.room_id, is_active=True
        ).exclude(user=self.user).update(
            unread_count=models.F('unread_count') + 1
        )

        return msg

    @database_sync_to_async
    def _check_membership(self):
        return RoomParticipant.objects.filter(
            room_id=self.room_id, user=self.user, is_active=True, is_banned=False
        ).exists()

    @database_sync_to_async
    def _set_user_online(self, online):
        from apps.users.models import User
        User.objects.filter(id=self.user.id).update(last_seen=timezone.now())
        cache.set(f'user_online_{self.user.id}', online, timeout=300)

    @database_sync_to_async
    def _mark_message_read(self, message_id):
        try:
            msg = Message.objects.get(id=message_id)
            MessageRead.objects.get_or_create(message=msg, user=self.user)
            RoomParticipant.objects.filter(
                room_id=self.room_id, user=self.user
            ).update(last_read_at=timezone.now(), unread_count=0)
        except Message.DoesNotExist:
            pass

    @database_sync_to_async
    def _add_reaction(self, message_id, emoji):
        try:
            msg = Message.objects.get(id=message_id)
            reactions = msg.reactions or {}
            user_id = str(self.user.id)
            if emoji not in reactions:
                reactions[emoji] = []
            if user_id in reactions[emoji]:
                reactions[emoji].remove(user_id)
            else:
                reactions[emoji].append(user_id)
            msg.reactions = reactions
            msg.save(update_fields=['reactions'])
        except Message.DoesNotExist:
            pass

    @database_sync_to_async
    def _edit_message(self, message_id, new_content):
        try:
            msg = Message.objects.get(id=message_id, sender=self.user)
            history = msg.edit_history or []
            history.append({'content': msg.get_content(), 'edited_at': timezone.now().isoformat()})
            msg.edit_history = history
            msg.is_edited = True
            msg.set_content(new_content)
            msg.save()
            return True
        except Message.DoesNotExist:
            return False

    @database_sync_to_async
    def _delete_message(self, message_id, for_everyone):
        try:
            msg = Message.objects.get(id=message_id, sender=self.user)
            msg.is_deleted = True
            msg.deleted_for_everyone = for_everyone
            if for_everyone:
                msg.content = 'This message was deleted'
                msg.content_encrypted = None
            msg.save()
        except Message.DoesNotExist:
            pass

    @database_sync_to_async
    def _send_pending_messages(self):
        pass

    @database_sync_to_async
    def _send_push_to_offline_participants(self, content):
        from infrastructure.celery_tasks.notifications import send_message_push_notification
        participants = RoomParticipant.objects.filter(
            room_id=self.room_id, is_active=True
        ).exclude(user=self.user).select_related('user')

        for participant in participants:
            is_online = cache.get(f'user_online_{participant.user.id}', False)
            if not is_online and participant.user.fcm_token:
                send_message_push_notification.delay(
                    str(participant.user.id),
                    self.user.get_full_name(),
                    content[:100],
                    str(self.room_id)
                )


# ═══════════════════════════════════════════════════════════════════════════════
# API VIEWS
# ═══════════════════════════════════════════════════════════════════════════════

class ConversationListView(APIView):
    """GET /messages/conversations - List all conversations"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        memberships = RoomParticipant.objects.filter(
            user=request.user, is_active=True
        ).select_related('room', 'room__creator').order_by('-room__last_message_at')

        conversations = []
        for membership in memberships:
            room = membership.room

            # For DMs, get the other participant
            other_user = None
            if room.room_type == ChatRoom.RoomType.DIRECT:
                other_participant = RoomParticipant.objects.filter(
                    room=room, is_active=True
                ).exclude(user=request.user).select_related('user', 'user__profile').first()
                if other_participant:
                    other_user = {
                        'id': str(other_participant.user.id),
                        'username': other_participant.user.username,
                        'full_name': other_participant.user.get_full_name(),
                        'is_online': cache.get(f'user_online_{other_participant.user.id}', False),
                        'last_seen': other_participant.user.last_seen.isoformat() if other_participant.user.last_seen else None,
                    }

            conversations.append({
                'room_id': str(room.id),
                'room_type': room.room_type,
                'name': room.name or (other_user['full_name'] if other_user else 'Unknown'),
                'last_message': room.last_message_preview,
                'last_message_at': room.last_message_at.isoformat() if room.last_message_at else None,
                'unread_count': membership.unread_count,
                'is_muted': membership.is_muted,
                'other_user': other_user,
                'participants_count': room.participants.count(),
            })

        return Response({'success': True, 'conversations': conversations})


class DirectMessageView(APIView):
    """POST /messages/direct - Start or get DM with user"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        target_user_id = request.data.get('user_id')
        try:
            target_user = User.objects.get(id=target_user_id, is_active=True)
        except User.DoesNotExist:
            return Response({'success': False, 'message': 'User not found.'}, status=404)

        if target_user == request.user:
            return Response({'success': False, 'message': 'Cannot message yourself.'}, status=400)

        room, created = ChatRoom.get_or_create_direct(request.user, target_user)

        return Response({
            'success': True,
            'room_id': str(room.id),
            'created': created,
            'ws_url': f'ws://api.apcconnect.ng/ws/chat/{room.id}/',
        })


class MessageHistoryView(APIView):
    """GET /messages/<room_id>/history - Get message history"""
    permission_classes = [IsAuthenticated]

    def get(self, request, room_id):
        # Check membership
        if not RoomParticipant.objects.filter(
            room_id=room_id, user=request.user, is_active=True
        ).exists():
            return Response({'success': False, 'message': 'Access denied.'}, status=403)

        before = request.query_params.get('before')
        limit = min(int(request.query_params.get('limit', 50)), 100)

        qs = Message.objects.filter(
            room_id=room_id,
            deleted_for_everyone=False,
        ).select_related('sender', 'reply_to').order_by('-created_at')

        if before:
            try:
                before_msg = Message.objects.get(id=before)
                qs = qs.filter(created_at__lt=before_msg.created_at)
            except Message.DoesNotExist:
                pass

        messages = list(qs[:limit])
        messages.reverse()  # Chronological order

        data = []
        for msg in messages:
            content = msg.get_content() if not msg.is_deleted else 'Message deleted'

            # Check if deleted for this user
            msg_data = {
                'id': str(msg.id),
                'message_type': msg.message_type,
                'content': content,
                'sender': {
                    'id': str(msg.sender.id) if msg.sender else None,
                    'username': msg.sender.username if msg.sender else 'Deleted',
                    'full_name': msg.sender.get_full_name() if msg.sender else 'Deleted User',
                    'is_me': msg.sender == request.user if msg.sender else False,
                },
                'media_url': msg.media_url,
                'media_type': msg.media_type,
                'media_name': msg.media_name,
                'reply_to': {
                    'id': str(msg.reply_to.id),
                    'content': msg.reply_to.get_content()[:100],
                    'sender_name': msg.reply_to.sender.get_full_name() if msg.reply_to.sender else '',
                } if msg.reply_to else None,
                'reactions': msg.reactions,
                'is_edited': msg.is_edited,
                'is_deleted': msg.is_deleted or msg.deleted_for_everyone,
                'is_forwarded': msg.is_forwarded,
                'delivery_status': msg.delivery_status,
                'timestamp': msg.created_at.isoformat(),
            }
            data.append(msg_data)

        # Mark as read
        RoomParticipant.objects.filter(
            room_id=room_id, user=request.user
        ).update(last_read_at=timezone.now(), unread_count=0)

        return Response({'success': True, 'messages': data, 'has_more': qs.count() > limit})


class GroupChatCreateView(APIView):
    """POST /messages/groups/create - Create group chat"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        name = request.data.get('name', '').strip()
        if not name:
            return Response({'success': False, 'message': 'Group name required.'}, status=400)

        participant_ids = request.data.get('participant_ids', [])

        room = ChatRoom.objects.create(
            room_type=ChatRoom.RoomType.GROUP,
            name=name,
            description=request.data.get('description', ''),
            creator=request.user,
        )

        # Add creator as owner
        RoomParticipant.objects.create(room=room, user=request.user, role='owner')

        # Add participants
        for uid in participant_ids[:499]:
            try:
                u = User.objects.get(id=uid, is_active=True)
                RoomParticipant.objects.get_or_create(room=room, user=u, defaults={'role': 'member'})
            except User.DoesNotExist:
                pass

        audit_logger.log(
            action='GROUP_CHAT_CREATED',
            user=request.user,
            details={'room_id': str(room.id), 'name': name}
        )

        return Response({
            'success': True,
            'room_id': str(room.id),
            'name': room.name,
            'ws_url': f'ws://api.apcconnect.ng/ws/chat/{room.id}/',
        }, status=201)


class SearchMessagesView(APIView):
    """GET /messages/search - Search messages"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        query = request.query_params.get('q', '').strip()
        room_id = request.query_params.get('room_id')

        if not query:
            return Response({'success': False, 'message': 'Search query required.'}, status=400)

        # Get user's rooms
        user_rooms = RoomParticipant.objects.filter(
            user=request.user, is_active=True
        ).values_list('room_id', flat=True)

        qs = Message.objects.filter(
            room__in=user_rooms,
            content__icontains=query,
            is_deleted=False,
        ).select_related('sender', 'room').order_by('-created_at')

        if room_id:
            qs = qs.filter(room_id=room_id)

        messages = qs[:50]

        return Response({
            'success': True,
            'results': [{
                'id': str(m.id),
                'room_id': str(m.room.id),
                'room_name': m.room.name,
                'content': m.get_content(),
                'sender': m.sender.get_full_name() if m.sender else '',
                'timestamp': m.created_at.isoformat(),
            } for m in messages]
        })
