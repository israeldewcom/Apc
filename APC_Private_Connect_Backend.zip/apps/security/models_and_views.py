"""
APC Private Connect - Security & Analytics Services (continued)
"""

import uuid
import logging
from datetime import timedelta

from django.db import models
from django.utils import timezone
from django.core.cache import cache
from django.db.models import F, Count, Avg, Q, Sum

from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.users.models import User
from core.utils.audit import AuditLogger

logger = logging.getLogger('apc.api')
security_logger = logging.getLogger('apc.security')
audit_logger = AuditLogger()


# ═══════════════════════════════════════════════════════════════════════════════
# SECURITY MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class SecurityAlert(models.Model):
    class AlertType(models.TextChoices):
        BRUTE_FORCE = 'brute_force', 'Brute Force Attack'
        SUSPICIOUS_LOGIN = 'suspicious_login', 'Suspicious Login'
        FAILED_BIOMETRIC = 'failed_biometric', 'Multiple Failed Biometric'
        DUPLICATE_NIN = 'duplicate_nin', 'Duplicate NIN Attempt'
        DUPLICATE_FINGERPRINT = 'duplicate_fingerprint', 'Duplicate Fingerprint'
        ACCOUNT_TAKEOVER = 'account_takeover', 'Possible Account Takeover'
        SPAM_ACTIVITY = 'spam_activity', 'Spam Activity Detected'
        UNUSUAL_ACTIVITY = 'unusual_activity', 'Unusual Activity Pattern'
        NEW_DEVICE = 'new_device', 'New Device Login'

    class Severity(models.TextChoices):
        LOW = 'low', 'Low'
        MEDIUM = 'medium', 'Medium'
        HIGH = 'high', 'High'
        CRITICAL = 'critical', 'Critical'

    class Status(models.TextChoices):
        OPEN = 'open', 'Open'
        INVESTIGATING = 'investigating', 'Under Investigation'
        RESOLVED = 'resolved', 'Resolved'
        FALSE_POSITIVE = 'false_positive', 'False Positive'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='security_alerts')
    alert_type = models.CharField(max_length=40, choices=AlertType.choices)
    severity = models.CharField(max_length=10, choices=Severity.choices, default=Severity.MEDIUM)
    description = models.TextField()
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    metadata = models.JSONField(default=dict)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OPEN)
    resolved_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='+')
    resolution_notes = models.TextField(blank=True)
    auto_action_taken = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status', 'severity']),
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['alert_type', '-created_at']),
        ]


class AuditLog(models.Model):
    class Severity(models.TextChoices):
        LOW = 'low', 'Low'
        MEDIUM = 'medium', 'Medium'
        HIGH = 'high', 'High'
        CRITICAL = 'critical', 'Critical'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='audit_logs')
    action = models.CharField(max_length=100, db_index=True)
    description = models.TextField(blank=True)
    severity = models.CharField(max_length=10, choices=Severity.choices, default=Severity.LOW)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    endpoint = models.CharField(max_length=255, blank=True)
    method = models.CharField(max_length=10, blank=True)
    device_id = models.CharField(max_length=255, blank=True)
    target_type = models.CharField(max_length=50, blank=True)
    target_id = models.CharField(max_length=36, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['user', '-timestamp']),
            models.Index(fields=['action', '-timestamp']),
            models.Index(fields=['ip_address', '-timestamp']),
        ]
        default_permissions = ('add', 'view')


class IPBlacklist(models.Model):
    ip_address = models.GenericIPAddressField(unique=True)
    reason = models.TextField()
    blocked_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    is_active = models.BooleanField(default=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=['ip_address', 'is_active'])]


class SpamReport(models.Model):
    reporter = models.ForeignKey(User, on_delete=models.CASCADE, related_name='spam_reports')
    target_user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='spam_received')
    content_type = models.CharField(max_length=50)
    content_id = models.CharField(max_length=36)
    reason = models.TextField()
    auto_detected = models.BooleanField(default=False)
    reviewed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYTICS MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class UserActivity(models.Model):
    """Track every significant user activity for analytics"""

    class ActivityType(models.TextChoices):
        LOGIN = 'login', 'Login'
        LOGOUT = 'logout', 'Logout'
        POST_CREATED = 'post_created', 'Post Created'
        POST_VIEWED = 'post_viewed', 'Post Viewed'
        POST_LIKED = 'post_liked', 'Post Liked'
        COMMENT_ADDED = 'comment_added', 'Comment Added'
        MESSAGE_SENT = 'message_sent', 'Message Sent'
        GROUP_JOINED = 'group_joined', 'Group Joined'
        MEETING_JOINED = 'meeting_joined', 'Meeting Joined'
        PROFILE_VIEWED = 'profile_viewed', 'Profile Viewed'
        SEARCH_PERFORMED = 'search_performed', 'Search Performed'
        FILE_UPLOADED = 'file_uploaded', 'File Uploaded'
        NOTIFICATION_CLICKED = 'notification_clicked', 'Notification Clicked'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='activities', db_index=True)
    activity_type = models.CharField(max_length=30, choices=ActivityType.choices)
    object_type = models.CharField(max_length=50, blank=True)
    object_id = models.CharField(max_length=36, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    session_id = models.CharField(max_length=36, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    device_type = models.CharField(max_length=20, blank=True)
    state = models.CharField(max_length=100, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['user', '-timestamp']),
            models.Index(fields=['activity_type', '-timestamp']),
            models.Index(fields=['state', '-timestamp']),
        ]


class DailyStats(models.Model):
    """Aggregated daily statistics for dashboard"""

    date = models.DateField(unique=True, db_index=True)

    # Users
    new_registrations = models.PositiveIntegerField(default=0)
    active_users = models.PositiveIntegerField(default=0)
    total_logins = models.PositiveIntegerField(default=0)
    verified_users_total = models.PositiveIntegerField(default=0)

    # Content
    posts_created = models.PositiveIntegerField(default=0)
    comments_created = models.PositiveIntegerField(default=0)
    reactions_given = models.PositiveIntegerField(default=0)
    media_uploaded_gb = models.FloatField(default=0.0)

    # Messaging
    messages_sent = models.PositiveIntegerField(default=0)
    active_chat_rooms = models.PositiveIntegerField(default=0)

    # Meetings
    meetings_held = models.PositiveIntegerField(default=0)
    meeting_minutes_total = models.PositiveIntegerField(default=0)
    meeting_participants_total = models.PositiveIntegerField(default=0)

    # Groups
    groups_created = models.PositiveIntegerField(default=0)
    group_joins = models.PositiveIntegerField(default=0)

    # Security
    failed_logins = models.PositiveIntegerField(default=0)
    security_alerts_raised = models.PositiveIntegerField(default=0)
    nin_verifications = models.PositiveIntegerField(default=0)

    # Performance
    avg_response_time_ms = models.FloatField(default=0.0)
    error_rate = models.FloatField(default=0.0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date']


class StateEngagementStats(models.Model):
    """Per-state engagement statistics"""

    date = models.DateField(db_index=True)
    state = models.CharField(max_length=100, db_index=True)
    active_members = models.PositiveIntegerField(default=0)
    posts_count = models.PositiveIntegerField(default=0)
    meetings_count = models.PositiveIntegerField(default=0)
    messages_count = models.PositiveIntegerField(default=0)
    new_registrations = models.PositiveIntegerField(default=0)
    engagement_score = models.FloatField(default=0.0)

    class Meta:
        unique_together = ['date', 'state']
        ordering = ['-date', '-engagement_score']


# ═══════════════════════════════════════════════════════════════════════════════
# SECURITY VIEWS
# ═══════════════════════════════════════════════════════════════════════════════

class SecurityDashboardView(APIView):
    """GET /security/dashboard - Admin security overview"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not request.user.is_admin:
            return Response({'success': False, 'message': 'Admin access required.'}, status=403)

        now = timezone.now()
        last_24h = now - timedelta(hours=24)
        last_7d = now - timedelta(days=7)

        open_alerts = SecurityAlert.objects.filter(status='open')
        recent_logins = AuditLog.objects.filter(action='USER_LOGIN', timestamp__gte=last_24h)
        failed_logins = AuditLog.objects.filter(action__in=['LOGIN_FAILED', 'ACCOUNT_LOCKED'], timestamp__gte=last_24h)

        # Top threats
        top_ips = AuditLog.objects.filter(
            action='LOGIN_FAILED', timestamp__gte=last_24h
        ).values('ip_address').annotate(count=Count('id')).order_by('-count')[:10]

        return Response({
            'success': True,
            'summary': {
                'open_alerts': open_alerts.count(),
                'critical_alerts': open_alerts.filter(severity='critical').count(),
                'logins_24h': recent_logins.count(),
                'failed_logins_24h': failed_logins.count(),
                'blocked_ips': IPBlacklist.objects.filter(is_active=True).count(),
                'suspicious_accounts': User.objects.filter(
                    account_status='suspended'
                ).count(),
            },
            'alert_breakdown': {
                alert_type: open_alerts.filter(alert_type=alert_type).count()
                for alert_type, _ in SecurityAlert.AlertType.choices
            },
            'top_suspicious_ips': [
                {'ip': item['ip_address'], 'attempts': item['count']}
                for item in top_ips
            ],
            'recent_alerts': [{
                'id': str(a.id),
                'type': a.alert_type,
                'severity': a.severity,
                'user': a.user.username if a.user else None,
                'ip': a.ip_address,
                'description': a.description,
                'created_at': a.created_at.isoformat(),
            } for a in open_alerts.order_by('-created_at')[:20]],
        })


class AuditLogView(APIView):
    """GET /security/audit-logs"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not request.user.is_admin:
            return Response({'success': False, 'message': 'Admin access required.'}, status=403)

        action = request.query_params.get('action')
        user_id = request.query_params.get('user_id')
        severity = request.query_params.get('severity')
        date_from = request.query_params.get('from')
        date_to = request.query_params.get('to')
        page = int(request.query_params.get('page', 1))
        size = min(int(request.query_params.get('size', 50)), 100)

        qs = AuditLog.objects.all()
        if action:
            qs = qs.filter(action__icontains=action)
        if user_id:
            qs = qs.filter(user_id=user_id)
        if severity:
            qs = qs.filter(severity=severity)
        if date_from:
            qs = qs.filter(timestamp__date__gte=date_from)
        if date_to:
            qs = qs.filter(timestamp__date__lte=date_to)

        total = qs.count()
        logs = qs.select_related('user')[(page-1)*size:page*size]

        return Response({
            'success': True,
            'total': total,
            'logs': [{
                'id': str(log.id),
                'user': log.user.username if log.user else 'System',
                'action': log.action,
                'description': log.description,
                'severity': log.severity,
                'ip_address': log.ip_address,
                'endpoint': log.endpoint,
                'metadata': log.metadata,
                'timestamp': log.timestamp.isoformat(),
            } for log in logs]
        })


class SecurityAlertManageView(APIView):
    """PATCH /security/alerts/<alert_id> - Manage security alerts"""
    permission_classes = [IsAuthenticated]

    def patch(self, request, alert_id):
        if not request.user.is_admin:
            return Response({'success': False, 'message': 'Admin access required.'}, status=403)

        try:
            alert = SecurityAlert.objects.get(id=alert_id)
        except SecurityAlert.DoesNotExist:
            return Response({'success': False, 'message': 'Alert not found.'}, status=404)

        new_status = request.data.get('status')
        if new_status in [c[0] for c in SecurityAlert.Status.choices]:
            alert.status = new_status
            alert.resolution_notes = request.data.get('notes', '')
            alert.resolved_by = request.user
            if new_status in ['resolved', 'false_positive']:
                alert.resolved_at = timezone.now()
            alert.save()

        return Response({'success': True, 'message': 'Alert updated.'})


class IPBlacklistView(APIView):
    """POST/DELETE /security/ip-blacklist"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if not request.user.is_admin:
            return Response({'success': False, 'message': 'Admin access required.'}, status=403)

        ip = request.data.get('ip_address')
        reason = request.data.get('reason', '')

        if not ip:
            return Response({'success': False, 'message': 'IP address required.'}, status=400)

        blacklist, created = IPBlacklist.objects.update_or_create(
            ip_address=ip,
            defaults={
                'reason': reason,
                'blocked_by': request.user,
                'is_active': True,
            }
        )
        # Update cache immediately
        cache.set(f'ip_blocked_{ip}', True, timeout=86400)

        audit_logger.log(
            action='IP_BLACKLISTED', user=request.user,
            details={'ip': ip, 'reason': reason}
        )
        return Response({'success': True, 'message': f'IP {ip} blacklisted.'})

    def delete(self, request):
        if not request.user.is_admin:
            return Response({'success': False, 'message': 'Admin access required.'}, status=403)

        ip = request.data.get('ip_address')
        IPBlacklist.objects.filter(ip_address=ip).update(is_active=False)
        cache.delete(f'ip_blocked_{ip}')
        return Response({'success': True, 'message': f'IP {ip} unblocked.'})


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYTICS VIEWS
# ═══════════════════════════════════════════════════════════════════════════════

class AdminAnalyticsDashboardView(APIView):
    """GET /analytics/dashboard - Main analytics for admins"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not request.user.is_admin:
            return Response({'success': False, 'message': 'Admin access required.'}, status=403)

        cache_key = f'analytics_dashboard_{request.user.state or "national"}'
        cached = cache.get(cache_key)
        if cached:
            return Response(cached)

        now = timezone.now()
        today = now.date()
        last_30d = today - timedelta(days=30)
        last_7d = today - timedelta(days=7)

        # Scope by admin level
        user_qs = User.objects.filter(is_active=True)
        if request.user.role == 'state_admin' and request.user.state:
            user_qs = user_qs.filter(state=request.user.state)
        elif request.user.role == 'lga_admin':
            user_qs = user_qs.filter(lga=request.user.lga)

        # User stats
        total_users = user_qs.count()
        verified_users = user_qs.filter(is_verified=True).count()
        new_this_month = user_qs.filter(date_joined__date__gte=last_30d).count()
        new_this_week = user_qs.filter(date_joined__date__gte=last_7d).count()
        active_today = user_qs.filter(last_seen__date=today).count()

        # User role breakdown
        role_breakdown = dict(
            user_qs.values('role').annotate(count=Count('id')).values_list('role', 'count')
        )

        # State breakdown (national admin only)
        state_breakdown = []
        if request.user.role in ['super_admin', 'national_admin']:
            state_breakdown = list(
                user_qs.values('state').annotate(
                    count=Count('id'),
                    verified=Count('id', filter=Q(is_verified=True))
                ).order_by('-count')[:37]  # 36 states + FCT
            )

        # Verification funnel
        verification_funnel = {
            'total': total_users,
            'email_verified': user_qs.filter(email_verified=True).count(),
            'phone_verified': user_qs.filter(phone_verified=True).count(),
            'nin_verified': user_qs.filter(nin_verified=True).count(),
            'fingerprint_enrolled': user_qs.filter(fingerprint_enrolled=True).count(),
            'fully_verified': verified_users,
        }

        # Get 30-day trend from DailyStats
        daily_stats = DailyStats.objects.filter(
            date__gte=last_30d
        ).order_by('date').values(
            'date', 'new_registrations', 'active_users',
            'posts_created', 'messages_sent', 'meetings_held'
        )

        # Meeting stats
        from apps.meetings.models_and_views import Meeting
        meetings_qs = Meeting.objects.all()
        if request.user.role == 'state_admin':
            meetings_qs = meetings_qs.filter(host__state=request.user.state)

        meeting_stats = {
            'total': meetings_qs.count(),
            'this_month': meetings_qs.filter(created_at__date__gte=last_30d).count(),
            'active_now': meetings_qs.filter(status='active').count(),
            'avg_participants': meetings_qs.filter(
                total_attendees__gt=0
            ).aggregate(avg=Avg('total_attendees'))['avg'] or 0,
        }

        # Top active states
        top_states = StateEngagementStats.objects.filter(
            date__gte=last_7d
        ).values('state').annotate(
            total_score=Sum('engagement_score'),
            total_members=Sum('active_members'),
        ).order_by('-total_score')[:10]

        data = {
            'success': True,
            'generated_at': now.isoformat(),
            'scope': request.user.state or 'national',
            'users': {
                'total': total_users,
                'verified': verified_users,
                'verification_rate': round((verified_users / total_users * 100), 1) if total_users else 0,
                'new_this_month': new_this_month,
                'new_this_week': new_this_week,
                'active_today': active_today,
                'role_breakdown': role_breakdown,
            },
            'verification_funnel': verification_funnel,
            'state_breakdown': state_breakdown,
            'meetings': meeting_stats,
            'top_engaged_states': list(top_states),
            'daily_trend': list(daily_stats),
        }

        cache.set(cache_key, data, timeout=300)
        return Response(data)


class UserAnalyticsView(APIView):
    """GET /analytics/users - Detailed user analytics"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not request.user.is_admin:
            return Response({'success': False, 'message': 'Admin access required.'}, status=403)

        period = request.query_params.get('period', '30')
        state = request.query_params.get('state')
        role = request.query_params.get('role')

        days = min(int(period), 365)
        start_date = timezone.now().date() - timedelta(days=days)

        qs = User.objects.filter(is_active=True, date_joined__date__gte=start_date)
        if state:
            qs = qs.filter(state=state)
        if role:
            qs = qs.filter(role=role)

        # Registration trend
        reg_trend = list(
            qs.extra(select={'day': 'date(date_joined)'})
            .values('day').annotate(count=Count('id')).order_by('day')
        )

        # Verification status distribution
        verification_dist = dict(
            qs.values('verification_status').annotate(count=Count('id')).values_list('verification_status', 'count')
        )

        # Gender distribution
        gender_dist = dict(
            qs.values('gender').annotate(count=Count('id')).values_list('gender', 'count')
        )

        # Age distribution (if DOB available)
        current_year = timezone.now().year
        age_groups = {'18-25': 0, '26-35': 0, '36-45': 0, '46-55': 0, '55+': 0}
        for user in qs.exclude(date_of_birth=None).values('date_of_birth'):
            age = current_year - user['date_of_birth'].year
            if 18 <= age <= 25:
                age_groups['18-25'] += 1
            elif 26 <= age <= 35:
                age_groups['26-35'] += 1
            elif 36 <= age <= 45:
                age_groups['36-45'] += 1
            elif 46 <= age <= 55:
                age_groups['46-55'] += 1
            else:
                age_groups['55+'] += 1

        return Response({
            'success': True,
            'period_days': days,
            'total_in_period': qs.count(),
            'registration_trend': reg_trend,
            'verification_distribution': verification_dist,
            'gender_distribution': gender_dist,
            'age_groups': age_groups,
            'top_states': list(
                qs.values('state').annotate(count=Count('id')).order_by('-count')[:10]
            ),
        })


class EngagementAnalyticsView(APIView):
    """GET /analytics/engagement"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not request.user.is_admin:
            return Response({'success': False, 'message': 'Admin access required.'}, status=403)

        period = int(request.query_params.get('period', 30))
        start_date = timezone.now() - timedelta(days=period)

        from apps.posts.models_and_views import Post, Reaction, Comment

        posts_qs = Post.objects.filter(
            created_at__gte=start_date, post_status='published'
        )

        post_type_breakdown = dict(
            posts_qs.values('post_type').annotate(count=Count('id')).values_list('post_type', 'count')
        )

        top_posts = posts_qs.order_by('-engagement_score').values(
            'id', 'title', 'content', 'post_type',
            'likes_count', 'comments_count', 'shares_count', 'views_count',
            'author__username', 'created_at'
        )[:10]

        activity_qs = UserActivity.objects.filter(timestamp__gte=start_date)
        activity_breakdown = dict(
            activity_qs.values('activity_type').annotate(count=Count('id')).values_list('activity_type', 'count')
        )

        hourly_activity = list(
            activity_qs.extra(select={'hour': "extract(hour from timestamp)"})
            .values('hour').annotate(count=Count('id')).order_by('hour')
        )

        return Response({
            'success': True,
            'period_days': period,
            'content': {
                'total_posts': posts_qs.count(),
                'post_type_breakdown': post_type_breakdown,
                'total_reactions': Reaction.objects.filter(created_at__gte=start_date).count(),
                'total_comments': Comment.objects.filter(created_at__gte=start_date).count(),
                'avg_engagement_score': posts_qs.aggregate(avg=Avg('engagement_score'))['avg'] or 0,
            },
            'top_posts': [dict(p) for p in top_posts],
            'activity_breakdown': activity_breakdown,
            'peak_hours': hourly_activity,
        })


class MyAnalyticsView(APIView):
    """GET /analytics/me - Personal analytics for any user"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        period = int(request.query_params.get('period', 30))
        start_date = timezone.now() - timedelta(days=period)

        from apps.posts.models_and_views import Post, Reaction, Comment

        my_posts = Post.objects.filter(author=user, created_at__gte=start_date, post_status='published')
        post_stats = my_posts.aggregate(
            total_likes=Sum('likes_count'),
            total_comments=Sum('comments_count'),
            total_shares=Sum('shares_count'),
            total_views=Sum('views_count'),
        )

        my_activities = UserActivity.objects.filter(user=user, timestamp__gte=start_date)

        return Response({
            'success': True,
            'period_days': period,
            'posts': {
                'total': my_posts.count(),
                'total_likes': post_stats['total_likes'] or 0,
                'total_comments': post_stats['total_comments'] or 0,
                'total_shares': post_stats['total_shares'] or 0,
                'total_views': post_stats['total_views'] or 0,
                'top_post': my_posts.order_by('-engagement_score').values(
                    'id', 'content', 'likes_count', 'views_count'
                ).first(),
            },
            'profile': {
                'followers': user.followers_count,
                'following': user.following_count,
                'total_posts': user.posts_count,
                'profile_completion': user.profile.profile_completion if hasattr(user, 'profile') else 0,
            },
            'verification': {
                'status': user.verification_status,
                'email': user.email_verified,
                'phone': user.phone_verified,
                'nin': user.nin_verified,
                'fingerprint': user.fingerprint_enrolled,
            },
            'activity_count': my_activities.count(),
        })
