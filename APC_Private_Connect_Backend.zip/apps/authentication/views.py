"""
APC Private Connect - Authentication Service
Full authentication: JWT, OTP, 2FA, device verification, session management
"""

import uuid
import hashlib
import secrets
import logging
from datetime import timedelta

from django.utils import timezone
from django.contrib.auth import authenticate
from django.core.cache import cache
from django.conf import settings

from rest_framework import status, generics
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.throttling import AnonRateThrottle
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenRefreshView
from rest_framework_simplejwt.exceptions import TokenError, InvalidToken

from apps.users.models import User, UserDevice
from core.utils.otp import OTPService
from core.utils.email import EmailService
from core.utils.sms import SMSService
from core.utils.audit import AuditLogger
from core.utils.encryption import EncryptionService
from .serializers import (
    RegisterSerializer, LoginSerializer, OTPVerifySerializer,
    PasswordResetSerializer, ChangePasswordSerializer,
    TwoFactorSetupSerializer, TwoFactorVerifySerializer,
    DeviceVerifySerializer,
)

logger = logging.getLogger('apc.api')
security_logger = logging.getLogger('apc.security')
audit_logger = AuditLogger()


class AuthThrottle(AnonRateThrottle):
    rate = '10/min'


class RegisterView(APIView):
    """
    POST /auth/register
    New member registration with email + phone verification
    """
    permission_classes = [AllowAny]
    throttle_classes = [AuthThrottle]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'success': False,
                'errors': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            user = serializer.save()

            # Send email verification OTP
            otp_service = OTPService()
            otp = otp_service.generate_and_store(
                key=f'email_verify_{user.id}',
                length=6,
                expiry_minutes=10
            )
            EmailService.send_email_verification(user.email, user.first_name, otp)

            # Send SMS OTP if phone provided
            if user.phone_number:
                sms_otp = otp_service.generate_and_store(
                    key=f'phone_verify_{user.id}',
                    length=6,
                    expiry_minutes=10
                )
                SMSService.send_verification(user.phone_number, sms_otp)

            # Create device record
            device_id = request.data.get('device_id', str(uuid.uuid4()))
            UserDevice.objects.create(
                user=user,
                device_id=device_id,
                device_name=request.data.get('device_name', 'Unknown'),
                device_type=request.data.get('device_type', 'unknown'),
                ip_address=self._get_client_ip(request),
                is_trusted=False,
            )

            audit_logger.log(
                action='USER_REGISTERED',
                user=user,
                ip=self._get_client_ip(request),
                details={'email': user.email, 'role': user.role}
            )

            return Response({
                'success': True,
                'message': 'Registration successful. Please verify your email.',
                'user_id': str(user.id),
                'verification_required': True,
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            logger.error(f"Registration error: {str(e)}")
            return Response({
                'success': False,
                'message': 'Registration failed. Please try again.'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def _get_client_ip(self, request):
        x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
        return x_forwarded.split(',')[0] if x_forwarded else request.META.get('REMOTE_ADDR')


class LoginView(APIView):
    """
    POST /auth/login
    Secure login with brute force protection, device tracking, 2FA support
    """
    permission_classes = [AllowAny]
    throttle_classes = [AuthThrottle]

    def post(self, request):
        ip = self._get_client_ip(request)
        serializer = LoginSerializer(data=request.data)

        if not serializer.is_valid():
            return Response({'success': False, 'errors': serializer.errors},
                          status=status.HTTP_400_BAD_REQUEST)

        email = serializer.validated_data['email']
        password = serializer.validated_data['password']
        device_id = serializer.validated_data.get('device_id', str(uuid.uuid4()))

        # ─── Brute Force Protection ────────────────────────────────────
        lockout_key = f'login_lockout_{ip}_{email}'
        attempts_key = f'login_attempts_{ip}_{email}'

        if cache.get(lockout_key):
            security_logger.warning(f"Locked out login attempt: {email} from {ip}")
            return Response({
                'success': False,
                'message': 'Account temporarily locked. Try again in 30 minutes.',
                'locked': True
            }, status=status.HTTP_429_TOO_MANY_REQUESTS)

        # ─── Authenticate ──────────────────────────────────────────────
        user = authenticate(request, username=email, password=password)

        if not user:
            attempts = cache.get(attempts_key, 0) + 1
            cache.set(attempts_key, attempts, timeout=1800)

            if attempts >= settings.APC_SETTINGS['MAX_LOGIN_ATTEMPTS']:
                lockout_duration = settings.APC_SETTINGS['LOCKOUT_DURATION_MINUTES'] * 60
                cache.set(lockout_key, True, timeout=lockout_duration)
                security_logger.warning(f"Account locked after {attempts} attempts: {email}")

                audit_logger.log(
                    action='ACCOUNT_LOCKED',
                    details={'email': email, 'ip': ip, 'attempts': attempts}
                )

            return Response({
                'success': False,
                'message': 'Invalid credentials.',
                'attempts_remaining': max(0, 5 - attempts)
            }, status=status.HTTP_401_UNAUTHORIZED)

        # ─── Check Account Status ──────────────────────────────────────
        if user.account_status == User.AccountStatus.SUSPENDED:
            return Response({
                'success': False,
                'message': 'Account suspended.',
                'reason': user.suspension_reason
            }, status=status.HTTP_403_FORBIDDEN)

        if user.account_status == User.AccountStatus.BANNED:
            return Response({
                'success': False,
                'message': 'Account has been permanently banned.'
            }, status=status.HTTP_403_FORBIDDEN)

        # ─── 2FA Check ─────────────────────────────────────────────────
        if user.two_factor_enabled:
            temp_token = secrets.token_urlsafe(32)
            cache.set(f'2fa_temp_{temp_token}', str(user.id), timeout=300)
            return Response({
                'success': True,
                'requires_2fa': True,
                'temp_token': temp_token,
                'message': 'Enter your 2FA code to continue.'
            }, status=status.HTTP_200_OK)

        # ─── Device Verification ───────────────────────────────────────
        device, created = UserDevice.objects.get_or_create(
            user=user,
            device_id=device_id,
            defaults={
                'device_name': request.data.get('device_name', 'Unknown Device'),
                'device_type': request.data.get('device_type', 'unknown'),
                'ip_address': ip,
                'is_trusted': False,
            }
        )

        if not device.is_trusted and not created:
            # Send device verification OTP
            otp_service = OTPService()
            otp = otp_service.generate_and_store(
                key=f'device_verify_{user.id}_{device_id}',
                length=6, expiry_minutes=10
            )
            EmailService.send_new_device_alert(user.email, user.first_name, device, otp)

            temp_token = secrets.token_urlsafe(32)
            cache.set(f'device_verify_temp_{temp_token}',
                     {'user_id': str(user.id), 'device_id': device_id},
                     timeout=600)

            return Response({
                'success': True,
                'requires_device_verification': True,
                'temp_token': temp_token,
                'message': 'New device detected. Check your email for verification code.'
            })

        return self._generate_tokens_response(user, device, ip, request)

    def _generate_tokens_response(self, user, device, ip, request):
        """Generate JWT tokens and return success response"""

        # Clear failed attempts
        email = user.email
        cache.delete(f'login_attempts_{ip}_{email}')

        # Generate tokens
        refresh = RefreshToken.for_user(user)
        access = refresh.access_token

        # Add custom claims
        access['role'] = user.role
        access['is_verified'] = user.is_verified
        access['device_id'] = device.device_id if device else None

        # Update user
        user.last_login = timezone.now()
        user.last_seen = timezone.now()
        user.save(update_fields=['last_login', 'last_seen'])

        # Trust device after successful login
        if device:
            device.is_trusted = True
            device.ip_address = ip
            device.is_current = True
            device.last_active = timezone.now()
            device.save()

        audit_logger.log(
            action='USER_LOGIN',
            user=user,
            ip=ip,
            details={'device_id': device.device_id if device else None}
        )

        return Response({
            'success': True,
            'message': 'Login successful.',
            'tokens': {
                'access': str(access),
                'refresh': str(refresh),
                'access_expires_in': 3600,
                'refresh_expires_in': 604800,
            },
            'user': {
                'id': str(user.id),
                'email': user.email,
                'username': user.username,
                'full_name': user.get_full_name(),
                'role': user.role,
                'is_verified': user.is_verified,
                'verification_status': user.verification_status,
                'profile_picture': user.profile.profile_picture.url if hasattr(user, 'profile') and user.profile.profile_picture else None,
            }
        })

    def _get_client_ip(self, request):
        x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
        return x_forwarded.split(',')[0] if x_forwarded else request.META.get('REMOTE_ADDR')


class TwoFactorVerifyView(APIView):
    """POST /auth/2fa/verify - Verify 2FA code"""
    permission_classes = [AllowAny]

    def post(self, request):
        temp_token = request.data.get('temp_token')
        totp_code = request.data.get('code')

        user_id = cache.get(f'2fa_temp_{temp_token}')
        if not user_id:
            return Response({'success': False, 'message': 'Session expired.'},
                          status=status.HTTP_400_BAD_REQUEST)

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({'success': False, 'message': 'Invalid session.'},
                          status=status.HTTP_400_BAD_REQUEST)

        import pyotp
        totp = pyotp.TOTP(user.two_factor_secret)

        if not totp.verify(totp_code, valid_window=1):
            # Check backup codes
            if totp_code in user.backup_codes:
                user.backup_codes.remove(totp_code)
                user.save(update_fields=['backup_codes'])
            else:
                return Response({'success': False, 'message': 'Invalid 2FA code.'},
                              status=status.HTTP_401_UNAUTHORIZED)

        cache.delete(f'2fa_temp_{temp_token}')
        device_id = request.data.get('device_id', str(uuid.uuid4()))
        device, _ = UserDevice.objects.get_or_create(user=user, device_id=device_id)

        view = LoginView()
        return view._generate_tokens_response(user, device, self._get_ip(request), request)

    def _get_ip(self, request):
        return request.META.get('HTTP_X_FORWARDED_FOR', '').split(',')[0] or request.META.get('REMOTE_ADDR')


class TwoFactorSetupView(APIView):
    """GET/POST /auth/2fa/setup - Setup TOTP 2FA"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        import pyotp, qrcode, io, base64
        secret = pyotp.random_base32()
        cache.set(f'2fa_setup_{request.user.id}', secret, timeout=600)

        totp = pyotp.TOTP(secret)
        provisioning_uri = totp.provisioning_uri(
            name=request.user.email,
            issuer_name='APC Private Connect'
        )

        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(provisioning_uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color='black', back_color='white')
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        qr_b64 = base64.b64encode(buffer.getvalue()).decode()

        return Response({
            'secret': secret,
            'qr_code': f'data:image/png;base64,{qr_b64}',
            'backup_codes': [secrets.token_hex(4).upper() for _ in range(10)],
        })

    def post(self, request):
        import pyotp
        secret = cache.get(f'2fa_setup_{request.user.id}')
        if not secret:
            return Response({'success': False, 'message': 'Setup session expired.'})

        code = request.data.get('code')
        totp = pyotp.TOTP(secret)

        if not totp.verify(code, valid_window=1):
            return Response({'success': False, 'message': 'Invalid code.'}, status=400)

        backup_codes = request.data.get('backup_codes', [])
        request.user.two_factor_enabled = True
        request.user.two_factor_secret = secret
        request.user.backup_codes = [hashlib.sha256(c.encode()).hexdigest() for c in backup_codes]
        request.user.save(update_fields=['two_factor_enabled', 'two_factor_secret', 'backup_codes'])

        cache.delete(f'2fa_setup_{request.user.id}')
        audit_logger.log(action='2FA_ENABLED', user=request.user)

        return Response({'success': True, 'message': '2FA enabled successfully.'})


class LogoutView(APIView):
    """POST /auth/logout - Logout and blacklist token"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data.get('refresh_token')
            if refresh_token:
                token = RefreshToken(refresh_token)
                token.blacklist()

            # Mark device as inactive
            device_id = request.data.get('device_id')
            if device_id:
                UserDevice.objects.filter(
                    user=request.user, device_id=device_id
                ).update(is_current=False)

            audit_logger.log(action='USER_LOGOUT', user=request.user)

            return Response({'success': True, 'message': 'Logged out successfully.'})
        except TokenError:
            return Response({'success': True, 'message': 'Logged out.'})


class PasswordResetRequestView(APIView):
    """POST /auth/password/reset/request"""
    permission_classes = [AllowAny]
    throttle_classes = [AuthThrottle]

    def post(self, request):
        email = request.data.get('email', '').lower().strip()

        try:
            user = User.objects.get(email=email, is_active=True)
            otp_service = OTPService()
            otp = otp_service.generate_and_store(
                key=f'password_reset_{user.id}',
                length=6, expiry_minutes=15
            )
            EmailService.send_password_reset(user.email, user.first_name, otp)

            audit_logger.log(action='PASSWORD_RESET_REQUESTED', user=user)
        except User.DoesNotExist:
            pass  # Don't reveal if email exists

        return Response({
            'success': True,
            'message': 'If an account exists with this email, a reset code has been sent.'
        })


class PasswordResetConfirmView(APIView):
    """POST /auth/password/reset/confirm"""
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = PasswordResetSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({'success': False, 'errors': serializer.errors}, status=400)

        email = serializer.validated_data['email']
        otp_code = serializer.validated_data['otp_code']
        new_password = serializer.validated_data['new_password']

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'success': False, 'message': 'Invalid request.'}, status=400)

        otp_service = OTPService()
        if not otp_service.verify(f'password_reset_{user.id}', otp_code):
            return Response({'success': False, 'message': 'Invalid or expired OTP.'}, status=400)

        user.set_password(new_password)
        user.password_changed_at = timezone.now()
        user.save(update_fields=['password', 'password_changed_at'])

        # Invalidate all active sessions
        RefreshToken.for_user(user)

        audit_logger.log(action='PASSWORD_RESET_COMPLETED', user=user)

        return Response({'success': True, 'message': 'Password reset successfully.'})


class ChangePasswordView(APIView):
    """POST /auth/password/change"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data, context={'request': request})
        if not serializer.is_valid():
            return Response({'success': False, 'errors': serializer.errors}, status=400)

        user = request.user
        if not user.check_password(serializer.validated_data['current_password']):
            return Response({'success': False, 'message': 'Current password incorrect.'}, status=400)

        user.set_password(serializer.validated_data['new_password'])
        user.password_changed_at = timezone.now()
        user.save(update_fields=['password', 'password_changed_at'])

        audit_logger.log(action='PASSWORD_CHANGED', user=user)

        return Response({'success': True, 'message': 'Password changed successfully.'})


class EmailVerifyView(APIView):
    """POST /auth/verify/email"""
    permission_classes = [AllowAny]

    def post(self, request):
        user_id = request.data.get('user_id')
        otp_code = request.data.get('otp_code')

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({'success': False, 'message': 'Invalid request.'}, status=400)

        otp_service = OTPService()
        if not otp_service.verify(f'email_verify_{user.id}', otp_code):
            return Response({'success': False, 'message': 'Invalid or expired OTP.'}, status=400)

        user.email_verified = True
        user.save(update_fields=['email_verified'])

        audit_logger.log(action='EMAIL_VERIFIED', user=user)

        return Response({'success': True, 'message': 'Email verified successfully.'})


class ResendOTPView(APIView):
    """POST /auth/otp/resend"""
    permission_classes = [AllowAny]
    throttle_classes = [AuthThrottle]

    def post(self, request):
        otp_type = request.data.get('type')  # email, phone, device
        user_id = request.data.get('user_id')

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({'success': False, 'message': 'Invalid request.'}, status=400)

        otp_service = OTPService()

        if otp_type == 'email':
            # Check resend cooldown
            cooldown_key = f'otp_cooldown_email_{user.id}'
            if cache.get(cooldown_key):
                return Response({'success': False, 'message': 'Please wait before requesting another OTP.'})
            otp = otp_service.generate_and_store(f'email_verify_{user.id}', expiry_minutes=10)
            EmailService.send_email_verification(user.email, user.first_name, otp)
            cache.set(cooldown_key, True, timeout=60)

        elif otp_type == 'phone' and user.phone_number:
            cooldown_key = f'otp_cooldown_phone_{user.id}'
            if cache.get(cooldown_key):
                return Response({'success': False, 'message': 'Please wait before requesting another OTP.'})
            otp = otp_service.generate_and_store(f'phone_verify_{user.id}', expiry_minutes=10)
            SMSService.send_verification(user.phone_number, otp)
            cache.set(cooldown_key, True, timeout=60)

        return Response({'success': True, 'message': 'OTP resent successfully.'})


class SessionListView(APIView):
    """GET /auth/sessions - List all active sessions"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        devices = UserDevice.objects.filter(
            user=request.user, is_current=True
        ).order_by('-last_active')

        data = [{
            'device_id': d.device_id,
            'device_name': d.device_name or 'Unknown Device',
            'device_type': d.device_type,
            'os': d.os,
            'location': d.location,
            'ip_address': d.ip_address,
            'last_active': d.last_active.isoformat(),
            'is_trusted': d.is_trusted,
            'is_current': d.device_id == request.META.get('HTTP_X_DEVICE_ID'),
        } for d in devices]

        return Response({'success': True, 'sessions': data})

    def delete(self, request):
        """Revoke all sessions except current"""
        current_device_id = request.META.get('HTTP_X_DEVICE_ID')
        UserDevice.objects.filter(
            user=request.user, is_current=True
        ).exclude(device_id=current_device_id).update(is_current=False)

        audit_logger.log(action='ALL_SESSIONS_REVOKED', user=request.user)

        return Response({'success': True, 'message': 'All other sessions terminated.'})
