"""
APC Private Connect - Posts & Feed Service
Social feed, post creation, reactions, comments, sharing, feed ranking algorithm
"""

import uuid
import logging
from django.db import models
from django.utils import timezone
from django.core.cache import cache
from django.db.models import F, Q, Count, Avg
from django.conf import settings

from rest_framework import status, generics, filters
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, JSONParser

from apps.users.models import User
from core.utils.audit import AuditLogger
from core.permissions import IsVerifiedMember, IsOwnerOrModerator

logger = logging.getLogger('apc.api')
audit_logger = AuditLogger()


# ═══════════════════════════════════════════════════════════════════════════════
# MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class Post(models.Model):
    """Main post model - supports text, image, video, document, link posts"""

    class PostType(models.TextChoices):
        TEXT = 'text', 'Text Post'
        IMAGE = 'image', 'Image Post'
        VIDEO = 'video', 'Video Post'
        DOCUMENT = 'document', 'Document Post'
        LINK = 'link', 'Link Post'
        POLL = 'poll', 'Poll'
        ANNOUNCEMENT = 'announcement', 'Announcement'
        EVENT = 'event', 'Event'
        AUDIO = 'audio', 'Audio Post'

    class Visibility(models.TextChoices):
        PUBLIC = 'public', 'All Members'
        CONNECTIONS = 'connections', 'Connections Only'
        GROUP = 'group', 'Group Members'
        ADMIN_ONLY = 'admin_only', 'Admins Only'
        PRIVATE = 'private', 'Private'

    class Status(models.TextChoices):
        DRAFT = 'draft', 'Draft'
        PUBLISHED = 'published', 'Published'
        HIDDEN = 'hidden', 'Hidden'
        REMOVED = 'removed', 'Removed by Moderator'
        ARCHIVED = 'archived', 'Archived'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    post_type = models.CharField(max_length=20, choices=PostType.choices, default=PostType.TEXT)

    # Content
    title = models.CharField(max_length=300, blank=True)
    content = models.TextField(max_length=10000)
    formatted_content = models.TextField(blank=True)  # Rich text/HTML
    link_url = models.URLField(blank=True)
    link_preview = models.JSONField(default=dict, blank=True)

    # Group/Location context
    group = models.ForeignKey(
        'groups.Group', null=True, blank=True,
        on_delete=models.SET_NULL, related_name='posts'
    )
    location_tag = models.CharField(max_length=200, blank=True)
    tags = models.JSONField(default=list, blank=True)
    mentions = models.ManyToManyField(User, related_name='mentioned_in', blank=True)

    # Visibility & Status
    visibility = models.CharField(max_length=20, choices=Visibility.choices, default=Visibility.PUBLIC)
    post_status = models.CharField(max_length=20, choices=Status.choices, default=Status.PUBLISHED)
    is_pinned = models.BooleanField(default=False)
    is_featured = models.BooleanField(default=False)
    allow_comments = models.BooleanField(default=True)
    allow_reactions = models.BooleanField(default=True)
    allow_sharing = models.BooleanField(default=True)

    # Engagement metrics (denormalized)
    likes_count = models.PositiveIntegerField(default=0)
    comments_count = models.PositiveIntegerField(default=0)
    shares_count = models.PositiveIntegerField(default=0)
    views_count = models.PositiveIntegerField(default=0)
    saves_count = models.PositiveIntegerField(default=0)
    reactions_count = models.PositiveIntegerField(default=0)

    # Feed algorithm score
    engagement_score = models.FloatField(default=0.0, db_index=True)
    trending_score = models.FloatField(default=0.0)
    relevance_score = models.FloatField(default=0.0)

    # Moderation
    is_reported = models.BooleanField(default=False)
    report_count = models.PositiveSmallIntegerField(default=0)
    moderated_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='moderated_posts'
    )
    moderation_reason = models.TextField(blank=True)

    # Original post (for shares)
    original_post = models.ForeignKey(
        'self', null=True, blank=True, on_delete=models.SET_NULL,
        related_name='shares'
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)
    published_at = models.DateTimeField(null=True, blank=True)
    scheduled_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['-created_at']),
            models.Index(fields=['author', '-created_at']),
            models.Index(fields=['post_status', 'visibility']),
            models.Index(fields=['-engagement_score']),
            models.Index(fields=['group', '-created_at']),
            models.Index(fields=['is_pinned', '-created_at']),
        ]

    def __str__(self):
        return f"{self.author.username}: {self.content[:60]}..."

    def calculate_engagement_score(self):
        """Recalculate the engagement score for feed ranking"""
        from datetime import timedelta
        age_hours = (timezone.now() - self.created_at).total_seconds() / 3600
        decay = 1 / (1 + age_hours / 24)  # 24-hour half-life

        score = (
            self.likes_count * 2.0 +
            self.comments_count * 3.0 +
            self.shares_count * 4.0 +
            self.views_count * 0.1 +
            self.saves_count * 5.0
        ) * decay

        # Boost for verified author
        if self.author.is_verified:
            score *= 1.2
        # Boost for pinned
        if self.is_pinned:
            score *= 2.0

        self.engagement_score = score
        self.save(update_fields=['engagement_score'])
        return score


class PostMedia(models.Model):
    """Media attachments for posts"""

    class MediaType(models.TextChoices):
        IMAGE = 'image', 'Image'
        VIDEO = 'video', 'Video'
        AUDIO = 'audio', 'Audio'
        DOCUMENT = 'document', 'Document'
        THUMBNAIL = 'thumbnail', 'Thumbnail'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='media')
    media_type = models.CharField(max_length=20, choices=MediaType.choices)
    file = models.FileField(upload_to='posts/media/')
    file_name = models.CharField(max_length=255)
    file_size = models.PositiveBigIntegerField()
    mime_type = models.CharField(max_length=100)
    width = models.PositiveIntegerField(null=True, blank=True)
    height = models.PositiveIntegerField(null=True, blank=True)
    duration = models.FloatField(null=True, blank=True)  # seconds
    thumbnail = models.ImageField(upload_to='posts/thumbnails/', null=True, blank=True)
    cdn_url = models.URLField(blank=True)
    is_processed = models.BooleanField(default=False)
    processing_status = models.CharField(max_length=20, default='pending')
    order = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['order', 'created_at']


class Reaction(models.Model):
    """Post reactions (like, love, haha, wow, sad, angry)"""

    class ReactionType(models.TextChoices):
        LIKE = 'like', '👍 Like'
        LOVE = 'love', '❤️ Love'
        HAHA = 'haha', '😄 Haha'
        WOW = 'wow', '😮 Wow'
        SAD = 'sad', '😢 Sad'
        ANGRY = 'angry', '😠 Angry'
        SUPPORT = 'support', '🤝 Support'
        CELEBRATE = 'celebrate', '🎉 Celebrate'

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reactions')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='reactions')
    reaction_type = models.CharField(max_length=20, choices=ReactionType.choices, default=ReactionType.LIKE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'post']
        indexes = [
            models.Index(fields=['post', 'reaction_type']),
            models.Index(fields=['user', 'post']),
        ]


class Comment(models.Model):
    """Comments on posts with nested reply support"""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    content = models.TextField(max_length=2000)
    parent = models.ForeignKey(
        'self', null=True, blank=True, on_delete=models.CASCADE,
        related_name='replies'
    )
    mentions = models.ManyToManyField(User, related_name='comment_mentions', blank=True)
    likes_count = models.PositiveIntegerField(default=0)
    replies_count = models.PositiveIntegerField(default=0)
    is_edited = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    is_pinned = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['post', 'created_at']),
            models.Index(fields=['post', 'parent']),
        ]


class CommentLike(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'comment']


class PostSave(models.Model):
    """Saved posts"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='saved_posts')
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    saved_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'post']


class Poll(models.Model):
    """Polls attached to posts"""

    post = models.OneToOneField(Post, on_delete=models.CASCADE, related_name='poll')
    question = models.CharField(max_length=500)
    allow_multiple = models.BooleanField(default=False)
    show_results_before_vote = models.BooleanField(default=False)
    closes_at = models.DateTimeField(null=True, blank=True)
    total_votes = models.PositiveIntegerField(default=0)

    @property
    def is_active(self):
        return not self.closes_at or self.closes_at > timezone.now()


class PollOption(models.Model):
    poll = models.ForeignKey(Poll, on_delete=models.CASCADE, related_name='options')
    text = models.CharField(max_length=200)
    votes_count = models.PositiveIntegerField(default=0)
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ['order']


class PollVote(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    poll = models.ForeignKey(Poll, on_delete=models.CASCADE)
    option = models.ForeignKey(PollOption, on_delete=models.CASCADE)
    voted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'poll', 'option']


class PostView(models.Model):
    """Track post views"""
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='views')
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    ip_address = models.GenericIPAddressField(null=True)
    viewed_at = models.DateTimeField(auto_now_add=True)
    duration_seconds = models.PositiveIntegerField(default=0)

    class Meta:
        indexes = [models.Index(fields=['post', 'viewed_at'])]


class PostReport(models.Model):
    """Report inappropriate posts"""

    class Reason(models.TextChoices):
        SPAM = 'spam', 'Spam'
        MISINFORMATION = 'misinformation', 'Misinformation'
        HATE_SPEECH = 'hate_speech', 'Hate Speech'
        HARASSMENT = 'harassment', 'Harassment'
        INAPPROPRIATE = 'inappropriate', 'Inappropriate Content'
        OTHER = 'other', 'Other'

    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='reports')
    reporter = models.ForeignKey(User, on_delete=models.CASCADE)
    reason = models.CharField(max_length=30, choices=Reason.choices)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)

    class Meta:
        unique_together = ['post', 'reporter']


# ═══════════════════════════════════════════════════════════════════════════════
# FEED ALGORITHM
# ═══════════════════════════════════════════════════════════════════════════════

class FeedAlgorithm:
    """
    Intelligent feed ranking algorithm
    Combines recency, engagement, relationship, and relevance signals
    """

    WEIGHTS = {
        'recency': 0.3,
        'engagement': 0.35,
        'relationship': 0.2,
        'relevance': 0.15,
    }

    @classmethod
    def get_user_feed(cls, user, page=1, page_size=20, feed_type='home'):
        """Generate personalized feed for user"""
        cache_key = f'feed_{user.id}_{feed_type}_{page}'
        cached = cache.get(cache_key)
        if cached and page > 1:
            return cached

        # Base queryset
        qs = Post.objects.filter(
            post_status=Post.Status.PUBLISHED,
        ).select_related('author', 'author__profile', 'group').prefetch_related('media')

        if feed_type == 'home':
            qs = cls._filter_home_feed(user, qs)
        elif feed_type == 'trending':
            qs = qs.filter(visibility=Post.Visibility.PUBLIC).order_by('-trending_score')
        elif feed_type == 'following':
            following_ids = user.following.values_list('following_id', flat=True)
            qs = qs.filter(author__in=following_ids)
        elif feed_type == 'state':
            qs = qs.filter(author__state=user.state)

        # Apply feed ranking
        posts = list(qs[:page_size * 3])
        ranked = cls._rank_posts(user, posts)
        page_posts = ranked[(page-1)*page_size : page*page_size]

        # Always put pinned posts first on page 1
        if page == 1:
            pinned = list(qs.filter(is_pinned=True, visibility=Post.Visibility.PUBLIC)[:3])
            page_posts = pinned + [p for p in page_posts if not p.is_pinned]

        cache.set(cache_key, page_posts, timeout=settings.APC_SETTINGS['POST_FEED_CACHE_TTL'])
        return page_posts

    @classmethod
    def _filter_home_feed(cls, user, qs):
        following_ids = list(user.following.values_list('following_id', flat=True))
        return qs.filter(
            Q(author__in=following_ids) |
            Q(visibility=Post.Visibility.PUBLIC) |
            Q(group__members=user)
        ).distinct()

    @classmethod
    def _rank_posts(cls, user, posts):
        """Score and rank posts for a user"""
        scored = []
        following_ids = set(user.following.values_list('following_id', flat=True))

        for post in posts:
            score = cls._calculate_score(user, post, following_ids)
            scored.append((score, post))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [p for _, p in scored]

    @classmethod
    def _calculate_score(cls, user, post, following_ids):
        """Multi-factor post scoring"""
        now = timezone.now()
        age_hours = max((now - post.created_at).total_seconds() / 3600, 0.1)

        # Recency score (decays over time)
        recency = 1.0 / (1.0 + age_hours / 12)

        # Engagement score (normalized)
        engagement = min(1.0, (
            post.likes_count * 0.2 +
            post.comments_count * 0.4 +
            post.shares_count * 0.3 +
            post.views_count * 0.01
        ) / 100)

        # Relationship score
        relationship = 0.0
        if post.author_id == user.id:
            relationship = 0.5
        elif post.author_id in following_ids:
            relationship = 1.0
        elif post.author.state == user.state:
            relationship = 0.3

        # Relevance score (tag matching, location)
        relevance = 0.0
        if user.state and post.author.state == user.state:
            relevance += 0.5
        if user.lga and post.author.lga == user.lga:
            relevance += 0.5

        final_score = (
            recency * cls.WEIGHTS['recency'] +
            engagement * cls.WEIGHTS['engagement'] +
            relationship * cls.WEIGHTS['relationship'] +
            relevance * cls.WEIGHTS['relevance']
        )

        return final_score


# ═══════════════════════════════════════════════════════════════════════════════
# API VIEWS
# ═══════════════════════════════════════════════════════════════════════════════

class FeedView(APIView):
    """GET /posts/feed - Get personalized feed"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        page = int(request.query_params.get('page', 1))
        feed_type = request.query_params.get('type', 'home')
        page_size = min(int(request.query_params.get('page_size', 20)), 50)

        posts = FeedAlgorithm.get_user_feed(request.user, page, page_size, feed_type)

        from .serializers import PostListSerializer
        serializer = PostListSerializer(posts, many=True, context={'request': request})

        return Response({
            'success': True,
            'feed_type': feed_type,
            'page': page,
            'count': len(posts),
            'posts': serializer.data,
        })


class PostCreateView(APIView):
    """POST /posts/create - Create a new post"""
    permission_classes = [IsAuthenticated, IsVerifiedMember]
    parser_classes = [MultiPartParser, JSONParser]

    def post(self, request):
        user = request.user
        content = request.data.get('content', '').strip()
        post_type = request.data.get('post_type', Post.PostType.TEXT)

        if not content and post_type == Post.PostType.TEXT:
            return Response({'success': False, 'message': 'Post content is required.'}, status=400)

        # Create post
        post = Post.objects.create(
            author=user,
            post_type=post_type,
            title=request.data.get('title', ''),
            content=content,
            link_url=request.data.get('link_url', ''),
            visibility=request.data.get('visibility', Post.Visibility.PUBLIC),
            allow_comments=request.data.get('allow_comments', True),
            allow_reactions=request.data.get('allow_reactions', True),
            tags=request.data.get('tags', []),
            location_tag=request.data.get('location_tag', ''),
            published_at=timezone.now(),
        )

        # Handle group post
        group_id = request.data.get('group_id')
        if group_id:
            from apps.groups.models import Group, GroupMember
            try:
                group = Group.objects.get(id=group_id)
                if not group.members.filter(user=user).exists():
                    return Response({'success': False, 'message': 'Not a member of this group.'}, status=403)
                post.group = group
                post.visibility = Post.Visibility.GROUP
                post.save(update_fields=['group', 'visibility'])
            except Group.DoesNotExist:
                pass

        # Handle media attachments
        files = request.FILES.getlist('media')
        for i, file in enumerate(files[:10]):  # Max 10 files
            mime_type = file.content_type
            if mime_type not in settings.APC_SETTINGS['ALLOWED_MEDIA_TYPES']:
                continue
            if file.size > settings.APC_SETTINGS['MAX_POST_MEDIA_SIZE']:
                continue

            media_type = 'image' if mime_type.startswith('image') else \
                        'video' if mime_type.startswith('video') else \
                        'audio' if mime_type.startswith('audio') else 'document'

            PostMedia.objects.create(
                post=post,
                media_type=media_type,
                file=file,
                file_name=file.name,
                file_size=file.size,
                mime_type=mime_type,
                order=i,
            )

        # Handle poll
        poll_data = request.data.get('poll')
        if poll_data and post_type == Post.PostType.POLL:
            poll = Poll.objects.create(
                post=post,
                question=poll_data.get('question', content),
                allow_multiple=poll_data.get('allow_multiple', False),
                closes_at=poll_data.get('closes_at'),
            )
            for idx, option_text in enumerate(poll_data.get('options', [])):
                PollOption.objects.create(poll=poll, text=option_text, order=idx)

        # Update user post count
        User.objects.filter(id=user.id).update(posts_count=F('posts_count') + 1)

        # Queue background tasks
        from infrastructure.celery_tasks.posts import process_post_media, update_feed_cache
        process_post_media.delay(str(post.id))
        update_feed_cache.delay(str(user.id))

        # Send notifications to followers
        from infrastructure.celery_tasks.notifications import notify_followers_new_post
        notify_followers_new_post.delay(str(user.id), str(post.id))

        audit_logger.log(action='POST_CREATED', user=user, details={'post_id': str(post.id)})

        from .serializers import PostDetailSerializer
        serializer = PostDetailSerializer(post, context={'request': request})
        return Response({'success': True, 'post': serializer.data}, status=201)


class PostDetailView(APIView):
    """GET/PUT/DELETE /posts/<post_id>"""
    permission_classes = [IsAuthenticated]

    def get(self, request, post_id):
        post = self._get_post(post_id, request.user)
        if not post:
            return Response({'success': False, 'message': 'Post not found.'}, status=404)

        # Record view
        PostView.objects.get_or_create(post=post, user=request.user)
        Post.objects.filter(id=post_id).update(views_count=F('views_count') + 1)

        from .serializers import PostDetailSerializer
        return Response({'success': True, 'post': PostDetailSerializer(post, context={'request': request}).data})

    def put(self, request, post_id):
        post = self._get_post(post_id, request.user)
        if not post or post.author != request.user:
            return Response({'success': False, 'message': 'Not authorized.'}, status=403)

        content = request.data.get('content')
        if content:
            post.content = content
        post.title = request.data.get('title', post.title)
        post.tags = request.data.get('tags', post.tags)
        post.visibility = request.data.get('visibility', post.visibility)
        post.save()

        cache.delete(f'post_{post_id}')
        return Response({'success': True, 'message': 'Post updated.'})

    def delete(self, request, post_id):
        post = self._get_post(post_id, request.user)
        if not post:
            return Response({'success': False, 'message': 'Post not found.'}, status=404)

        if post.author != request.user and not request.user.has_role_permission('moderate_content'):
            return Response({'success': False, 'message': 'Not authorized.'}, status=403)

        post.post_status = Post.Status.REMOVED
        post.save(update_fields=['post_status'])

        User.objects.filter(id=post.author.id).update(posts_count=F('posts_count') - 1)
        audit_logger.log(action='POST_DELETED', user=request.user, details={'post_id': str(post_id)})

        return Response({'success': True, 'message': 'Post removed.'})

    def _get_post(self, post_id, user):
        try:
            return Post.objects.get(id=post_id, post_status__in=['published', 'draft'])
        except Post.DoesNotExist:
            return None


class ReactionView(APIView):
    """POST /posts/<post_id>/react - React to a post"""
    permission_classes = [IsAuthenticated]

    def post(self, request, post_id):
        try:
            post = Post.objects.get(id=post_id, post_status='published')
        except Post.DoesNotExist:
            return Response({'success': False, 'message': 'Post not found.'}, status=404)

        reaction_type = request.data.get('reaction_type', Reaction.ReactionType.LIKE)

        existing = Reaction.objects.filter(user=request.user, post=post).first()

        if existing:
            if existing.reaction_type == reaction_type:
                existing.delete()
                Post.objects.filter(id=post_id).update(
                    reactions_count=F('reactions_count') - 1,
                    likes_count=F('likes_count') - 1
                )
                return Response({'success': True, 'action': 'removed', 'reaction_type': reaction_type})
            else:
                old_type = existing.reaction_type
                existing.reaction_type = reaction_type
                existing.save()
                return Response({'success': True, 'action': 'changed', 'reaction_type': reaction_type})
        else:
            Reaction.objects.create(user=request.user, post=post, reaction_type=reaction_type)
            Post.objects.filter(id=post_id).update(
                reactions_count=F('reactions_count') + 1,
                likes_count=F('likes_count') + 1
            )

            # Notify post author
            from infrastructure.celery_tasks.notifications import send_reaction_notification
            send_reaction_notification.delay(str(request.user.id), str(post_id), reaction_type)

            return Response({'success': True, 'action': 'added', 'reaction_type': reaction_type})


class CommentView(APIView):
    """GET /posts/<post_id>/comments - List & create comments"""
    permission_classes = [IsAuthenticated]

    def get(self, request, post_id):
        parent_id = request.query_params.get('parent_id')
        page = int(request.query_params.get('page', 1))
        size = min(int(request.query_params.get('size', 20)), 50)

        qs = Comment.objects.filter(
            post_id=post_id,
            parent_id=parent_id,
            is_deleted=False
        ).select_related('author', 'author__profile').order_by('-created_at')

        total = qs.count()
        comments = qs[(page-1)*size:page*size]

        data = [{
            'id': str(c.id),
            'content': c.content,
            'author': {
                'id': str(c.author.id),
                'username': c.author.username,
                'full_name': c.author.get_full_name(),
                'avatar': c.author.profile.profile_picture.url if hasattr(c.author, 'profile') and c.author.profile.profile_picture else None,
                'is_verified': c.author.is_verified,
            },
            'likes_count': c.likes_count,
            'replies_count': c.replies_count,
            'is_edited': c.is_edited,
            'is_pinned': c.is_pinned,
            'created_at': c.created_at.isoformat(),
        } for c in comments]

        return Response({'success': True, 'total': total, 'page': page, 'comments': data})

    def post(self, request, post_id):
        try:
            post = Post.objects.get(id=post_id, post_status='published', allow_comments=True)
        except Post.DoesNotExist:
            return Response({'success': False, 'message': 'Post not found or comments disabled.'}, status=404)

        content = request.data.get('content', '').strip()
        if not content:
            return Response({'success': False, 'message': 'Comment content required.'}, status=400)

        parent_id = request.data.get('parent_id')
        parent = None
        if parent_id:
            try:
                parent = Comment.objects.get(id=parent_id, post=post)
            except Comment.DoesNotExist:
                return Response({'success': False, 'message': 'Parent comment not found.'}, status=404)

        comment = Comment.objects.create(
            post=post,
            author=request.user,
            content=content,
            parent=parent
        )

        Post.objects.filter(id=post_id).update(comments_count=F('comments_count') + 1)
        if parent:
            Comment.objects.filter(id=parent_id).update(replies_count=F('replies_count') + 1)

        # Notify post author
        from infrastructure.celery_tasks.notifications import send_comment_notification
        send_comment_notification.delay(str(request.user.id), str(post_id), str(comment.id))

        return Response({
            'success': True,
            'comment': {
                'id': str(comment.id),
                'content': comment.content,
                'created_at': comment.created_at.isoformat(),
            }
        }, status=201)


class PollVoteView(APIView):
    """POST /posts/<post_id>/poll/vote"""
    permission_classes = [IsAuthenticated]

    def post(self, request, post_id):
        option_ids = request.data.get('option_ids', [])
        if not option_ids:
            return Response({'success': False, 'message': 'Select at least one option.'}, status=400)

        try:
            post = Post.objects.get(id=post_id)
            poll = post.poll
        except (Post.DoesNotExist, Poll.DoesNotExist):
            return Response({'success': False, 'message': 'Poll not found.'}, status=404)

        if not poll.is_active:
            return Response({'success': False, 'message': 'This poll has ended.'}, status=400)

        if not poll.allow_multiple and len(option_ids) > 1:
            return Response({'success': False, 'message': 'Single choice poll only.'}, status=400)

        # Remove existing votes
        PollVote.objects.filter(user=request.user, poll=poll).delete()

        for option_id in option_ids:
            try:
                option = PollOption.objects.get(id=option_id, poll=poll)
                PollVote.objects.create(user=request.user, poll=poll, option=option)
                PollOption.objects.filter(id=option_id).update(votes_count=F('votes_count') + 1)
            except PollOption.DoesNotExist:
                pass

        Poll.objects.filter(id=poll.id).update(total_votes=F('total_votes') + 1)

        return Response({'success': True, 'message': 'Vote recorded.'})


class SavePostView(APIView):
    """POST /posts/<post_id>/save"""
    permission_classes = [IsAuthenticated]

    def post(self, request, post_id):
        try:
            post = Post.objects.get(id=post_id)
        except Post.DoesNotExist:
            return Response({'success': False, 'message': 'Post not found.'}, status=404)

        save, created = PostSave.objects.get_or_create(user=request.user, post=post)

        if not created:
            save.delete()
            Post.objects.filter(id=post_id).update(saves_count=F('saves_count') - 1)
            return Response({'success': True, 'saved': False})

        Post.objects.filter(id=post_id).update(saves_count=F('saves_count') + 1)
        return Response({'success': True, 'saved': True})
