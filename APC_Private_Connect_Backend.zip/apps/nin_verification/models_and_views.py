"""
APC Private Connect - NIN Verification Service
NIMC API integration, biometric verification, identity management
"""

import uuid
import hashlib
import base64
import logging
import requests
from datetime import datetime

from django.db import models
from django.utils import timezone
from django.conf import settings
from django.core.cache import cache

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.throttling import UserRateThrottle

from apps.users.models import User
from core.utils.audit import AuditLogger
from core.utils.encryption import EncryptionService

logger = logging.getLogger('apc.api')
security_logger = logging.getLogger('apc.security')
audit_logger = AuditLogger()


# ═══════════════════════════════════════════════════════════════════════════════
# MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class NINVerification(models.Model):
    """NIN verification record for each user"""

    class VerificationStatus(models.TextChoices):
        PENDING = 'pending', 'Pending'
        IN_PROGRESS = 'in_progress', 'In Progress'
        VERIFIED = 'verified', 'Verified'
        FAILED = 'failed', 'Failed'
        EXPIRED = 'expired', 'Expired'
        FLAGGED = 'flagged', 'Flagged - Manual Review Required'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='nin_verification')
    nin_number = models.CharField(max_length=11, db_index=True)
    nin_hash = models.CharField(max_length=64, unique=True)  # SHA-256 hash for dedup
    status = models.CharField(
        max_length=20, choices=VerificationStatus.choices,
        default=VerificationStatus.PENDING
    )

    # NIMC Response Data (encrypted)
    nimc_first_name = models.CharField(max_length=100, blank=True)
    nimc_last_name = models.CharField(max_length=100, blank=True)
    nimc_middle_name = models.CharField(max_length=100, blank=True)
    nimc_date_of_birth = models.DateField(null=True, blank=True)
    nimc_gender = models.CharField(max_length=20, blank=True)
    nimc_phone = models.CharField(max_length=20, blank=True)
    nimc_address = models.TextField(blank=True)
    nimc_state_of_origin = models.CharField(max_length=100, blank=True)
    nimc_lga_of_origin = models.CharField(max_length=100, blank=True)
    nimc_photo_url = models.URLField(blank=True)

    # Verification details
    name_match_score = models.FloatField(null=True, blank=True)  # 0.0 - 1.0
    dob_match = models.BooleanField(null=True)
    verified_by = models.CharField(max_length=100, blank=True)  # system/admin
    verified_at = models.DateTimeField(null=True, blank=True)
    failure_reason = models.TextField(blank=True)
    attempts = models.PositiveSmallIntegerField(default=0)
    max_attempts = models.PositiveSmallIntegerField(default=3)

    # Admin override
    manually_verified = models.BooleanField(default=False)
    manually_verified_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='nin_verifications_approved'
    )
    manual_verification_notes = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'NIN Verification'
        indexes = [
            models.Index(fields=['nin_number']),
            models.Index(fields=['status']),
            models.Index(fields=['user', 'status']),
        ]

    def __str__(self):
        return f"NIN Verification: {self.user.username} - {self.status}"

    @staticmethod
    def hash_nin(nin_number):
        return hashlib.sha256(nin_number.encode()).hexdigest()


class FingerprintRecord(models.Model):
    """Biometric fingerprint enrollment record"""

    class FingerType(models.TextChoices):
        RIGHT_THUMB = 'right_thumb', 'Right Thumb'
        LEFT_THUMB = 'left_thumb', 'Left Thumb'
        RIGHT_INDEX = 'right_index', 'Right Index'
        LEFT_INDEX = 'left_index', 'Left Index'

    class Status(models.TextChoices):
        ENROLLED = 'enrolled', 'Enrolled'
        PENDING = 'pending', 'Pending Enrollment'
        FAILED = 'failed', 'Failed'
        REVOKED = 'revoked', 'Revoked'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='fingerprints')
    finger_type = models.CharField(max_length=20, choices=FingerType.choices)
    template_hash = models.CharField(max_length=128)  # Encrypted fingerprint template hash
    quality_score = models.FloatField(default=0.0)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    enrolled_at = models.DateTimeField(auto_now_add=True)
    last_used = models.DateTimeField(null=True, blank=True)
    device_id = models.CharField(max_length=255, blank=True)

    class Meta:
        unique_together = ['user', 'finger_type']
        indexes = [models.Index(fields=['user', 'status'])]

    def __str__(self):
        return f"{self.user.username} - {self.finger_type}"


class VerificationAttempt(models.Model):
    """Log every verification attempt for audit/security"""

    class AttemptType(models.TextChoices):
        NIN = 'nin', 'NIN Verification'
        FINGERPRINT = 'fingerprint', 'Fingerprint Verification'
        ADMIN_ACTION = 'admin_action', 'Admin Action Verification'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='verification_attempts')
    attempt_type = models.CharField(max_length=20, choices=AttemptType.choices)
    success = models.BooleanField()
    ip_address = models.GenericIPAddressField(null=True)
    device_id = models.CharField(max_length=255, blank=True)
    match_score = models.FloatField(null=True)
    failure_reason = models.CharField(max_length=200, blank=True)
    metadata = models.JSONField(default=dict)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']
        indexes = [models.Index(fields=['user', 'attempt_type', 'timestamp'])]


# ═══════════════════════════════════════════════════════════════════════════════
# NIMC API SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

class NIMCService:
    """
    NIMC (National Identity Management Commission) API Integration
    Handles NIN verification against national database
    """

    BASE_URL = settings.NIMC_API_BASE_URL
    API_KEY = settings.NIMC_API_KEY
    API_SECRET = settings.NIMC_API_SECRET

    HEADERS = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }

    @classmethod
    def verify_nin(cls, nin_number, first_name=None, last_name=None, dob=None):
        """
        Verify NIN against NIMC national database
        Returns verification result dict
        """
        if not settings.NIN_VERIFICATION_ENABLED:
            # In development, return mock verified response
            return cls._mock_verify(nin_number, first_name, last_name)

        try:
            # Generate auth token
            auth_token = cls._generate_auth_token()

            payload = {
                'nin': nin_number,
                'firstName': first_name,
                'lastName': last_name,
                'dateOfBirth': dob.isoformat() if dob else None,
            }

            response = requests.post(
                f'{cls.BASE_URL}/verify',
                json=payload,
                headers={**cls.HEADERS, 'Authorization': f'Bearer {auth_token}'},
                timeout=30,
            )

            if response.status_code == 200:
                data = response.json()
                return {
                    'success': True,
                    'verified': data.get('verified', False),
                    'nin_data': {
                        'first_name': data.get('firstName', ''),
                        'last_name': data.get('lastName', ''),
                        'middle_name': data.get('middleName', ''),
                        'date_of_birth': data.get('dateOfBirth'),
                        'gender': data.get('gender', ''),
                        'phone': data.get('phone', ''),
                        'address': data.get('address', ''),
                        'state_of_origin': data.get('stateOfOrigin', ''),
                        'lga_of_origin': data.get('lgaOfOrigin', ''),
                        'photo': data.get('photo', ''),
                    },
                    'match_score': data.get('matchScore', 0.0),
                    'name_match': data.get('nameMatch', False),
                    'dob_match': data.get('dobMatch', False),
                }

            elif response.status_code == 404:
                return {'success': False, 'error': 'NIN not found in national database'}
            elif response.status_code == 429:
                return {'success': False, 'error': 'Rate limit exceeded. Try again later.'}
            else:
                logger.error(f"NIMC API error: {response.status_code} - {response.text}")
                return {'success': False, 'error': 'NIMC verification service unavailable'}

        except requests.exceptions.Timeout:
            logger.error("NIMC API timeout")
            return {'success': False, 'error': 'Verification service timeout. Try again.'}
        except Exception as e:
            logger.error(f"NIMC API exception: {str(e)}")
            return {'success': False, 'error': 'Verification failed. Try again.'}

    @classmethod
    def _generate_auth_token(cls):
        import hmac, time
        timestamp = str(int(time.time()))
        signature = hmac.new(
            cls.API_SECRET.encode(),
            f'{cls.API_KEY}{timestamp}'.encode(),
            hashlib.sha256
        ).hexdigest()
        return base64.b64encode(f'{cls.API_KEY}:{timestamp}:{signature}'.encode()).decode()

    @classmethod
    def _mock_verify(cls, nin, first_name=None, last_name=None):
        """Development mock - simulates NIMC response"""
        return {
            'success': True,
            'verified': True,
            'nin_data': {
                'first_name': first_name or 'John',
                'last_name': last_name or 'Doe',
                'middle_name': 'Emmanuel',
                'date_of_birth': '1985-03-15',
                'gender': 'male',
                'phone': '',
                'address': 'Lagos, Nigeria',
                'state_of_origin': 'Lagos',
                'lga_of_origin': 'Ikeja',
                'photo': '',
            },
            'match_score': 0.95,
            'name_match': True,
            'dob_match': True,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# FINGERPRINT SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

class FingerprintService:
    """
    Biometric fingerprint processing service
    Handles enrollment, verification, and template management
    """

    MIN_QUALITY_SCORE = 0.6
    MATCH_THRESHOLD = 0.85

    @classmethod
    def enroll(cls, user, finger_type, template_data, quality_score, device_id):
        """
        Enroll a fingerprint template for a user
        """
        if quality_score < cls.MIN_QUALITY_SCORE:
            return {
                'success': False,
                'error': f'Fingerprint quality too low ({quality_score:.0%}). Please try again.'
            }

        # Hash the template for storage
        template_hash = cls._hash_template(template_data)

        # Check for duplicate fingerprint (prevent multi-account)
        duplicate = FingerprintRecord.objects.filter(
            template_hash=template_hash, status='enrolled'
        ).exclude(user=user).first()

        if duplicate:
            security_logger.warning(
                f"Duplicate fingerprint detected: user {user.id} matches user {duplicate.user.id}"
            )
            return {
                'success': False,
                'error': 'This fingerprint is already registered to another account.',
                'duplicate_detected': True
            }

        # Save fingerprint
        record, created = FingerprintRecord.objects.update_or_create(
            user=user, finger_type=finger_type,
            defaults={
                'template_hash': template_hash,
                'quality_score': quality_score,
                'status': FingerprintRecord.Status.ENROLLED,
                'device_id': device_id,
            }
        )

        # Update user fingerprint status
        enrolled_count = FingerprintRecord.objects.filter(
            user=user, status='enrolled'
        ).count()

        if enrolled_count >= 1:
            user.fingerprint_enrolled = True
            if user.nin_verified:
                user.verification_status = User.VerificationStatus.FULLY_VERIFIED
                user.is_verified = True
            else:
                user.verification_status = User.VerificationStatus.FINGERPRINT_VERIFIED
            user.save(update_fields=['fingerprint_enrolled', 'verification_status', 'is_verified'])

        audit_logger.log(
            action='FINGERPRINT_ENROLLED',
            user=user,
            details={'finger_type': finger_type, 'quality': quality_score}
        )

        return {
            'success': True,
            'message': 'Fingerprint enrolled successfully.',
            'finger_type': finger_type,
            'quality_score': quality_score,
            'total_enrolled': enrolled_count,
        }

    @classmethod
    def verify(cls, user, template_data):
        """
        Verify a fingerprint against enrolled templates
        """
        template_hash = cls._hash_template(template_data)

        enrolled = FingerprintRecord.objects.filter(user=user, status='enrolled')
        if not enrolled.exists():
            return {'success': False, 'verified': False, 'error': 'No fingerprint enrolled'}

        # Check against all enrolled fingerprints
        for record in enrolled:
            score = cls._calculate_match_score(template_hash, record.template_hash)
            if score >= cls.MATCH_THRESHOLD:
                record.last_used = timezone.now()
                record.save(update_fields=['last_used'])

                VerificationAttempt.objects.create(
                    user=user, attempt_type='fingerprint',
                    success=True, match_score=score
                )
                return {'success': True, 'verified': True, 'match_score': score}

        VerificationAttempt.objects.create(
            user=user, attempt_type='fingerprint',
            success=False, failure_reason='No match found'
        )
        return {'success': True, 'verified': False, 'error': 'Fingerprint does not match'}

    @staticmethod
    def _hash_template(template_data):
        if isinstance(template_data, str):
            template_data = template_data.encode()
        return hashlib.sha256(template_data).hexdigest()

    @staticmethod
    def _calculate_match_score(hash1, hash2):
        """Simplified match - in production use actual biometric SDK"""
        if hash1 == hash2:
            return 1.0
        # In real implementation, use biometric template matching library
        return 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# API VIEWS
# ═══════════════════════════════════════════════════════════════════════════════

class NINThrottle(UserRateThrottle):
    rate = '5/hour'


class NINVerifyView(APIView):
    """POST /verification/nin/submit - Submit NIN for verification"""
    permission_classes = [IsAuthenticated]
    throttle_classes = [NINThrottle]

    def post(self, request):
        user = request.user
        nin_number = request.data.get('nin_number', '').strip()

        # Validate NIN format
        if not nin_number or len(nin_number) != 11 or not nin_number.isdigit():
            return Response({
                'success': False,
                'message': 'NIN must be exactly 11 digits.'
            }, status=400)

        # Check if already verified
        if user.nin_verified:
            return Response({
                'success': False,
                'message': 'NIN already verified for this account.'
            }, status=400)

        # Check for NIN already used
        nin_hash = NINVerification.hash_nin(nin_number)
        existing = NINVerification.objects.filter(
            nin_hash=nin_hash, status='verified'
        ).exclude(user=user).first()

        if existing:
            security_logger.warning(f"Duplicate NIN attempt: user {user.id}, NIN hash {nin_hash[:8]}...")
            audit_logger.log(
                action='DUPLICATE_NIN_DETECTED',
                user=user,
                details={'nin_hash': nin_hash[:8]}
            )
            return Response({
                'success': False,
                'message': 'This NIN is already registered to another account.'
            }, status=400)

        # Check attempt limits
        nin_record, created = NINVerification.objects.get_or_create(
            user=user,
            defaults={'nin_number': nin_number, 'nin_hash': nin_hash}
        )

        if nin_record.attempts >= nin_record.max_attempts:
            return Response({
                'success': False,
                'message': 'Maximum verification attempts reached. Contact support.'
            }, status=429)

        nin_record.attempts += 1
        nin_record.status = NINVerification.VerificationStatus.IN_PROGRESS
        nin_record.save()

        # Call NIMC API
        result = NIMCService.verify_nin(
            nin_number,
            first_name=user.first_name,
            last_name=user.last_name,
            dob=user.date_of_birth
        )

        if not result['success']:
            nin_record.status = NINVerification.VerificationStatus.FAILED
            nin_record.failure_reason = result.get('error', 'Unknown error')
            nin_record.save()

            return Response({
                'success': False,
                'message': result.get('error', 'Verification failed.'),
                'attempts_remaining': nin_record.max_attempts - nin_record.attempts
            }, status=400)

        if not result['verified']:
            nin_record.status = NINVerification.VerificationStatus.FAILED
            nin_record.failure_reason = 'NIN details do not match records'
            nin_record.save()
            return Response({'success': False, 'message': 'NIN verification failed. Details do not match.'}, status=400)

        # Success - Save NIMC data
        nin_data = result['nin_data']
        nin_record.status = NINVerification.VerificationStatus.VERIFIED
        nin_record.nin_number = nin_number
        nin_record.nin_hash = nin_hash
        nin_record.nimc_first_name = nin_data['first_name']
        nin_record.nimc_last_name = nin_data['last_name']
        nin_record.nimc_middle_name = nin_data.get('middle_name', '')
        nin_record.nimc_gender = nin_data.get('gender', '')
        nin_record.nimc_state_of_origin = nin_data.get('state_of_origin', '')
        nin_record.nimc_lga_of_origin = nin_data.get('lga_of_origin', '')
        nin_record.name_match_score = result.get('match_score', 0)
        nin_record.dob_match = result.get('dob_match', False)
        nin_record.verified_at = timezone.now()
        nin_record.verified_by = 'system'
        nin_record.save()

        # Update user
        user.nin_number = nin_number
        user.nin_verified = True
        if user.fingerprint_enrolled:
            user.verification_status = User.VerificationStatus.FULLY_VERIFIED
            user.is_verified = True
        else:
            user.verification_status = User.VerificationStatus.NIN_VERIFIED
        user.save(update_fields=['nin_number', 'nin_verified', 'verification_status', 'is_verified'])

        VerificationAttempt.objects.create(
            user=user, attempt_type='nin', success=True,
            match_score=result.get('match_score'),
            ip_address=request.META.get('REMOTE_ADDR')
        )

        audit_logger.log(action='NIN_VERIFIED', user=user)

        return Response({
            'success': True,
            'message': 'NIN verified successfully.',
            'verification_status': user.verification_status,
            'name_match_score': result.get('match_score'),
            'next_step': 'fingerprint_enrollment' if not user.fingerprint_enrolled else None
        })


class NINStatusView(APIView):
    """GET /verification/nin/status"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            record = NINVerification.objects.get(user=request.user)
            return Response({
                'success': True,
                'status': record.status,
                'verified_at': record.verified_at.isoformat() if record.verified_at else None,
                'attempts': record.attempts,
                'attempts_remaining': record.max_attempts - record.attempts,
                'failure_reason': record.failure_reason if record.status == 'failed' else None,
            })
        except NINVerification.DoesNotExist:
            return Response({'success': True, 'status': 'not_submitted'})


class FingerprintEnrollView(APIView):
    """POST /verification/fingerprint/enroll"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        finger_type = request.data.get('finger_type', 'right_thumb')
        template_data = request.data.get('template_data')
        quality_score = float(request.data.get('quality_score', 0.0))
        device_id = request.data.get('device_id', '')

        if not template_data:
            return Response({'success': False, 'message': 'Fingerprint template data required.'}, status=400)

        valid_fingers = [c.value for c in FingerprintRecord.FingerType]
        if finger_type not in valid_fingers:
            return Response({'success': False, 'message': f'Invalid finger type. Choose from: {valid_fingers}'}, status=400)

        result = FingerprintService.enroll(user, finger_type, template_data, quality_score, device_id)
        http_status = 201 if result['success'] else 400
        return Response(result, status=http_status)


class FingerprintVerifyView(APIView):
    """POST /verification/fingerprint/verify - Verify fingerprint for admin actions"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        template_data = request.data.get('template_data')
        if not template_data:
            return Response({'success': False, 'message': 'Fingerprint data required.'}, status=400)

        result = FingerprintService.verify(request.user, template_data)

        audit_logger.log(
            action='FINGERPRINT_VERIFIED' if result.get('verified') else 'FINGERPRINT_FAILED',
            user=request.user,
            details={'match_score': result.get('match_score')}
        )

        return Response(result)


class VerificationStatusView(APIView):
    """GET /verification/status - Full verification status"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        fingerprints = FingerprintRecord.objects.filter(user=user, status='enrolled')

        try:
            nin_record = NINVerification.objects.get(user=user)
            nin_status = nin_record.status
        except NINVerification.DoesNotExist:
            nin_status = 'not_submitted'

        return Response({
            'success': True,
            'overall_status': user.verification_status,
            'is_verified': user.is_verified,
            'steps': {
                'email': {'completed': user.email_verified, 'label': 'Email Verification'},
                'phone': {'completed': user.phone_verified, 'label': 'Phone Verification'},
                'nin': {
                    'completed': user.nin_verified,
                    'status': nin_status,
                    'label': 'NIN Verification'
                },
                'fingerprint': {
                    'completed': user.fingerprint_enrolled,
                    'enrolled_count': fingerprints.count(),
                    'fingers': [f.finger_type for f in fingerprints],
                    'label': 'Biometric Enrollment'
                },
            },
            'completion_percentage': self._calculate_completion(user),
            'next_step': self._get_next_step(user),
        })

    def _calculate_completion(self, user):
        steps = [user.email_verified, user.phone_verified, user.nin_verified, user.fingerprint_enrolled]
        return int((sum(steps) / len(steps)) * 100)

    def _get_next_step(self, user):
        if not user.email_verified:
            return {'action': 'verify_email', 'message': 'Verify your email address'}
        if not user.phone_verified:
            return {'action': 'verify_phone', 'message': 'Verify your phone number'}
        if not user.nin_verified:
            return {'action': 'submit_nin', 'message': 'Submit your NIN for verification'}
        if not user.fingerprint_enrolled:
            return {'action': 'enroll_fingerprint', 'message': 'Enroll your fingerprint'}
        return None
